package helper.hkmbPersonal; 

import isg.comm.CCardCommConst;
import isg.comm.GDTCommConst;
import isg.commercial.Commercial;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.Vector;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.jstl.core.Config;

import org.apache.struts.Globals;
import org.apache.struts.action.ActionForm;

import ACESvc.ACEFactory;
import ACESvc.ACESvcLabel;

import common.form.BaseForm;
import common.helper.SuspendPgmInstance;

import ctil.banking.config.AccTypeConfig;
import ctil.banking.config.AppSetupConfig;
import ctil.banking.config.BankAccType;
import ctil.banking.config.BranchConfig;
import ctil.banking.config.CCTrxAccessConfig;
import ctil.banking.config.CCardTypeConfig;
import ctil.banking.config.CommCustConfig;
import ctil.banking.config.ConfigConst;
import ctil.banking.config.CurrencyRefConfig;
import ctil.banking.config.ECertTrxConfig;
import ctil.banking.config.HKDFeeConfig;
import ctil.banking.config.HolidayConfig;
import ctil.banking.config.HostTrxCodeDespConfig;
import ctil.banking.config.LoadConfigException;
import ctil.banking.config.LoanTypeConfig;
import ctil.banking.config.SecMarketIdConfig;
import ctil.banking.config.SecProductLineConfig;
import ctil.banking.config.TenorConfig;
import ctil.banking.config.TrxAccessConfig;
import ctil.banking.config.TrxAvailConfig;
import ctil.banking.config.TrxCodeDespConfig;
import ctil.banking.config.TrxErrorCodeConfig;
import ctil.banking.profile.UserProfile;
import ctil.banking.util.TransactionException;
import ctil.comm.CommConst;
import ctil.comm.Request;
import ctil.comm.Response;
import ctil.comm.WebSessConnector;
import ctil.util.CommonConst;
import ctil.util.ContentReader;
import ctil.util.CreditCardFormatter;
import ctil.util.ErrorPage;
import ctil.util.HostTrxNumber;
import ctil.util.Log;
import ctil.util.SQLAction;
import ctil.util.SQLActionResult;
import ctil.util.TrxAvailability;
import ctil.util.VecList;
import ctil.util.logging.DebugLogger;
import ctil.util.logging.base.LogConst;
/**
 * 
 */
abstract public class WebBankHelper 
{

    protected static DebugLogger logger = DebugLogger.getLogger();
    
    //----------------------------------------------------------
    // The following 4 parameters must be defined in subClasses.
	//----------------------------------------------------------
    protected String htmlFileName = null;         // The output HTML file name
	protected String errHtmlFileName = null;      // The error HTML file name
	protected String responsibleTrx = null;       // The code of transaction to be handled by the servlet
	protected String handleErrServletName = null; // The servlet handling zors
	protected String handleOkServletName = null;  // The servlet to be jumped to after displaying Response page

	protected String HTML_TemplateBaseDir = "";
	protected String HTML_ErrorTemplateBaseDir = "";

    //----------------------------------------------------------
    // Servlet Parameters
    //----------------------------------------------------------
//	protected ServletConfig servletCfg = null;
	protected HttpSession httpSession = null;
	protected HttpServletRequest httpReq = null;
	protected HttpServletResponse httpRsp = null;

    //----------------------------------------------------------
    // HTML input name defined in HTML page.
    //----------------------------------------------------------
	protected final String AccInfoParaName = "AccountList";
	protected final String IndexParaName = "index";
	protected final String WSMSeqNoParaName = CommConst.WSM_SEQ_NO;
	protected final String ErrorParaName = CommonConst.ERROR_FLAG;

    //----------------------------------------------------------
    // Index for storing information to UserProfile
    //----------------------------------------------------------
	protected Vector storedList = null;       // Used to store info to be pushed to UserProfile.
	protected final int ToHostReqIndex = 0;
	protected final int ConfirmInfoIndex = 1;

    //----------------------------------------------------------
    // Variables store the value of the above HTML input.
    //----------------------------------------------------------
	protected String parameterAccInfo = null;
	protected String parameterWsmSeqNo = null;
	protected String parameterErrFlag = null;

    //----------------------------------------------------------
    // Variable store the UserProfile info.
    //----------------------------------------------------------
	protected UserProfile userProfile = null;
	protected String userProfileSessionKey = null;

    //----------------------------------------------------------
    // The following 5 parameters are extracted from UserProfile
    //----------------------------------------------------------
	protected String bbpID = null;
    protected String hkid = null;
    protected String tokenHKID = null;
	protected byte [] passwd;
	protected String language = CommonConst.SYS_DEF_LANG;
	protected String traceID = CommonConst.SYS_TRACEID;
	private	String wsmSeqNoInUserProfile = null;

    //----------------------------------------------------------
    // The WSM Seq No sent from Browser.
    //----------------------------------------------------------
	private	String wsmSeqNoFromBrowser = null;

    //----------------------------------------------------------
    // Used to store the list of account types for user selection.
    //----------------------------------------------------------
	protected Vector selectAccTypeList = null;

    //----------------------------------------------------------
    // Used to store the Selection List (in TV form) for showing on HTML page.
    //----------------------------------------------------------
	protected Vector userInfoList = null;     // Selection List

    //----------------------------------------------------------
    // Used to store the selected account info from the selection list in the HTML page.
    //----------------------------------------------------------
	protected String selectedIdx = null;
	protected String accType = null;
	protected String productCode = null;
	protected String accNo = null;
	protected String accRefNo = null;
	protected String accCcy = null;

	protected String toSelectedIdx = null;
	protected String toAccType = null;
	protected String toProductCode = null;
	protected String toAccNo = null;
	protected String toAccRefNo = null;
	protected String toAccCcy = null;

    //----------------------------------------------------------
    // Reference Number info in response page.
    //----------------------------------------------------------
	private final String rspRefNoTag = CommConst.COM_FLD_RSP_REF_NO;

    //----------------------------------------------------------
    // Name of Servlet to be jumped to after showing response page.
    //----------------------------------------------------------
	private final String handleOkServletNameTag = CommConst.COM_FLD_SERVLET_CLASS;

	protected String rspPageRefNo = null;
    
    // Account Vec Field Index
    public final int ACC_VEC_IDX_ACCNO = 0;
    public final int ACC_VEC_IDX_DESC = 1;
    public final int ACC_VEC_IDX_CCY = 2;
    public final int ACC_VEC_IDX_TYPE = 3;
    public final int ACC_VEC_IDX_INDEX_NUM = 4;
    public final int ACC_VEC_IDX_BAL = 5;
    public final int ACC_VEC_IDX_BAL_SIGN = 6;
    public final int ACC_VEC_IDX_PROD_CODE = 7;
    public final int ACC_VEC_IDX_FULL_DESC = 8;    

    //----------------------------------------------------------        
    // Config Table
    //----------------------------------------------------------
	protected final int ACC_TYPE_CONFIG_IDX = 1;
	protected final int APP_SETUP_CONFIG_IDX = 2;
	protected final int BRANCH_CONFIG_IDX = 3;
	protected final int CCY_REF_CONFIG_IDX = 4;
	protected final int HKD_FEE_CONFIG_IDX = 5;
	protected final int HOLIDAY_CONFIG_IDX = 6;
	protected final int LOAN_TYPE_CONFIG_IDX = 7;
	protected final int TENOR_CONFIG_IDX = 8;
	protected final int TRX_ACCESS_CONFIG_IDX = 9;
	protected final int TRX_AVAIL_CONFIG_IDX = 10;
	protected final int TRX_CODE_DESP_CONFIG_IDX = 11;
	protected final int HOST_TRX_CODE_DESP_CONFIG_IDX = 12;

    protected final int COMM_CUST_CONFIG_IDX = 13;
    protected CommCustConfig commCustTbl = null;
    protected String _servletType = "N";
    
	protected AccTypeConfig accTypeTbl = null;
	protected AppSetupConfig appSetupTbl = null;
	protected BranchConfig branchTbl = null;
	protected CurrencyRefConfig ccyRefTbl = null;
	protected HKDFeeConfig hkdFeeTbl = null;
	protected HolidayConfig holidayTbl = null;
	protected LoanTypeConfig loanTypeTbl = null;
	protected final int SEC_MARKET_ID_CONFIG_IDX = 15;
	protected final int SEC_PRODUCT_LINE_IDX = 16;
	protected TenorConfig tenorTbl = null;
	protected TrxAccessConfig trxAccessTbl = null;
	protected TrxAvailConfig trxAvailTbl = null;
	protected TrxCodeDespConfig trxCodeDespTbl = null;
	protected HostTrxCodeDespConfig hostTrxCodeDespTbl = null;
	protected SecMarketIdConfig secMarketIdTbl = null;
    protected ECertTrxConfig ecertTrx = null;
    protected SecProductLineConfig secProductLines = null;

    //----------------------------------------------------------
    // Used to control if the parameters sent from Browser to be shown in the debug LogConst.
    //----------------------------------------------------------
	protected boolean showBrowserParameters = true;

    //----------------------------------------------------------
    // Other Class global variables
    //----------------------------------------------------------
	protected TrxAvailability trxAvail = null;
	protected Hashtable parameterTbl = null;

	protected BankAccType bankAccType = null;
	protected HostTrxNumber hTrxNum = null;
	protected boolean reqToChkWSM_SeqNo = false;
	protected boolean reqToChkAccessibility = false;  // determine if Selection list to be gen
	protected boolean reqMcssaSelectionList = true;   // get expanded Mcssa Selection List
	protected boolean reqFullSelectionList = false;
	protected String reqFilterCcy = "";
	protected boolean reqToMarkDefaultSelectionItem = false;
    protected boolean reqToChkAvailability = true;  // validation before submit request
    protected boolean reqToChkBrowserBack = false;

	public String markSelectionTag = CommConst.SELECTION_FLD_MARK_INDEX_NUM;
//	protected HTMLFormatter htmlFmt = null;
	protected int errCode = TransactionException.EC_SUCCESS;
    protected Vector accountVec = null;
    protected String transactionAvailablity = "";
    protected Map<String, String> errMsgVarMap = new HashMap<String, String>();	//PRJ4459: Return err message with variable
	protected WebSessConnector webSessConnector = null;

	protected final String DefaultDescString = "Unknown";
	protected String className = null;

	protected final int SuspendFlagIdx = 0;
	protected final int SuspendPageIdx = 1;
	protected final int SuspendContentIdx = 2;
    public ACEFactory aceF = null;
    
    protected String handlerRandomNum = "";
    
	//----------------------------------------------------------
	// Variable for Credit Card List	
	//----------------------------------------------------------
	private Vector creditCardList = null;
	
	
    //----------------------------------------------------------
    // Used to store function suspend message
    //----------------------------------------------------------
	protected String suspendMessage = "";

    
    //---------------------------------------------------------
    protected ActionForm actionForm    = null; 
    protected Object formObj = null;
    
    //---------------------------------------------------------
    // Added by Yan(CTIL)
    //---------------------------------------------------------    
    protected Vector rspInfo;  // response info in TagValue format		


    //---------------------------------------------------------
    // Added by Joanne
    //---------------------------------------------------------    
	public static String SQLTrxID = ConfigConst.TRX_NONHOSTWB;        

    //----------------------------------------------------------
    // Method
    //----------------------------------------------------------
    abstract protected void initPara();
	
    //---------------------------------------------------------
    // Modified by Yan(CTIL)r
    // Change the getRspInfo to public method for jpf access
    //---------------------------------------------------------  
    // Modified by Yan(CTIL)
    // Change the getRspInfo back to protected method 
    //---------------------------------------------------------      

    abstract protected Vector getRspInfo(String traceID);

//    abstract public Vector getRspInfo(String traceID);
    

    
    //----------------------------------------------------------
    // Servlet allows Back from Error page must implement this method
    //----------------------------------------------------------
    //	abstract protected Vector getBackPageInfo(String traceID);

	public WebBankHelper()
	{
		className = this.getClass().getName();
		logger.log(traceID, LogConst.SEV_INFO, className + ": constructor is called"); 
	}
    
    
    //---------------------------------------------------------
    // Added by Yan(CTIL)
    // For jsp access the instance variable rspInfo
    //---------------------------------------------------------
    /**
     * Method getResponse()
     * @return Vector
     */ 
    public Vector getResponse(){
        return rspInfo;
    }
        
	//---------------------------------------------------------
    // Added by Allen(CTIL)
    // For jsp access the current selected language
    //---------------------------------------------------------
    /**
     * Method getLanguage()
     * @return String
     */ 
	public String getLanguage(){
		return language;
	}
	
	
    /**
     * Method handle 
     * @param HttpServletRequest httpRequest     
     * @return int - TransactionException code no.
     *      
     */    
	public int handle(HttpServletRequest req, ActionForm form)
	{

		logger.log(traceID, LogConst.SEV_ROUTINE, className + ": handle starts");
		
		initPara();

        httpReq     = req;
        
        //Added by Yan(CTIL)        
        actionForm  = form;
        errCode = TransactionException.EC_SUCCESS;
		try {
			errCode = getDoPostParameters();
			if (errCode != TransactionException.EC_SUCCESS)
			{
				return errCode;
			}
		}
		catch (Exception e)
		{
			logger.log(traceID, LogConst.SEV_ERROR, className + ": Exception: getDoPostParameters: " + e.toString());
			errCode = TransactionException.EC_SYSTEM_ERROR;
			
			return errCode;
		}
        
        try{
            errCode = handleHttpRequest(req);
       
        }    
        catch (HandleableException e)
		{
			throw e;
		}
		catch (Exception e)
		{
			logger.log(traceID, LogConst.SEV_ERROR, className + ": Exception: handleHttpRequest: " + e.toString());
			errCode = TransactionException.EC_SYSTEM_ERROR;
			
			return errCode;
		}
        
        return errCode;
	}

	/**
	 * Method handle (new formBean)
	 * @param HttpServletRequest httpRequest     
	 * @return int - TransactionException code no.
	 *      
	 */    
	public int handle(HttpServletRequest req, String formBeanName, Object formBean) {
		logger.log(traceID, LogConst.SEV_ROUTINE, className + " (new formBean) : handle starts");

		initPara();

		httpReq = req;

///////////////////// THIS BLOCK IS REDUNDANT !!!!///////////////////////////////////	
//		
//		try {
//			//formObj = Class.forName(formBeanName).cast(formBean);
//			formObj = formBean;
//			logger.log(traceID, LogConst.SEV_ROUTINE, className + " (new formBean) : myForm.getClass() = " + 
//						formObj.getClass().getName());
//		} catch(ClassNotFoundException cnfe) {
//			errCode = TransactionException.EC_SYSTEM_ERROR;
//			return errCode;
//		}
////////////////////////////////////////////////////////////////////////////////
		
		
		formObj = formBean;
		
		/// !!!! IMPORTANT !!!
		/// Need to assign actionForm as well
		/// TO FIX: formObj and actionForm are similar and causes confusion.
		/// All action form needs to base on ActionForm can simplify code so that
		/// formObj can be eliminated.
		if (formBean instanceof ActionForm){
			actionForm  = (ActionForm)formBean;
		}
		
		errCode = TransactionException.EC_SUCCESS;

		try {
			errCode = getDoPostParameters();
			if (errCode != TransactionException.EC_SUCCESS) {
				return errCode;
			}
		} catch (Exception e) {
			logger.log(traceID, LogConst.SEV_ERROR, className + " (new formBean) : Exception: getDoPostParameters: " + e.toString());
			errCode = TransactionException.EC_SYSTEM_ERROR;

			return errCode;
		}

		try {
			errCode = handleHttpRequest(req);

		} catch (Exception e) {
			logger.log(traceID, LogConst.SEV_ERROR, className + " (new formBean) : Exception: handleHttpRequest: " + e.toString());
			errCode = TransactionException.EC_SYSTEM_ERROR;

			return errCode;
		}
		return errCode;
	}
	
	protected int handleHttpRequest(HttpServletRequest req)
	{
		logger.log(traceID, LogConst.SEV_ROUTINE, className + ": handleHttpRequest starts");

		if (hTrxNum == null)
		{
			hTrxNum = HostTrxNumber.getInstance(ConfigConst.FILE_VRUSEQNUM);
		}

		
		try
        {
			errCode = getUserProfile();  // chk HttpSession and the WebConnector seq. no
			if (errCode != TransactionException.EC_SUCCESS)
			{
                
				return errCode;
			}

			//Detect if the language is changed, the lang will be changed if detected
			detectLangChg(traceID);

            
            logger.log(traceID, LogConst.SEV_ROUTINE, className + ": start to check Commercial");
            
/* comment by Emily 20050204 No need to check */
            Commercial checking = new Commercial(traceID);
            //logger.log(traceID, LogConst.SEV_ROUTINE, className + ": after new commercial");
            
            errCode = checking.isAvailTrx(bbpID, responsibleTrx, _servletType, "", traceID);
            //      if (!checking.isAvailTrx(bbpID, responsibleTrx, _servletType, "", traceID))
            if (errCode != TransactionException.EC_SUCCESS)
            {
                logger.log(traceID, LogConst.SEV_ERROR, className + ": return "+errCode);
 			
                return errCode;
            }
            logger.log(traceID, LogConst.SEV_ERROR, className + ": commercial checking is done.");
/**/            

        }
		catch (Exception e)
		{
			logger.log(traceID, LogConst.SEV_ERROR, className + ": handleHttpRequest: Exception: getUserProfile: " + e.toString());
			errCode = TransactionException.EC_SYSTEM_ERROR;
            
			return errCode;
		}
		/*
        try{
            secureECertTrx(responsibleTrx);
        }catch (TransactionException e)
		{
			logger.log(traceID, LogConst.SEV_WARNING, className + ": handleHttpRequest: Transaction Exception: " + e.getMessage());
			errCode = e.getErrorNumber();
            return errCode;
		}

        // Check function suspend
        
        isSuspend(className, traceID);
        if (errCode != TransactionException.EC_SUCCESS) {
            return errCode;
        }
        */
    

        try {
			bankAccType = BankAccType.getInstance(traceID);
    		trxAvail = TrxAvailability.getInstance(traceID);
        }
        catch (LoadConfigException e)
        {
			logger.log(traceID, LogConst.SEV_ERROR, className + ": handleHttpRequest: LoadConfigException: " + e.getMessage());
            errCode = TransactionException.EC_LOAD_SYS_CFG;      
            return errCode;
        }
        catch (Exception e)
        {
			logger.log(traceID, LogConst.SEV_ERROR, className + ": handleHttpRequest: TrxAvailability.getInstance Exception: " + e.getMessage());
            errCode = TransactionException.EC_LOAD_SYS_CFG;        
            return errCode;
        }

		try {
			errCode = validateSession();  // chk HttpSession and the WebConnector seq. no
			if (errCode != TransactionException.EC_SUCCESS)
			{          
				return errCode;
			}
		}
		catch (Exception e)
		{
			logger.log(traceID, LogConst.SEV_ERROR, className + ": handleHttpRequest: Exception: validateSession: " + e.toString());
			errCode = TransactionException.EC_SYSTEM_ERROR;           
			return errCode;
		}

		try {
			errCode = loadConfig(traceID);
			if ((errCode != TransactionException.EC_SUCCESS))
			{            
				return errCode;
			}
		}
		catch (Exception e)
		{
			logger.log(traceID, LogConst.SEV_ERROR, className + ": handleHttpRequest: Exception: loadConfig: " + e.toString());
            errCode = TransactionException.EC_LOAD_SYS_CFG;           
			return errCode;
		}

		try {
			errCode = chkAccessibility(traceID);
			if (errCode != TransactionException.EC_SUCCESS)
			{          
				return errCode;
			}
		}
		catch (Exception e)
		{
			logger.log(traceID, LogConst.SEV_ERROR, className + ": handleHttpRequest: Exception: chkAccessibility: " + e.toString());
			errCode = TransactionException.EC_SYSTEM_ERROR;           
			return errCode;
		}

		try {
			errCode = chkBrowserBack(traceID);
			if (errCode != TransactionException.EC_SUCCESS)
			{          
				return errCode;
			}
		}
		catch (Exception e)
		{
			logger.log(traceID, LogConst.SEV_ERROR, className + ": handleHttpRequest: Exception: chkBrowserBack: " + e.toString());
			errCode = TransactionException.EC_SYSTEM_ERROR;           
			return errCode;
		}
		
		
		try {
			errCode = handleReq(traceID);          
			logger.log(traceID, LogConst.SEV_ROUTINE, className + ": handleHttpRequest finished");
			return errCode;
		}
		catch (HandleableException e)
		{
			throw e;
		}
		catch (Exception e)
		{
			logger.log(traceID, LogConst.SEV_ERROR, className + ": handleHttpRequest: Exception: " + e.toString()+":"+new UnhandleableException(e));
			errCode = TransactionException.EC_SYSTEM_ERROR;
			return errCode;
		}
	}
    
    /**
     * Method getAllParameters - Get all parameters from Browser.
     * 
     */
	private void getAllParameters()
	{
		String parameterName;
		String parameterValue;
		String tmpValue;

		logger.log(traceID, LogConst.SEV_ROUTINE, className + ": getAllParameters() starts");

		try {
			parameterTbl = new Hashtable();
			Enumeration enumeration = httpReq.getParameterNames();

			while(enumeration.hasMoreElements())
			{
				parameterName = (String)enumeration.nextElement();
				parameterValue = (String)httpReq.getParameterValues(parameterName)[0];

				if (parameterValue != null)
				{
					parameterTbl.put(parameterName, parameterValue);

					if (showBrowserParameters)
					{
						logger.log(traceID, LogConst.SEV_ROUTINE, className + ": getAllParameters:(" + parameterName + "," + parameterValue + ")" );
					}
                    
                    //if (parameterValue.toLowerCase().indexOf("script") >= 0 && parameterValue.toLowerCase().indexOf("<") >= 0 && parameterValue.toLowerCase().indexOf(">") >= 0) {
                    if (parameterValue.toLowerCase().indexOf("<") >= 0 || 
                        parameterValue.toLowerCase().indexOf(">") >= 0 ||
                        parameterValue.toLowerCase().indexOf("&#x3c") >= 0 ||
                        parameterValue.toLowerCase().indexOf("&#x3e") >= 0)    
                    {
                        logger.log(traceID, LogConst.SEV_ROUTINE, className + ": Parameter values contains crosssite scripting!!" );
                        errCode = TransactionException.EC_UNKNOWN_ERROR;
                    }                     
				}
			}
		}
		catch (Exception e)
		{
			logger.log(traceID, LogConst.SEV_ROUTINE, className + ": getAllParameters: no parameters sent from browser");
		}
	}

	protected int getDoPostParameters()
	{
		logger.log(traceID, LogConst.SEV_ROUTINE, className + ": getDoPostParameters starts");
		try {
			getAllParameters();
            if (errCode != TransactionException.EC_SUCCESS) {
                return errCode;
            }
			parameterAccInfo = getParameterValue(AccInfoParaName);
			parameterErrFlag = getParameterValue(ErrorParaName);
			parameterWsmSeqNo = getParameterValue(WSMSeqNoParaName);

			logger.log(traceID, LogConst.SEV_ROUTINE, className + ": getDoPostParameters: AccInfo: " + parameterAccInfo + " errFlag " + parameterErrFlag + " WebSMSeqNO " + parameterWsmSeqNo);
		}
		catch (Exception e)
		{
		  logger.log(traceID, LogConst.SEV_ERROR, className + ": getDoPostParameters: no parameter");
		}
		errCode = TransactionException.EC_SUCCESS;
		return errCode;
	}

	protected int getDoGetParameters()
	{
		logger.log(traceID, LogConst.SEV_ROUTINE, className + ": getDoGetParameters starts");

		try {
			getAllParameters();
            if (errCode != TransactionException.EC_SUCCESS) {
                return errCode;
            }
			parameterAccInfo = getParameterValue(IndexParaName);

			logger.log(traceID, LogConst.SEV_ROUTINE, className + ": getDoGetParameters: " + IndexParaName + "=" + parameterAccInfo);
		}
		catch (Exception e)
		{
		  logger.log(traceID, LogConst.SEV_ERROR, className + ": getDoGetParameters: no values for parameter: " + IndexParaName);
		}
		errCode = TransactionException.EC_SUCCESS;
		return errCode;
	}

	protected int validateSession()
	{
		errCode = TransactionException.EC_SUCCESS;

		logger.log(traceID, LogConst.SEV_ROUTINE, className + ": validateSession starts");

		chkWSM_SeqNo(traceID);
		if (errCode != TransactionException.EC_SUCCESS)
		{
			return errCode;
		}

        try {
       		webSessConnector = new WebSessConnector(traceID);
			if (!webSessConnector.allowTrx(userProfile.getUserID(traceID), traceID))
			{
				errCode = TransactionException.EC_TRX_ALDY_IN_PROGRESS;
				return errCode;
			}
        }
        catch (TransactionException e)
        {
			logger.log(traceID, LogConst.SEV_WARNING, className + ": validateSession: Transaction Exception: " + e.getMessage());
			errCode = e.getErrorNumber();
			return errCode;
        }
        catch (Exception e)
        {
			logger.log(traceID, LogConst.SEV_WARNING, className + ": validateSession: Exception: " + e.getMessage());
			errCode = TransactionException.EC_SYSTEM_ERROR;
			return errCode;
        }

		logger.log(traceID, LogConst.SEV_ROUTINE, className + ": validateSession finished");

        return errCode;
	}

	protected int chkAccessibility(String traceID)
	{
		Vector markedItemList = null;
		String indexInfo = null;
		errCode = TransactionException.EC_SUCCESS;

		logger.log(traceID, LogConst.SEV_ROUTINE, className + ": chkAccessibility starts");
		
		//SR002420 Credit Card
//		if (!reqToChkAccessibility)
//		{
//			userInfoList = new Vector();
//			return errCode;
//		}
		
		if (parameterAccInfo != null)
		{
			markedItemList = genSelectedItemList(markSelectionTag, parameterAccInfo, traceID);
			userProfile.markSelectedItem(markedItemList);
			logger.log(traceID, LogConst.SEV_ROUTINE, className + ": chkAccessibility: to mark selected info for index: " + parameterAccInfo);
		}
		else
		{
		 	if (reqToMarkDefaultSelectionItem)
		 	{
		 		if ((indexInfo = getDefaultSelectionItemFromUserProfile(traceID)) != null)
		 		{
					markedItemList = genSelectedItemList(markSelectionTag, indexInfo, traceID);
					userProfile.markSelectedItem(markedItemList);
					logger.log(traceID, LogConst.SEV_ROUTINE, className + ": chkAccessibility: to mark selected info for index: " + indexInfo);
				}
		 	}
		 	else
			{
				userProfile.markSelectedItem(null);
			}
		}

        // PRJ3904 Start to generate Account Selection List
		
		prepareHostSysBal();
		
		if (reqFullSelectionList)
		{
			userInfoList = userProfile.getFullSelectionList(traceID);
		}
		else
		{
			selectAccTypeList = trxAvail.getAccessibleAccTypes(responsibleTrx, traceID);
			if (reqFilterCcy.length() != 0)
			{
				userInfoList = userProfile.getRequiredList(selectAccTypeList, reqFilterCcy, traceID);
			}
			else
			{
				userInfoList = userProfile.getRequiredList(selectAccTypeList, reqMcssaSelectionList, traceID);
			}
		}

		if ((userInfoList == null) || (userInfoList.isEmpty()))
		{			
			//SR002420 Credit Card
			if (!reqToChkAccessibility) {
                userInfoList = new Vector();
                return errCode;
            } else {            
    			logger.log(traceID, LogConst.SEV_WARNING, className + ": chkAccessibility: userInfoList is null or empty");
//    			userInfoList = new Vector();
//    			trxAvail.genNowAccessibleTrxInTV(userInfoList, null, traceID);
    			errCode = TransactionException.EC_TRANSACTION_NOT_ALLOW;
            }
			
		}
		else
		{
			logger.log(traceID, LogConst.SEV_ROUTINE, className + ": chkAccessibility: finished to userProfile.getRequiredList: size: " + userInfoList.size());
			errCode = TransactionException.EC_SUCCESS;
		}

		logger.log(traceID, LogConst.SEV_ROUTINE, className + ": chkAccessibility finished");
		return errCode;
	}

    /**
     * Method handleReq
     * @param String traceID
     * @return int
     * Handle received Http Req
     */
	protected int handleReq(String traceID)
	{
		Vector tv = null;
		Vector markedItemList = null;
        VecList vecList = new VecList();
        //------------------
        // Modified by Yan(CTIL)
        // Change rspInfo to instance variable
        //------------------
		//Vector rspInfo;  // response info in TagValue format		
		
        String nextWebSMSeqNo;

		String accInfo = parameterAccInfo;;

		logger.log(traceID, LogConst.SEV_ROUTINE, className + ": handleReq: starts");

		if (chkIfIsOnErr(traceID))
		{
			logger.log(traceID, LogConst.SEV_ROUTINE, className + ": handleReq: chkIfIsOnErr is true");
			errCode = TransactionException.EC_SUCCESS;
			rspInfo = getBackPageInfo(traceID);
		}
		else
		{
			logger.log(traceID, LogConst.SEV_ROUTINE, className + ": handleReq: starting to generate response");
			errCode = TransactionException.EC_SUCCESS;
			rspInfo = getRspInfo(traceID);   // SubClass defined function to determine which
			                                 // HTML Template file to be used and return the
			                                 // information to be shown.
		}


		if (errCode != TransactionException.EC_SUCCESS)
		{
			logger.log(traceID, LogConst.SEV_WARNING, className + ": handleReq: genErrRsp for errCode: " + errCode);
            /* emily add */
            try {
                vecList.addItem(rspInfo, CommConst.ERR_FLD_ERR_MESG, getTrxErrMsg(errCode), traceID);
                vecList.addItem(rspInfo, CommConst.ERR_FLD_ERR_NO, Integer.toString(errCode), traceID);
                this.addTrxAvailabilityInfoToList(rspInfo, traceID);
            } catch (Exception e) {
                return errCode;
            }
			return errCode;
		}
        
        // Check function suspend
        isSuspend(className, traceID);
        if (errCode != TransactionException.EC_SUCCESS) {
            try {
                vecList.addItem(rspInfo, CommConst.ERR_FLD_ERR_MESG, getTrxErrMsg(errCode), traceID);
                vecList.addItem(rspInfo, CommConst.ERR_FLD_ERR_NO, Integer.toString(errCode), traceID);
                this.addTrxAvailabilityInfoToList(rspInfo, traceID);
            } catch (Exception e) {
                return errCode;
            }

            return errCode;
        }
        

		errCode = TransactionException.EC_SUCCESS;
		nextWebSMSeqNo = addWSM_SeqNo(rspInfo, traceID);
		logger.log(traceID, LogConst.SEV_ROUTINE, className + ": handleReq: get next WebSMSeqNo: " + nextWebSMSeqNo);

		if (errCode != TransactionException.EC_SUCCESS)
		{
			logger.log(traceID, LogConst.SEV_WARNING, className + ": handleReq: Failed to add WSM_SeqNo to the vector List");
            /* emily add */
            try {
                vecList.addItem(rspInfo, CommConst.ERR_FLD_ERR_MESG, getTrxErrMsg(errCode), traceID);
                vecList.addItem(rspInfo, CommConst.ERR_FLD_ERR_NO, Integer.toString(errCode), traceID);
                this.addTrxAvailabilityInfoToList(rspInfo, traceID);
            } catch (Exception e) {
                return errCode;
            }
            
			return errCode;
		}

		try
		{
			logger.log(traceID, LogConst.SEV_ROUTINE, className + ": handleReq: Start to format rsp page with template: " + HTML_TemplateBaseDir + htmlFileName);

            // Insert the language to the vector list
			addLanguageToList(rspInfo, this.language, traceID);
            
            // revamp Prashant Insert customer name to vector list
			addCustomerNameToList(rspInfo,this.userProfile.getCustomerName(traceID), traceID);			
            
            // revamp Prashant Insert last login time to vector list
			addLastLoginTimeToList(rspInfo,this.userProfile.getLastLoginTime(traceID), traceID);			

           
		}
		catch (Exception e)
		{
			logger.log(traceID, LogConst.SEV_ERROR, className + ": handleReq: Exception: " + e.getMessage());
			errCode = TransactionException.EC_SYSTEM_ERROR;                        
            try {
                vecList.addItem(rspInfo, CommConst.ERR_FLD_ERR_MESG, getTrxErrMsg(errCode), traceID);
                vecList.addItem(rspInfo, CommConst.ERR_FLD_ERR_NO, Integer.toString(errCode), traceID);
                this.addTrxAvailabilityInfoToList(rspInfo, traceID);
            } catch (Exception ee) {
                return errCode;
            }                
			return errCode;
		}


		logger.log(traceID, LogConst.SEV_ROUTINE, className + ": handleReq: finished");

		return errCode;
	}

   
    /**
     * Method extractSelection
     * Extract the selected account info from the selection list
     */
	protected boolean extractSelection(String accInfo, String traceID)
	{
		Vector selectionInfo;

		if (accInfo == null)
		{
			return false;
		}

		try {
			selectedIdx = accInfo;
			selectionInfo = userProfile.index2AcctInfo(selectedIdx);
			ContentReader cr = new ContentReader();
			cr.setContent(selectionInfo, traceID);

			accType = (String)cr.getContent(CommConst.SELECTION_FLD_ACCT_TYPE,
											CommConst.MSGPOS_CONTENT, traceID);

			productCode = (String)cr.getContent(CommConst.SELECTION_FLD_ACCT_PRODUCT_CODE,
												CommConst.MSGPOS_CONTENT, traceID);

			accNo = (String)cr.getContent(CommConst.SELECTION_FLD_ACCT_NO,
										  CommConst.MSGPOS_CONTENT, traceID);

			accCcy = (String)cr.getContent(CommConst.SELECTION_FLD_ACCT_CURR,
										CommConst.MSGPOS_CONTENT, traceID);

			accRefNo = null;

			if ((accType != null) && (productCode != null) && (accNo != null) && (accCcy != null))
			{
				logger.log(traceID, LogConst.SEV_ROUTINE, className + ": extractSelection: for index: " + accInfo + " accType: " + accType + ", productCode: " + productCode + ", accNo: " + accNo + ", ccy: " + accCcy);

				// check if the accType is loan or time deposit. If so, get the corresponding
				// account no.

				if ( bankAccType.checkCategory(accType, traceID).equalsIgnoreCase(BankAccType.timeDeposit) )
				{
					accRefNo = accNo;
					accNo = userProfile.getTimeDepositAccNo(traceID);
				}
				else if ( bankAccType.checkCategory(accType, traceID).equalsIgnoreCase(BankAccType.loan) )
				{
					accRefNo = accNo;
					accNo = userProfile.getLoanAcctNo(traceID);
				}
				return true;
			}
			logger.log(traceID, LogConst.SEV_WARNING, className + ": extractSelection: Invalid format for index: " + accInfo);
			return false;
		}
		catch (Exception e)
		{
			logger.log(traceID, LogConst.SEV_ERROR, className + ": extractSelection: Exception: extract info for index: " + accInfo);
			return false;
		}
	}

    /**
     * Extract the "To" selected account info from the selection list
     */
	protected boolean extractToSelection(String accInfo, String traceID)
	{
		Vector selectionInfo;

		if (accInfo == null)
		{
			return false;
		}

		try {
			selectedIdx = accInfo;
			selectionInfo = userProfile.index2AcctInfo(selectedIdx);
			ContentReader cr = new ContentReader();
			cr.setContent(selectionInfo, traceID);

			toAccType = (String)cr.getContent(CommConst.SELECTION_FLD_ACCT_TYPE,
											CommConst.MSGPOS_CONTENT, traceID);

			toProductCode = (String)cr.getContent(CommConst.SELECTION_FLD_ACCT_PRODUCT_CODE,
												CommConst.MSGPOS_CONTENT, traceID);

			toAccNo = (String)cr.getContent(CommConst.SELECTION_FLD_ACCT_NO,
										  CommConst.MSGPOS_CONTENT, traceID);

			toAccCcy = (String)cr.getContent(CommConst.SELECTION_FLD_ACCT_CURR,
										CommConst.MSGPOS_CONTENT, traceID);

			toAccRefNo = null;
			if ((toAccType != null) && (toProductCode != null) && (toAccNo != null) && (toAccCcy != null))
			{
				logger.log(traceID, LogConst.SEV_ROUTINE, className + ": extractToSelection: for index: " + accInfo + " accType: " + toAccType + ", productCode: " + toProductCode + ", accNo: " + toAccNo + ", ccy: " + toAccCcy);

				// check if the accType is loan or time deposit. If so, get the corresponding
				// account no.

				if ( bankAccType.checkCategory(toAccType, traceID).equalsIgnoreCase(BankAccType.timeDeposit) )
				{
					toAccRefNo = toAccNo;
					toAccNo = userProfile.getTimeDepositAccNo(traceID);
				}
				else if ( bankAccType.checkCategory(toAccType, traceID).equalsIgnoreCase(BankAccType.loan) )
				{
					toAccRefNo = toAccNo;
					toAccNo = userProfile.getLoanAcctNo(traceID);
				}
				return true;
			}
			logger.log(traceID, LogConst.SEV_WARNING, className + ": extractToSelection: Invalid format for index: " + accInfo);
			return false;
		}
		catch (Exception e)
		{
			logger.log(traceID, LogConst.SEV_ERROR, className + ": extractToSelection: Exception: extract info for index: " + accInfo);
			return false;
		}
	}

    /**
     * Method loadConfig
     * Default method to load config table (do nothing)
     */
	protected int loadConfig(String traceID)
	{
		logger.log(traceID, LogConst.SEV_ROUTINE, className + ": loadConfig: no config file is needed to load");

		errCode = TransactionException.EC_SUCCESS;
		return errCode;
	}

    /**
     * Method loadConfigTbl
     * A common routine to load a specific config table.
     */
	protected int loadConfigTbl(int configIndex, String traceID)
	{
		String tblName;
		boolean loaded = false;

		logger.log(traceID, LogConst.SEV_ROUTINE, className + ": loadConfigTbl starts");

		errCode = TransactionException.EC_SUCCESS;
		try {
			switch (configIndex)
			{
				case ACC_TYPE_CONFIG_IDX:
					tblName = ConfigConst.FILE_ACC_TYPE;
					accTypeTbl = null;
					accTypeTbl = AccTypeConfig.getInstance(tblName, traceID);
					loaded = accTypeTbl != null ? true : false;
					break;
				case APP_SETUP_CONFIG_IDX:
					tblName = ConfigConst.FILE_APP_SETUP;
					appSetupTbl = null;
					appSetupTbl = AppSetupConfig.getInstance(tblName, traceID);
					loaded = appSetupTbl != null ? true : false;
					break;
				case BRANCH_CONFIG_IDX:
					tblName = ConfigConst.FILE_BRANCH;
					branchTbl = null;
					branchTbl = BranchConfig.getInstance(tblName, traceID);
					loaded = branchTbl != null ? true : false;
					break;
				case CCY_REF_CONFIG_IDX:
					tblName = ConfigConst.FILE_CURRENCY_REF;
					ccyRefTbl = null;
					ccyRefTbl = CurrencyRefConfig.getInstance(tblName, traceID);
					loaded = ccyRefTbl != null ? true : false;
					break;
				case HKD_FEE_CONFIG_IDX:
					tblName = ConfigConst.FILE_HKD_FEE;
					hkdFeeTbl = null;
					hkdFeeTbl = HKDFeeConfig.getInstance(tblName, traceID);
					loaded = hkdFeeTbl != null ? true : false;
					break;
				case HOLIDAY_CONFIG_IDX:
					tblName = ConfigConst.FILE_HOLIDAY;
					holidayTbl = null;
					holidayTbl = HolidayConfig.getInstance(tblName, traceID);
					loaded = holidayTbl != null ? true : false;
					break;
				case LOAN_TYPE_CONFIG_IDX:
					tblName = ConfigConst.FILE_LOAN_TYPE;
					loanTypeTbl = null;
					loanTypeTbl = LoanTypeConfig.getInstance(tblName, traceID);
					loaded = loanTypeTbl != null ? true : false;
					break;
				case TENOR_CONFIG_IDX:
					tblName = ConfigConst.FILE_TENOR;
					tenorTbl = null;
					tenorTbl = TenorConfig.getInstance(tblName, traceID);
					loaded = tenorTbl != null ? true : false;
					break;
				case TRX_ACCESS_CONFIG_IDX:
					tblName = ConfigConst.FILE_TRX_ACCESS;
					trxAccessTbl = null;
					trxAccessTbl = TrxAccessConfig.getInstance(tblName, traceID);
					loaded = trxAccessTbl != null ? true : false;
					break;
				case TRX_AVAIL_CONFIG_IDX:
					tblName = ConfigConst.FILE_TRX_AVAIL;
					trxAvailTbl = null;
					trxAvailTbl = TrxAvailConfig.getInstance(tblName, traceID);
					loaded = trxAvailTbl != null ? true : false;
					break;
				case TRX_CODE_DESP_CONFIG_IDX:
					tblName = ConfigConst.FILE_TRX_CODE;
					trxCodeDespTbl = null;
					trxCodeDespTbl = TrxCodeDespConfig.getInstance(tblName, traceID);
					loaded = trxCodeDespTbl != null ? true : false;
					break;
				case HOST_TRX_CODE_DESP_CONFIG_IDX:
					tblName = ConfigConst.FILE_HOST_TRX_CODE;
					hostTrxCodeDespTbl = null;
					hostTrxCodeDespTbl = HostTrxCodeDespConfig.getInstance(tblName, traceID);
					loaded = hostTrxCodeDespTbl != null ? true : false;
					break;
				case COMM_CUST_CONFIG_IDX:
					tblName = ConfigConst.FILE_COMM_CUST;
					commCustTbl = null;
					commCustTbl = CommCustConfig.getInstance(tblName, traceID);
					loaded = commCustTbl != null ? true : false;
					break;
				case SEC_MARKET_ID_CONFIG_IDX:
					tblName = ConfigConst.FILE_SEC_MARKET_ID;
					secMarketIdTbl = null;
					secMarketIdTbl = SecMarketIdConfig.getInstance(tblName, traceID);
					loaded = secMarketIdTbl != null ? true : false;
					break;
				case SEC_PRODUCT_LINE_IDX:
					tblName = ConfigConst.FILE_SEC_PRODUCT_LINE;
					secProductLines = null;
					secProductLines = SecProductLineConfig.getInstance(tblName, traceID);
					loaded = secProductLines != null ? true : false;
					break;
				default:
					errCode = TransactionException.EC_LOAD_SYS_CFG;
					logger.log(traceID, LogConst.SEV_ROUTINE, className + ": loadConfigTbl: unrecognized config index: " + configIndex);
					return errCode;

			}

			if (!loaded)
			{
				errCode = TransactionException.EC_LOAD_SYS_CFG;
			}
			logger.log(traceID, LogConst.SEV_ROUTINE, className + ": loadConfigTbl: load config: " + tblName + " result: " + loaded);
		}
		catch (LoadConfigException e)
		{
			logger.log(traceID, LogConst.SEV_ERROR, className + ": loadConfigTbl: LoadConfigException: " + e.toString());
			errCode = TransactionException.EC_LOAD_SYS_CFG;
		}
		catch (Exception e)
		{
			logger.log(traceID, LogConst.SEV_ERROR, className + ": loadConfigTbl: Exception: " + e.toString());
			e.printStackTrace();
			errCode = TransactionException.EC_LOAD_SYS_CFG;
		}
		logger.log(traceID, LogConst.SEV_ROUTINE, className + ": loadConfigTbl finished");
		return errCode;
	}

	protected String getDefaultSelectionItemFromUserProfile(String traceID)
	{
		Vector info;
		if (userProfile != null)
		{
			info = userProfile.getDefaultSelectedItem();
			if (info != null)
			{
				return (String)info.elementAt(0);
			}
		}
		return null;
	}

	protected Vector genDefaultSelectedItemList(String info, String traceID)
	{
		Vector list = new Vector();

		if (info == null)
			return null;

		list.addElement(info);
		return list;
	}

	protected Vector genSelectedItemList(String tag, String index, String traceID)
	{
		Vector list = new Vector();
		Vector oneItem = new Vector(2);

		if (index == null)
			return null;

		oneItem.addElement(index);
		oneItem.addElement(tag);
		list.addElement(oneItem);

		return list;
	}

	protected Vector getBackPageInfo(String traceID)
	{
		return null;
	}

	protected String getTemplateBaseDir(String language, String traceID)
	{
		if (language.equals(CommonConst.LANG_ENGLISH))
		{
			return ConfigConst.HTML_TemplateBaseDir_ENGLISH;
		}
		return ConfigConst.HTML_TemplateBaseDir_CHINESE;
	}

	protected String getErrorTemplateBaseDir(String language, String traceID)
	{
		if (language.equals(CommonConst.LANG_ENGLISH))
		{
			return ConfigConst.HTML_TemplateBaseDir_ENGLISH;
		}
		return ConfigConst.HTML_TemplateBaseDir_CHINESE;
	}

	private String getUserProfileSessionKey()
	{
		return CommonConst.KEY_USERPROFILE;
	}

	protected int getUserProfile()
	{
		logger.log(traceID, LogConst.SEV_ROUTINE, className + ": getUserProfile starts");

		errCode = TransactionException.EC_SUCCESS;
		if ((httpSession = httpReq.getSession(false)) == null)
		{
			logger.log(traceID, LogConst.SEV_WARNING, className + ": getUserProfile: Failed to getSession");
			//errCode = TransactionException.EC_INVALID_SESSIONID;
			
			errCode = TransactionException.EC_USER_FORCE_LOGOFFED;
			return errCode;
		}

		userProfileSessionKey = getUserProfileSessionKey();
		userProfile = (UserProfile)httpSession.getAttribute(userProfileSessionKey);

		if (userProfile == null)
		{
			logger.log(traceID, LogConst.SEV_WARNING, className + ": getUserProfile: Failed to get userProfile with session key: " + userProfileSessionKey);
			// errCode = TransactionException.EC_INVALID_SESSIONID;
			errCode = TransactionException.EC_USER_FORCE_LOGOFFED;
			return errCode;
		}

		getParametersFromUserProfile();

		logger.log(traceID, LogConst.SEV_ROUTINE, className + ": getUserProfile finished");
 		logger.log(traceID, LogConst.SEV_ROUTINE, className + ": errCode = "+errCode);
        return errCode;
	}

	public int chkUserProfile(HttpServletRequest req, String traceID){
		logger.log(traceID, LogConst.SEV_ROUTINE, className + ": checkUserProfile starts");

		errCode = TransactionException.EC_SUCCESS;
		if ((httpSession = req.getSession(false)) == null)
		{
			logger.log(traceID, LogConst.SEV_WARNING, className + ": checkUserProfile: Failed to getSession");
			//errCode = TransactionException.EC_INVALID_SESSIONID;
			errCode = TransactionException.EC_USER_FORCE_LOGOFFED;
			return errCode;
		}

		userProfileSessionKey = getUserProfileSessionKey();
		userProfile = (UserProfile)httpSession.getAttribute(userProfileSessionKey);

		if (userProfile == null)
		{
			logger.log(traceID, LogConst.SEV_WARNING, className + ": checkUserProfile: Failed to get userProfile with session key: " + userProfileSessionKey);
			//errCode = TransactionException.EC_INVALID_SESSIONID;
			errCode = TransactionException.EC_USER_FORCE_LOGOFFED;
			return errCode;
		}

		//getParametersFromUserProfile();

		logger.log(traceID, LogConst.SEV_ROUTINE, className + ": checkUserProfile finished");
 		logger.log(traceID, LogConst.SEV_ROUTINE, className + ": errCode = "+errCode);
        return errCode;
	}
    /**
     * Method getRspInfoFromHost
     * - Get information from Host.
     * 
     * Using this method to submit req to Host must implement the following methods:
     * composeHostReq
     * submitReq
     */
	protected Vector getRspInfoFromHost(String traceID)
	{


		Vector req;
		Vector result = null;

		boolean validFormat = false;

		String accInfo = parameterAccInfo;

		logger.log(traceID, LogConst.SEV_INFO, className + ": parent's getRspInfoFromHost");

		validFormat = extractSelection(accInfo, traceID);
		errCode = TransactionException.EC_SUCCESS;

//		if (trxAvail.isAvailable(responsibleTrx, traceID))
		if (trxAvail.isNowAccessible(responsibleTrx, accType, traceID))
		{
			req = composeHostReq(traceID);
			if (errCode != TransactionException.EC_SUCCESS)
			{
				return result;
			}
			result = submitReq(req, traceID);
		}
		else
		{
			logger.log(traceID, LogConst.SEV_WARNING, className + ": getRspInfoFromHost: trx: " + responsibleTrx + " is not now accessible for accType: " + accType);
			errCode = TransactionException.EC_TRANSACTION_NOT_ALLOW;
			result = null;
		}
		return result;
	}

	protected void getParametersFromUserProfile()
	{
		traceID = userProfile.getTraceID();
		language = userProfile.getUserLanguage(traceID);
		if (language == null)
		{
			logger.log(traceID, LogConst.SEV_INFO, className + ": getParametersFromUserProfile: no language is defined in UserProfile");
			language = CommonConst.SYS_DEF_LANG;
		}
		bbpID = userProfile.getUserID(traceID);
		passwd = userProfile.getUserPWD(traceID);
        hkid = userProfile.getHKID(traceID);
        tokenHKID= userProfile.getTokenHKID(traceID);
		wsmSeqNoInUserProfile = userProfile.getSeqNo(traceID);

		HTML_TemplateBaseDir = getTemplateBaseDir(language, traceID);
    HTML_ErrorTemplateBaseDir = getErrorTemplateBaseDir(language, traceID);

logger.log(traceID, LogConst.SEV_WARNING, className + ": getParametersFromUserProfile: tokenid" + tokenHKID);

	}

    /**
     * Method appendVList
     * Append v2 to v1.
     */
	protected boolean appendVList(Vector v1, Vector v2, String traceID)
	{
    int i;

		if ((v1 == null) || (v2 == null))
		{
			return false;
		}

		logger.log(traceID, LogConst.SEV_INFO, className + ": appendVList: org size:v1: " + v1.size() + ", v2: " + v2.size());

		if (v2.size() == 0)
		{
			return true;
		}

		for (i=0; i<v2.size(); i++)
		{
			v1.addElement(v2.elementAt(i));
		}

		logger.log(traceID, LogConst.SEV_INFO, className + ": appendVList: after size:v1: " + v1.size());

		return true;

	}

    /**
     * Method addItemToSelectionList
     * A common method to add a list of info to the variable: userInfoList (the selection list to be
     * shown on HTML page)
     */
	protected void addItemToSelectionList(Vector list)
	{
		int i;

		logger.log(traceID, LogConst.SEV_INFO, className + ": addItemToSelectionList starts");

		if ((list == null) || (list.isEmpty()))
		{
			logger.log(traceID, LogConst.SEV_INFO, className + ": addItemToSelectionList: empty list");
			return;
		}

		for (i=0; i<list.size(); i++)
		{
			userInfoList.addElement(list.elementAt(i));
		}

		logger.log(traceID, LogConst.SEV_INFO, className + ": addItemToSelectionList: userInfoList size after adding: " + userInfoList.size());
	}

    /** 
     * Method addWSM_SeqNo - Insert a new WSM Seq No to the HTML page
     */
	protected String addWSM_SeqNo(Vector rspInfo, String traceID)
	{
		String nxt = null;
		Vector tv = new Vector(2);

		if (rspInfo == null)
		{
			logger.log(traceID, LogConst.SEV_WARNING, className + ": addWSM_SeqNo: rspInfo is null");
			errCode = TransactionException.EC_SYSTEM_ERROR;
			return nxt;
		}
		try {
			nxt = webSessConnector.getNextSeqNumber(traceID);

			tv.addElement(CommConst.WSM_SEQ_NO);
			tv.addElement(nxt);
			rspInfo.addElement(tv);

			// store the new number in userProfile.
			userProfile.setSeqNo(nxt, traceID);
			return nxt;
		}
		catch (TransactionException e)
		{
			logger.log(traceID, LogConst.SEV_ROUTINE, className + ": addWSM_SeqNo: Transaction Exception: " + e.toString());
			errCode = e.getErrorNumber();
			return nxt;
		}
		catch (Exception e)
		{
			logger.log(traceID, LogConst.SEV_ERROR, className + ": addWSM_SeqNo: Exception: " + e.toString());
			errCode = TransactionException.EC_SYSTEM_ERROR;
			return nxt;
		}
	}

	protected void chkWSM_SeqNo(String traceID)
	{
		wsmSeqNoFromBrowser = parameterWsmSeqNo;

		logger.log(traceID, LogConst.SEV_INFO, className + ": chkWSM_SeqNo starts");

		errCode = TransactionException.EC_SUCCESS;

		if (chkIfIsOnErr(traceID))
		{
			logger.log(traceID, LogConst.SEV_INFO, className + ": chkWSM_SeqNo: handle request from Error page: no need to check WSM Seq No");
			return;
		}
		if (!reqToChkWSM_SeqNo)
		{
			logger.log(traceID, LogConst.SEV_INFO, className + ": chkWSM_SeqNo: no need to check WSM Seq No");
			return;
		}

		if (wsmSeqNoFromBrowser == null)
		{
			logger.log(traceID, LogConst.SEV_INFO, className + ": chkWSM_SeqNo: No WSM_SeqNo from the browser");
			errCode = TransactionException.EC_INVALID_WSC_SEQ_NO;
			return;
		}

		if (wsmSeqNoInUserProfile.equals(wsmSeqNoFromBrowser))
		{
			logger.log(traceID, LogConst.SEV_INFO, className + ": chkWSM_SeqNo: WSM Seq No are matched");
			errCode = TransactionException.EC_SUCCESS;
			return;
		}
		logger.log(traceID, LogConst.SEV_INFO, className + ": chkWSM_SeqNo: WSM_SeqNo is not matched. Profile: " + wsmSeqNoInUserProfile + ", Browser: " + wsmSeqNoFromBrowser);
		errCode = TransactionException.EC_INVALID_WSC_SEQ_NO;
		return;
	}

	protected boolean chkIfIsOnErr(String traceID)
	{
		if (parameterErrFlag == null)
		{
			return false;
		}
		return true;
	}

    //------------------------------------------------------------------------
    // Servlet using getRspInfoFromHost method for submitting req must implement
    // the following two methods.
    //------------------------------------------------------------------------

    /**
     * Method composeHostReq - A default method to compose Host req message (do nothing)
     */
	protected Vector composeHostReq(String traceID)
	{
		logger.log(traceID, LogConst.SEV_INFO, className + ": composeHostReq: perform default parent method");
		return null;
	}

    /**
     * Method submitReq - A default method to submit req message to Host (do nothing)
     */
	protected Vector submitReq(Vector reqList, String traceID)
	{
		logger.log(traceID, LogConst.SEV_INFO, className + ": submitReq: perform default parnet method");
		return null;
	}

    /**
     * Method submitReq - a common function to send req message to Host and get back response.
     */
	protected Vector submitReq(Vector reqInfo, String trxCode, String traceID)
	{
		Vector result = null;
		Request toHostReq;

		logger.log(traceID, LogConst.SEV_INFO, className + ": submitReq starts");
		errCode = TransactionException.EC_SUCCESS;

        // Check transaction availiablity
        if (this.reqToChkAvailability) {
            if (!trxAvail.isAvailable(responsibleTrx, traceID)){
                logger.log(traceID, LogConst.SEV_WARNING, this.getClass().getName() + ": submitReq Failed: transaction not allowed");
                errCode = TransactionException.EC_TRANSACTION_NOT_ALLOW;
                return result;
            }
        }
        
		// send to eTrx server
		try {
			//toHostReq = new Request(reqInfo, bbpID, trxCode, userProfile.getSessionID(traceID), httpReq.getRemoteAddr(), traceID);
			toHostReq = new Request(reqInfo, bbpID, trxCode, userProfile.getSessionID(traceID), getIpAddressFromRequest(httpReq, traceID), traceID);
            //secureECertTrx(trxCode);
			Response rsp = webSessConnector.handleRequest(toHostReq, traceID);
			errCode = rsp.getReturnCode();
			if (errCode != TransactionException.EC_SUCCESS)
			{
				logger.log(traceID, LogConst.SEV_WARNING, className + ": submitReq: Failed to process req: " + errCode);
			}
			else
			{
				logger.log(traceID, LogConst.SEV_ROUTINE, className + ": submitReq: Get back response from host");
				result = rsp.getContent();
				return result;
			}
		}
		catch (TransactionException e)
		{
			logger.log(traceID, LogConst.SEV_WARNING, className + ": submitReq: Transaction Exception: " + e.getMessage());
			errCode = e.getErrorNumber();
		}
		catch (Exception e)
		{
			logger.log(traceID, LogConst.SEV_WARNING, className + ": submitReq: Exception: " + e.getMessage());
			errCode = TransactionException.EC_SYSTEM_ERROR;
		}
		logger.log(traceID, LogConst.SEV_ROUTINE, className + ": submitReq finished");
        return result;
	}

    /**
     * Method getParameterValue
     * Extract info from the parameter table 
     * (storing all parameters posted together with the HTML page).
     */
	protected String getParameterValue(String name)
	{
		String value = null;
		if (parameterTbl.containsKey(name))
		{
			value = (String)parameterTbl.get(name);
		}
		return value;
	}

    /**
     * Method genRefRspNo - Generate Response Reference No. to be shown in the response HTML page.
     * 
     */
	protected String genRefRspNo(String traceID)
	{
		return hTrxNum.getNextNumber();
	}

    /**
     * Method addLanguageToList - Add Response Reference No. in the response HTML page.
     */
	protected boolean addLanguageToList(Vector list, String language, String traceID)
	{
		Vector tv;

		if ((list == null) || (language == null))
		{
			return false;
		}

		tv = new Vector(2);
		tv.addElement(CommConst.COM_FLD_SELECT_LANGUAGE);
		tv.addElement(this.language);
		list.addElement(tv);

		return true;
	}
	
    /**
     * Method addCustomerNameToList - Add Response customer name in the response HTML page.
     */
	protected boolean addCustomerNameToList(Vector list, String customerName, String traceID)
	{
		Vector tv;
		// revamp debug Prashant

		if ((list == null) || (customerName == null))
		{
			return false;
		}

		tv = new Vector(2);
		tv.addElement(CommConst.CID_FLD_CUST_NAME);
		tv.addElement(customerName);
		list.addElement(tv);

		return true;
	}
	
	/**
     * MEthod addLastLoginTimeToList
     * Add Response last login time in the response HTML page.
     */

	protected boolean addLastLoginTimeToList(Vector list, String lastLoginTime, String traceID)
	{
		Vector tv;

		if ((list == null) || (lastLoginTime == null))
		{
			return false;
		}

		tv = new Vector(2);
		tv.addElement("CID_FLD_LAST_LOGIN");
		tv.addElement(lastLoginTime);
		list.addElement(tv);

		return true;
	}
		

	protected boolean addSvcFunctionNameToList(Vector list, String lang, String hostTrxCode, String traceID)
	{
		Vector item = null;
        String funDesp;

		try {
			if (list == null)
			{
				return false;
			}

			if (hostTrxCodeDespTbl == null)
			{
				loadConfigTbl(HOST_TRX_CODE_DESP_CONFIG_IDX, traceID);
			}
			funDesp = hostTrxCodeDespTbl.getDescription(hostTrxCode, lang, traceID);
			item = new Vector(2);
			item.addElement(CommConst.COM_FLD_TRX_SERVICE);
			item.addElement(funDesp);
			list.addElement(item);

            return true;
		}
		catch (Exception e)
		{
			logger.log(traceID, LogConst.SEV_WARNING, className + ": addSvcFunctionNameToList: Exception: " + e.toString());
			return false;
		}
	}

	protected boolean addRspRefNoToList(Vector list, String rspRefNo, String traceID)
	{
		Vector tv;
		if (list == null)
		{
			logger.log(traceID, LogConst.SEV_WARNING, className + ": addRspRefNoToList: input list is null");
			return false;
		}

		try {
			if (rspRefNo == null)
			{
				logger.log(traceID, LogConst.SEV_WARNING, className + ": addRspRefNoToList: rspRefNo is null");
				return false;
			}
			tv = new Vector(2);
			tv.addElement(rspRefNoTag);
			tv.addElement(rspRefNo);
			list.addElement(tv);

			return true;
		}
		catch (Exception e)
		{
			logger.log(traceID, LogConst.SEV_ERROR, className + ": addRspRefNoToList: Exception: " + e.toString());
			return false;
		}
	}

	protected boolean addOkServletNameToList(Vector list, String servletName, String traceID)
	{
		Vector tv;
		if (list == null)
		{
			logger.log(traceID, LogConst.SEV_WARNING, className + ": addOkServletNameToList: input list is null");
			return false;
		}

		try {
			if (servletName == null)
			{
				logger.log(traceID, LogConst.SEV_WARNING, className + ": addOkServletNameToList: servletName is null");
				return false;
			}
			tv = new Vector(2);
			tv.addElement(handleOkServletNameTag);
			tv.addElement(CommonConst.SERVLET_HOME + servletName);
			list.addElement(tv);

			return true;
		}
		catch (Exception e)
		{

			logger.log(traceID, LogConst.SEV_ERROR, className + ": addOkServletNameToList: Exception: " + e.toString());
			return false;
		}
	}

	protected String getRspRefNoFromList(Vector list, String traceID)
	{
		return getRspRefNoFromList(list, rspRefNoTag, traceID);
	}

	protected String getRspRefNoFromList(Vector list, String tag, String traceID)
	{
		String rspRefNo;
		ContentReader cr;

		if (list == null)
		{
			return null;
		}

		try {
			cr = new ContentReader(list, traceID);
			rspRefNo = (String)cr.getContent(tag, CommConst.MSGPOS_CONTENT, traceID);
			return rspRefNo;
		}
		catch (Exception e)
		{
			logger.log(traceID, LogConst.SEV_ERROR, className + ": getRspRefNoFromList: Exception: " + e.toString());
			return null;
		}
    }

    /**
     * Method getAccTypeDescription
     * A common routine to map the accType to human description.
     */
    protected String getAccTypeDescription(String traceID)
    {
        return getAccTypeDescription(accType, productCode, traceID);
    }

    protected String getAccTypeDescription(String accType, String productCode, String traceID)
    {
        String description;
    
        errCode = TransactionException.EC_SUCCESS;
        if (accTypeTbl == null)
        {
            loadConfigTbl(ACC_TYPE_CONFIG_IDX, traceID);
        }
    
        if (errCode != TransactionException.EC_SUCCESS)
        {
            return "";
        }
    
        try {
            description = accTypeTbl.getDescription(accType, productCode, language, traceID);
            logger.log(traceID, LogConst.SEV_ROUTINE, className + ": getAccTypeDescription: for accType: " + accType + ", productCode: " + productCode + " is: " + description);
            return description;
        }
        catch (Exception e)
        {
            logger.log(traceID, LogConst.SEV_ERROR, className + ": getAccTypeDescription: for accType: " + accType + ": Exception: " + e.toString());
            e.printStackTrace();
            return "";
        }
    }
    
    protected boolean addTrxAvailabilityInfoToList(Vector list, String traceID)
    {
        if (userProfile != null)
        {
                userProfile.getTrxAvailability(list, traceID);
        }
        return true;
    }

    protected boolean addInfoToUserProfile(UserProfile usrProfile, Vector toHostReq, Vector confirmInfo, String traceID)
    {
        Vector i = new Vector(2);
        i.insertElementAt(toHostReq, ToHostReqIndex);
        i.insertElementAt(confirmInfo, ConfirmInfoIndex);
        usrProfile.setReqInfo(i, traceID);
        return true;
    }

    protected Vector getInfoFromUserProfile(UserProfile usrProfile, int index, String traceID)
    {
        Vector i = usrProfile.getReqInfo(traceID);
        
        if ((i == null) || (index >= i.size()))
            return null;
        return (Vector)i.elementAt(index);
    }

    protected String genErrorPageFileName(String orgFileName, int errno, String traceID)
    {
        int index = 0;
        String errFile = null;
            ErrorPage ep;
            try
        {
            ep = ErrorPage.getInstance(traceID);
          errFile = orgFileName.toLowerCase();
                index = errFile.lastIndexOf(".html");
          return (orgFileName.substring(0, index) + ep.getErrorPageSuffix(errno, traceID) + orgFileName.substring(index));
            }
            catch (Exception e)
        {
          return orgFileName;
        }
    }
    //--------------------------------------------------------------------------
    // Ref20040304.1   (start) Refresh Acc Balance and update to accsummary list
    //--------------------------------------------------------------------------

    //--------------------------------------------------------------------------
    // Commented by Yan(CTIL)
    // Original codes in initialize() only for baseDir, no longer required
    //--------------------------------------------------------------------------
    /*
	protected void initialize()
	{
    */
	/*
		htmlFileName = null;
		errHtmlFileName = null;
		responsibleTrx = null;
		handleErrServletName = null;
		handleOkServletName = null;

	// Servlet Parameters
		httpSession = null;
		httpReq = null;
		httpRsp = null;

		storedList = null;

	// Variables store the value of the above HTML input.
		parameterAccInfo = null;
		parameterWsmSeqNo = null;
		parameterErrFlag = null;

	// Variable store the UserProfile info.
		userProfile = null;
		userProfileSessionKey = null;

	// The following 5 parameters are extracted from UserProfile
		bbpID = null;
		passwd = null;

// language is already initialized with the value stored in Cookie
//		language = CommonConst.SYS_DEF_LANG;
		traceID = CommonConst.SYS_TRACEID;
		wsmSeqNoInUserProfile = null;

	// The WSM Seq No sent from Browser.
		wsmSeqNoFromBrowser = null;

	// Used to store the list of account types for user selection.
		selectAccTypeList = null;

	// Used to store the Selection List (in TV form) for showing on HTML page.
		userInfoList = null;     // Selection List

	// Used to store the selected account info from the selection list in the HTML page.
		selectedIdx = null;
		accType = null;
		productCode = null;
		accNo = null;
		accRefNo = null;
		accCcy = null;

		toSelectedIdx = null;
		toAccType = null;
		toProductCode = null;
		toAccNo = null;
		toAccRefNo = null;
		toAccCcy = null;

		rspPageRefNo = null;
		
		accTypeTbl = null;
		appSetupTbl = null;
		branchTbl = null;
		ccyRefTbl = null;
		hkdFeeTbl = null;
		holidayTbl = null;
		loanTypeTbl = null;
		tenorTbl = null;
		trxAccessTbl = null;
		trxAvailTbl = null;
		trxCodeDespTbl = null;

	// Used to control if the parameters sent from Browser to be shown in the debug log.
		showBrowserParameters = true;

	// Other Class global variables
		trxAvail = null;
		parameterTbl = null;

		bankAccType = null;
		hTrxNum = null;
		reqToChkWSM_SeqNo = false;
		reqToChkAccessibility = false;
		reqMcssaSelectionList = true;   // get expanded Mcssa Selection List
		reqFullSelectionList = false;
		reqFilterCcy = "";

		markSelectionTag = CommConst.SELECTION_FLD_MARK_INDEX_NUM;
		htmlFmt = null;
		errCode = TransactionException.EC_SUCCESS;

		webSessConnector = null;
    */
	/*

		HTML_TemplateBaseDir = getTemplateBaseDir(language, traceID);
	    HTML_ErrorTemplateBaseDir = getErrorTemplateBaseDir(language, traceID);

	}    
    */
	
    
	protected void updateRefreshAcBalWB(String inAccNo, String inCcy, String inAccType, String traceID)
	{
        logger.log(traceID, LogConst.SEV_WARNING,  className + ": updateRefreshAcBal (start) inAccNo:" + inAccNo + ", inCcy:" + inCcy + ", inAccType:" + inAccType);		
		Vector tv;
		Vector toHostReqInfo, accInfo;
		Request toHostReq;
		VecList vecList = new VecList();
		int j;
		String ccy;
		String accType;
		String accNo;
		String userID 	= userProfile.getUserID(traceID);
		byte[] userPWD 	=	userProfile.getUserPWD(traceID);	
		Vector acctSummaryList;
		Vector tmpVec = new Vector();
		//ContentReader CRacctSummaryList;
		acctSummaryList = userProfile.getAcctSummary(traceID);
        ContentReader crAcc = null;  
        crAcc = new ContentReader(acctSummaryList, traceID);


        // Submit INQ Message to Host
        logger.log(traceID, LogConst.SEV_WARNING,  className + ": updateRefreshAcBal :Submit INQ Message to Host");		
        String bal = "-"; 
        String sign = " ";
		toHostReqInfo = composeHostINQReqWB(userID, userPWD, inAccNo, inCcy, inAccType, traceID);
		//toHostReq = new Request(toHostReqInfo, userID, ConfigConst.TRX_INQ, userProfile.getSessionID(traceID), httpReq.getRemoteAddr(), traceID);
		toHostReq = new Request(toHostReqInfo, userID, ConfigConst.TRX_INQ, userProfile.getSessionID(traceID), getIpAddressFromRequest(httpReq, traceID), traceID);

		// send to eTrx server
		try 
		{
			Response rsp = webSessConnector.handleRequest(toHostReq, traceID);
			errCode = rsp.getReturnCode();
           // get element id for Avail Balance
   		   if (isHostErrorWB(errCode))
		   {
			  bal = "-";
			  sign = " ";
			  errCode = TransactionException.EC_SUCCESS;
            } else {
    		  tv = rsp.getContent();
			  ContentReader cr = new ContentReader(tv, traceID);
						
			  bal = (String)cr.getContent(CommConst.INQ_FLD_AVA_BAL, CommConst.MSGPOS_CONTENT, (short)1, traceID);					
//			  sign = (String)cr.getContent(CommConst.INQ_FLD_SIGN_OF_AVA_BAL, CommConst.MSGPOS_CONTENT, (short)1, traceID);            	
            }	
         } catch (Exception e) {
           logger.log(traceID, LogConst.SEV_WARNING,  className + ": updateRefreshAcBal :Submit INQ Message to Host Exception e:" + e.toString());		
           errCode = TransactionException.EC_SUCCESS;
         }	    
         
		 /* Update balace in acctSummaryList */		
		try {
		  logger.log(traceID, LogConst.SEV_WARNING,  className + ": updateRefreshAcBal :Update balace in acctSummaryList");		
		  for(j=0; j<acctSummaryList.size(); j++)
		  {
			
			accNo = (String) crAcc.getContent(CommConst.INQ_FLD_TRX_ACC_NO, CommConst.MSGPOS_CONTENT, (short) (j+1) , traceID);
			ccy = (String) crAcc.getContent(CommConst.INQ_FLD_CURR_CODE, CommConst.MSGPOS_CONTENT, (short) (j+1) , traceID);
			accType = (String) crAcc.getContent(CommConst.INQ_FLD_TRX_ACC_TYPE, CommConst.MSGPOS_CONTENT, (short) (j+1) , traceID);
		    if (accNo.equals(inAccNo) && ccy.equals(inCcy) && accType.equals(inAccType))
		    {
		        //logger.log(traceID, LogConst.SEV_WARNING,  className + ": updateRefreshAcBal Refresh Ac " + accNo + ", AcType: " + accType + ", AcCcy: " + ccy);		
				replaceItemValue(acctSummaryList, CommConst.INQ_FLD_AVA_BAL, bal, Integer.toString(j+1), traceID);
//				replaceItemValue(acctSummaryList, CommConst.INQ_FLD_SIGN_OF_AVA_BAL, sign, Integer.toString(j+1), traceID);
				break;
			}	
           }
         } catch (Exception e) {
           logger.log(traceID, LogConst.SEV_WARNING,  className + ": updateRefreshAcBal :Update balace in acctSummaryList Exception e:" + e.toString());		
           errCode = TransactionException.EC_SUCCESS;         	
         }	

         /* Update balace in accBal */		                  
        try { 
          logger.log(traceID, LogConst.SEV_WARNING,  className + ": updateRefreshAcBal :Update balace in accBal");
          Vector accBal;
          accBal = userProfile.getAccountAvailBal(traceID);
         
		  for(j=0; j<accBal.size(); j++)
		  {
			
			accInfo = (Vector)accBal.elementAt(j);
			accType = (String)accInfo.elementAt(3);
	    	accNo	= (String)accInfo.elementAt(0);
			ccy		= (String)accInfo.elementAt(4);

		    if (accNo.equals(inAccNo) && ccy.equals(inCcy) && accType.equals(inAccType))
		    {
				accInfo.setElementAt(bal,1); // balance //
//				accInfo.setElementAt(sign,2);// sign //
				break;
			}	
           }
         } catch (Exception e) {
           logger.log(traceID, LogConst.SEV_WARNING,  className + ": updateRefreshAcBal :Update balace in accBal Exception e:" + e.toString());		
           errCode = TransactionException.EC_SUCCESS;
         }	   

        logger.log(traceID, LogConst.SEV_WARNING,  className + ": updateRefreshAcBal (end)");		
        

	} 
	
	protected boolean isHostErrorWB(int errCode)
	{
		int HOST_MAX_ERR = 5000;
		if (errCode <= HOST_MAX_ERR)
		{
			return true;
		}
		return false;
	}	
	
	protected Vector composeHostINQReqWB(String BBP_Id, byte [] passwd, String accNo, String ccy, String accType, String traceID)
	{
		int cnt = 0;
		Vector req = new Vector();
		Vector tv;

		logger.log(traceID, LogConst.SEV_ERROR, this.getClass().getName() + ": composeHostINQReqWB starts");

		errCode = TransactionException.EC_SUCCESS;

        // Trx Code
		tv = new Vector(2);
		tv.addElement(CommConst.INQ_FLD_TRX_CODE);
		tv.addElement(ConfigConst.TRX_INQ);
		req.addElement(tv);

        // BBP ID
		tv = new Vector(2);
		tv.addElement(CommConst.INQ_FLD_CUST_ID);
		tv.addElement(BBP_Id);
		req.addElement(tv);

        // Passwd
		tv = new Vector(2);
		tv.addElement(CommConst.INQ_FLD_PWD);
		tv.addElement(passwd);
		req.addElement(tv);

        // Acc No
		tv = new Vector(2);
		tv.addElement(CommConst.INQ_FLD_TRX_ACC_NO);
		tv.addElement(accNo);
		req.addElement(tv);

        // Ccy
		tv = new Vector(2);
		tv.addElement(CommConst.INQ_FLD_CURRENCY);
		tv.addElement(ccy);
		req.addElement(tv);

        // Multi-Ccy flag
		tv = new Vector(2);
		tv.addElement(CommConst.INQ_FLD_MULTI_CURR_FLAG_FOR_TRX_ACC);
		tv.addElement(CommConst.INQ_FLD_DUMMY);
		req.addElement(tv);

        // Acc Type
		tv = new Vector(2);
		tv.addElement(CommConst.INQ_FLD_TRX_ACC_TYPE);
		tv.addElement(accType);
		req.addElement(tv);

		logger.log(traceID, LogConst.SEV_ERROR, this.getClass().getName() + ": composeHostINQReqWB finished");

		return req;
	}	

   

    protected void replaceItemValue(Vector acctSummaryList, String aItem, String aKey, String aRow, String traceID) throws TransactionException 
    {
        //logger.log(traceID, LogConst.SEV_ERROR, "replaceItemValue (Start) aItem:" + aItem + ", aKey:" + aKey + ", aRow:" + aRow);
        
        String l_value = null;
        Vector tmpItemVec = new Vector(0);
        tmpItemVec = null;
        int itemPos = 0, keyPos = 1, itemRow = 2;
        if (!acctSummaryList.isEmpty()) {
          for (int i = 0; i < acctSummaryList.size(); i++) {
            tmpItemVec = (Vector)acctSummaryList.elementAt(i);
            if (tmpItemVec.elementAt(itemPos).equals(aItem) &&
                tmpItemVec.elementAt(itemRow).equals(aRow)) {
              tmpItemVec.setElementAt(aKey,keyPos);
              break;
            } // end if
          } // end for
        } // end if
        else {
          logger.log(traceID, LogConst.SEV_ERROR, "VecList:replaceItemValue: Invalid Input");
          throw new TransactionException(TransactionException.EC_INVALID_MSG_CONTENT_ERR, "VecList:replaceItemValue: Invalid Input");
        }
        
        //System.out.println("aVector from replace : " + aVector);
    }
    //--------------------------------------------------------------------------
    // * Ref20040304.1   (end)  */
    //--------------------------------------------------------------------------


    protected void isSuspend (String classname, String traceID) 
    {
    
        try {
            errCode = TransactionException.EC_SUCCESS;            
            SuspendPgmInstance mySuspendPgmImage = SuspendPgmInstance.getInstance(traceID);            
            String programId = classname;
            
            while (programId.indexOf('_') != -1) {
                programId = programId.substring(0, programId.indexOf('_'))
                            + programId.substring(programId.indexOf('_') + 1, programId.length());
            }
            
            programId = programId.substring(programId.lastIndexOf(".") + 1);
    
            if (mySuspendPgmImage.isSuspend(programId, traceID)) {
                logger.log(traceID, LogConst.SEV_WARNING,  className + ": isSuspend: " + classname + " is to be suspended");
                errCode = TransactionException.EC_FUNCTION_SUSPEND;
                
                
				if (language.equals(CommonConst.LANG_TRADITIONAL_CHINESE)) {
					this.suspendMessage = mySuspendPgmImage.getTradChiMsg();
				} if (language.equals(CommonConst.LANG_SIMPLIFIED_CHINESE)) {
					this.suspendMessage = mySuspendPgmImage.getSimpChiMsg();
				}else if (language.equals(CommonConst.LANG_ENGLISH)) {
					this.suspendMessage = mySuspendPgmImage.getEngMsg();
				}
                
            }

        } catch (Exception e) {
            logger.log(traceID, LogConst.SEV_ERROR, className + ": isSuspend: exception in checking for suspension - " + e.toString());
            //errCode = TransactionException.EC_FUNCTION_SUSPEND;                
        }
    
    }


    /**
     * Method getTraceID - Added by Yan(CTIL)
     * @return String
     * 
     */
     public String getTraceID(){
        return traceID;  
     }
                            
    /**
     * Method getTrxErrMsg() - Added by Yan(CTIL)
     * Return error message based on configuration and locale
     * @param int errno
     * @return String errMsg
     *      
     */
    public String getTrxErrMsg( int errno ){
		if (language.equals(CommonConst.LANG_TRADITIONAL_CHINESE)) {
			if(httpReq != null)	Config.set( httpReq , Config.FMT_LOCALE ,  "zh_TW" ); 
		} else if (language.equals(CommonConst.LANG_SIMPLIFIED_CHINESE)) {
			if(httpReq != null)	Config.set( httpReq , Config.FMT_LOCALE ,  "zh_CN" ); 
		} else if (language.equals(CommonConst.LANG_ENGLISH)) {
			if(httpReq != null)	Config.set( httpReq , Config.FMT_LOCALE ,  "en" ); 
	    }
        String mesg = "";       	
        try{
            if (errno == TransactionException.EC_FUNCTION_SUSPEND) {
                return this.suspendMessage;
            }      	
             TrxErrorCodeConfig txnErrCfg = TrxErrorCodeConfig.getInstance( null, traceID );  
             
             if (errMsgVarMap != null && errMsgVarMap.size() > 0) {		// PRJ2605 - EPSCO Bill Payment 20090908
            	 mesg   = txnErrCfg.getErrorMessage( errno , language , errMsgVarMap, traceID );            	 
             } else {
            	 mesg   = txnErrCfg.getErrorMessage( errno , language , traceID );  
             }
             
        }catch(LoadConfigException lce){        
            logger.log( traceID, LogConst.SEV_ERROR , "getTrxErrMsg:Fail to load TxnErrCodeConfig["+lce+"]");            
        }
        
        return mesg;
    }

    /**
     * Get a transaction error message with parameter filled in.
     * eg. For Error Message 1234 "My account number is ${accNo}"
     * getTrxErrMsg(1234, {accNo: 45678}) will returns "My account number is 45678"
     * 
     * @param errno
     * @param params
     * @return
     */
    public String getTrxErrMsg(int errno, Map<String, String> params){
    	//PRJ2529 - Simplified Chinese
		if (language.equals(CommonConst.LANG_TRADITIONAL_CHINESE)) {
			Config.set( httpReq , Config.FMT_LOCALE ,  "zh_TW" ); 
		} else if (language.equals(CommonConst.LANG_SIMPLIFIED_CHINESE)) {
			Config.set( httpReq , Config.FMT_LOCALE ,  "zh_CN" ); 
		} else if (language.equals(CommonConst.LANG_ENGLISH)) {
			Config.set( httpReq , Config.FMT_LOCALE ,  "en" ); 
		}
    	
        String mesg; 
        try{
            TrxErrorCodeConfig txnErrCfg = TrxErrorCodeConfig.getInstance( null, traceID );   
             
            mesg = txnErrCfg.getErrorMessage( errno , language , params, traceID );            	 
        }catch(LoadConfigException lce){        
            logger.log( traceID, LogConst.SEV_ERROR , "getTrxErrMsg:Fail to load TxnErrCodeConfig["+lce+"]");
            mesg = "";
        }
        
        return mesg;


    }
    
    public String getTrxErrMsg()
    {
    	return getTrxErrMsg(this.getErrorCode());
    }      
    
    
    /**
     * Method getTrxPagIdx() - Added by Yan(CTIL)
     * @param int errno
     * @return String pagIdx
     *      
     */                            
    public String getTrxPagIdx( int errno ){

        String pagIdx = "";    
    
        try{
            TrxErrorCodeConfig txnErrCfg = TrxErrorCodeConfig.getInstance( null, traceID );

            pagIdx = txnErrCfg.getErrorPageSuffix( errno , traceID );
                    
            
        }catch(LoadConfigException lce){
            
            logger.log( traceID, LogConst.SEV_ERROR , "PinChangeController::actionPinChange::Fail to load TxnErrCodeConfig["+lce+"]");
            
        }	
        
        return pagIdx;
    }                                 
                                 

    public Vector getTrxAvailability(Vector list, String traceID)
    {
        if (userProfile != null)
        {
                userProfile.getTrxAvailability(list, traceID);
        }
        
        return list;
    }


     public Vector genAccountList(String traceID)      {
        
        errCode = loadConfigTbl(ACC_TYPE_CONFIG_IDX, traceID);
        if (errCode == TransactionException.EC_SUCCESS) {
        ContentReader cr = new ContentReader();
        Vector accountVec = new Vector();
        Vector accountList = new Vector();
        Vector vec = new Vector();
        String accountNo = "";
        String accountDesc = "";
        String accountCcy = "";
        String accountType = "";
        String accountIndex = "";
        String accountBal = "";
        String accountBalSign = "";
        String accountProdCode = "";
        String accountFullDesc = "";        
        
        cr = new ContentReader(userInfoList, traceID);
        short i = 1;
        while (accountNo != null) {
            accountNo = (String) cr.getContent(CommConst.SELECTION_FLD_ACCT_NO, CommConst.MSGPOS_CONTENT, i, traceID);
            accountCcy = (String) cr.getContent(CommConst.SELECTION_FLD_ACCT_CURR, CommConst.MSGPOS_CONTENT, i, traceID);
            accountType = (String) cr.getContent(CommConst.SELECTION_FLD_ACCT_TYPE, CommConst.MSGPOS_CONTENT, i, traceID);
            accountIndex = (String) cr.getContent(CommConst.SELECTION_FLD_INDEX_NUM, CommConst.MSGPOS_CONTENT, i, traceID);
            accountBal = (String) cr.getContent(CommConst.SELECTION_FLD_AVAIL_BALANCE, CommConst.MSGPOS_CONTENT, i, traceID);
            accountBalSign = (String) cr.getContent(CommConst.SELECTION_FLD_AVAIL_BALANCE_SIGN, CommConst.MSGPOS_CONTENT, i, traceID);
            accountProdCode = (String) cr.getContent(CommConst.SELECTION_FLD_ACCT_PRODUCT_CODE, CommConst.MSGPOS_CONTENT, i, traceID);  
            
            if (accountType !=null && accountProdCode !=null) {
                accountDesc = accTypeTbl.getDescription(accountType, accountProdCode, language, traceID);
            }   
            if (accountDesc == null) accountDesc = ""; 

            if (accountNo != null && accountDesc != null && accountCcy != null && accountType !=null) {
                accountFullDesc = accountCcy + " " + accountDesc + " " + accountNo;
                vec = new Vector();
                vec.add(accountNo);
                vec.add(accountDesc);
                vec.add(accountCcy);
                vec.add(accountType);                         
                vec.add(accountIndex);
                vec.add(accountBal);
                vec.add(accountBalSign);                
                vec.add(accountProdCode);
                vec.add(accountFullDesc);                
                accountVec.add(vec);
            }
            i++;                             
        } //end while                
        
        //accountList.add(accountVec);
        return accountVec;
        }
        return new Vector();
     }

    public Vector addAccountListToVec(Vector list, String traceID)
    {
        Vector tempVec = new Vector();
        tempVec.add(CommConst.SELECTION_FLD_ACCT_LIST);
        tempVec.add(genAccountList(traceID));
        list.add(tempVec);
        return list;
    }
    
    public void setAccountVec(){
        accountVec = genAccountList(traceID);
    }    

    public Vector getAccountVec() {
        return this.accountVec;
    }  

    public int getErrorCode(){
        return errCode;
    }

    public void setErrorCode(int err){
        errCode = err;
    }

    public void setTransactionAvailablilty() {
        Vector tempVec = new Vector();
        try
        {
            logger.log(traceID,LogConst.SEV_ROUTINE, "setTransactionAvailablilty start");
            TrxAvailability.getInstance(traceID).genNowAccessibleTrxInTV(tempVec, this.userProfile, traceID);
            ContentReader cr = new ContentReader(tempVec, traceID);                 
            this.transactionAvailablity = (String)cr.getContent("AllowTrx", CommConst.MSGPOS_CONTENT, traceID);        
            logger.log(traceID,LogConst.SEV_ROUTINE, "setTransactionAvailablilty end");
            
        }
        catch (LoadConfigException lce)
        {
            logger.log(traceID,LogConst.SEV_ERROR, "setTransactionAvailablilty Exception (lce):" + lce.toString());
        }    
    }    
    
    public String getTransactionAvailablilty(){
        return this.transactionAvailablity;
    }  
    

     public boolean checkAccountExist(String inAccountNo, String traceID)      {
        
        ContentReader cr = new ContentReader();
        String accountNo = "";
        
        cr = new ContentReader(userInfoList, traceID);
logger.log( traceID, LogConst.SEV_ERROR , "checkAccountExist:" + cr.toString());        
        short i = 1;
        while (accountNo != null) {
            accountNo = (String) cr.getContent(CommConst.SELECTION_FLD_ACCT_NO, CommConst.MSGPOS_CONTENT, i, traceID);
            if (accountNo == null) {
                return false;
            } else {
                if (accountNo.equals(inAccountNo)){
                    return true;
                }
            }
            i++;                
        }
        return false;
     }

     public String getAccountIndex(String inAccountNo, String traceID)      {
        
        ContentReader cr = new ContentReader();
        String accountNo = "";
        
        cr = new ContentReader(userInfoList, traceID);
        logger.log( traceID, LogConst.SEV_ERROR , "getAccountIndex:" + cr.toString());        
        short i = 1;
        while (accountNo != null) {
            accountNo = (String) cr.getContent(CommConst.SELECTION_FLD_ACCT_NO, CommConst.MSGPOS_CONTENT, i, traceID);
            if (accountNo == null) {
                return "";
            } else {
                if (accountNo.equals(inAccountNo)){
                    return (String) cr.getContent(CommConst.SELECTION_FLD_INDEX_NUM, CommConst.MSGPOS_CONTENT, i, traceID);
                }
            }
            i++;                
        }
        return "";
     }

	public SQLActionResult executeSQL(SQLAction action, String traceID) throws TransactionException, Exception
	{
		Vector content = null;
		Response rsp = null;
		Request req = null;
		Vector item = null;
		VecList vecList = new VecList();

		content = new Vector();
		//    vList.addItem(content, CommConst.FLD_TRX_ID, l_trxID, traceID);
		vecList.addItem(content, CommConst.COM_FLD_PWD, "0000000000000000", traceID);
		vecList.addItem(content, CommConst.COM_FLD_CUST_ID, "0000000000", traceID);

		item = new Vector(2);
		item.addElement(CommConst.BANK_APP_ACTION_REQ);
		item.addElement(action);
		content.addElement(item);


		try {
            //req = new Request(content, bbpID, ConfigConst.TRX_NONHOSTWB, userProfile.getSessionID(traceID), httpReq.getRemoteAddr(), traceID);
			req = new Request(content, bbpID, ConfigConst.TRX_NONHOSTWB, userProfile.getSessionID(traceID), getIpAddressFromRequest(httpReq, traceID), traceID);
			rsp = webSessConnector.handleRequest(req, traceID);

			ContentReader cr = new ContentReader(rsp.getContent(), traceID);
			SQLActionResult result = (SQLActionResult)cr.getContent(CommConst.BANK_APP_ACTION_RSP, CommConst.MSGPOS_CONTENT, traceID);
			return result;
		}
		catch (TransactionException te)
		{
			logger.log(traceID, LogConst.SEV_WARNING, className + " executeSQL Trx Exception: " + te.toString() + ", errno: " + te.getErrorNumber());
			throw te;
		}
		catch (Exception e)
		{
			logger.log(traceID, LogConst.SEV_WARNING, className + " executeSQL Exception: " + e.toString());
			throw e;
		}
	}

	public SQLActionResult executeSQL(SQLAction action, String appSqlCfg, String traceID)
                         throws TransactionException, Exception
	{
		Vector content = null;
		Response rsp = null;
		Request req = null;
		Vector item = null;
		VecList vecList = new VecList();
	    SQLActionResult nullresult = null;
	    byte pwd[];
	    String passwd = "";

		content = new Vector();
		vecList.addItem(content, CommConst.COM_FLD_CUST_ID, userProfile.getUserID(traceID), traceID);
		pwd = userProfile.getUserPWD(traceID);
		for (int y = 0; y < pwd.length; y++) {
			passwd = passwd + pwd[0];
		}
		vecList.addItem(content, CommConst.COM_FLD_PWD, passwd, traceID);

		item = new Vector(2);
		item.addElement(CommConst.BANK_APP_ACTION_REQ);
		item.addElement(action);
		content.addElement(item);

        vecList.addItem(content, ConfigConst.KEY_APP_SQL_CFG, appSqlCfg, traceID);

		try {
 		    //req = new Request(content, userProfile.getUserID(traceID), SQLTrxID, userProfile.getSessionID(traceID), httpReq.getRemoteAddr(), traceID);
			req = new Request(content, userProfile.getUserID(traceID), SQLTrxID, userProfile.getSessionID(traceID), getIpAddressFromRequest(httpReq, traceID), traceID);
			rsp = webSessConnector.handleRequest(req, traceID);
            errCode = rsp.getReturnCode();

			if (errCode != TransactionException.EC_SUCCESS)
			{
				logger.log(traceID, LogConst.SEV_WARNING, className + ": submitReq: Failed to process req (SQLTrxID:" + SQLTrxID + "): " + errCode);
			}
			else
			{
			   ContentReader cr = new ContentReader(rsp.getContent(), traceID);
			   SQLActionResult result = (SQLActionResult)cr.getContent(CommConst.BANK_APP_ACTION_RSP, CommConst.MSGPOS_CONTENT, traceID);
               logger.log(traceID, LogConst.SEV_ROUTINE, className + " executeSQL (SQLTrxID: " + SQLTrxID + ") done");
			   return result;
			}
		}
		catch (TransactionException te)
		{
			logger.log(traceID, LogConst.SEV_WARNING, className + " executeSQL Trx Exception (SQLTrxID: " + SQLTrxID + "): " + te.toString() + ", errno: " + te.getErrorNumber());
			throw te;
		}
		catch (Exception e)
		{
			logger.log(traceID, LogConst.SEV_WARNING, className + " executeSQL Exception (SQLTrxID: " + SQLTrxID + "): "  + e.toString());
			throw e;
		}
			return nullresult;
	}

  public String getValueAt(Vector rs, int row, int column) {
     Vector details =  (Vector) rs.elementAt(row);
     return (String)details.elementAt(column).toString().trim();
  }

    public void secureECertTrx(String trxCode) throws TransactionException{
        boolean ecertFlag = false;
        
        try{
logger.log(traceID, LogConst.SEV_WARNING, className + " 11111111111111111: "  + httpSession);
logger.log(traceID, LogConst.SEV_WARNING, className + " 11111111111111111: "  + httpSession.getAttribute(CommConst.ECERT_FLAG));
            if (httpSession.getAttribute(CommConst.ECERT_FLAG).equals("1")){
                ecertFlag = true;
            }
            if (httpSession.getAttribute(CommConst.TOKEN_FLAG).equals(ACESvcLabel.TOKEN_REGISTERED)){
                ecertFlag = true;
            }
			logger.log(traceID, LogConst.SEV_WARNING, className + " eCert Trx List: " + getECertTrxList());
            if (isECertTrx(trxCode) && !ecertFlag){
                throw new TransactionException(TransactionException.EC_ECERT_TRX_ERR, "trx not allowed without eCert, trxID: " + trxCode);
            }
        }catch(Exception e){
            throw new TransactionException(TransactionException.EC_ECERT_TRX_ERR, "trx not allowed without eCert, trxID: " + trxCode + ", " + e.toString());
        }
    }
    
    public boolean isECertTrx(String trxCode) throws TransactionException{

        try{
            return ECertTrxConfig.getInstance().requiredECert(trxCode);
        }catch(Exception e){
            throw new TransactionException(TransactionException.EC_ECERT_TRX_ERR, e.toString());
        }
        
    }
    
    public Hashtable getECertTrxList() throws TransactionException {
        try{
            return ECertTrxConfig.getInstance().getECertTrxList();
        }catch(Exception e){
            throw new TransactionException(TransactionException.EC_ECERT_TRX_ERR, e.toString());
        }
    }

    public boolean isECertLogon(){
        return userProfile.isECertLogon();
    }

    public boolean isTokenActivated(){
        return userProfile.isTokenActivated();
    }
      
    public String replaceToken(){
        if (userProfile.isTokenReplace())
            return "1";
        else
            return "";
    }
    
    public int verifyToken(HttpSession httpS, String trxID, String bbpID, String nationalID, String srn, String token) throws Exception{
        int rtn = 0;
        if (srn == null)
            srn = "";
        logger.log(traceID, LogConst.SEV_WARNING, className + " verifyToken begin");
        if (aceF == null)
            aceF = new ACEFactory(traceID);
        rtn = aceF.verifyToken(httpS, trxID.trim(), bbpID.trim(), nationalID.trim(), srn.trim(), token.trim());
        logger.log(traceID, LogConst.SEV_WARNING, className + " verifyToken completed with result: " + rtn);
        rtn = getTokenOBErrorCode(rtn);
        return rtn;        
    }
    
    public int activateToken(HttpSession httpS, String trxID, String bbpID, String nationalID, String srn, String token) throws Exception{
        int rtn = 0;
        logger.log(traceID, LogConst.SEV_WARNING, className + " activateToken begin");
        if (aceF == null)
            aceF = new ACEFactory(traceID);
        rtn = aceF.activateToken(httpS, trxID.trim(), bbpID.trim(), nationalID.trim(), srn.trim(), token.trim());
        if (rtn == ACESvcLabel.ACE_AGENT_ACCESS_OK){
            userProfile.setTokenReplace(false);
        }
        logger.log(traceID, LogConst.SEV_WARNING, className + " activateToken completed with result: " + rtn);
        rtn = getTokenOBErrorCode(rtn);
        if (rtn == TransactionException.EC_TOKEN_NEXT){
            rtn = TransactionException.EC_TOKEN_ACT_NEXT;
        }
        return rtn;
    }
 
    private int getTokenOBErrorCode(int rtn){
        
        if (rtn != ACESvcLabel.ACE_AGENT_ACCESS_OK){
            if (rtn == ACESvcLabel.ACE_AGENT_NEXT_TOKEN){
                errCode = TransactionException.EC_TOKEN_NEXT;
            }else if(rtn == ACESvcLabel.ACE_AGENT_ACCESS_DENIED){
                errCode = TransactionException.EC_TOKEN_ERR;
            }else if(rtn == TransactionException.EC_TOKEN_ALREADY_REG){
                errCode = TransactionException.EC_SUCCESS;
            }else{
                errCode = rtn;
            }
        }else{
            errCode = TransactionException.EC_SUCCESS;
        }
        
        return errCode;
    }
    /***  Send dummy request to eTran to keep session alive  ***/
    protected Vector getRspInfoKeepAlive(String traceID) {
        Vector submitReqInfo = new Vector();
        Vector page = new Vector();
        VecList vecList = new VecList();

        try {
            
            String cifNo = userProfile.getUserCIF(traceID);

            logger.log(traceID, LogConst.SEV_WARNING, className + ": getRspInfoKeepAlive() - Start for CIF = " + cifNo);

            vecList.addItem(submitReqInfo, CommConst.COM_FLD_CIF_NUM, cifNo, traceID);
            vecList.addItem(submitReqInfo, CommConst.COM_FLD_CUST_ID, bbpID, traceID);
            rspInfo = submitReq(submitReqInfo, ConfigConst.TRX_REFRESH_SESSION, traceID);

            if (errCode != TransactionException.EC_SUCCESS) {
                logger.log(traceID, LogConst.SEV_WARNING, className + ": getRspInfoKeepAlive() - Error for CIF = " + cifNo);
                return page;
            }
      
            logger.log(traceID, LogConst.SEV_WARNING, className + ": getRspInfoKeepAlive() - End for CIF = " + cifNo);

        } catch(Exception e) {
            logger.log(traceID, LogConst.SEV_ROUTINE, className +
                       ": getRspInfoKeepAlive() - Exception, e = " + e.toString());
            errCode = TransactionException.EC_SYSTEM_ERROR;
        }

        return page;
    }
    
    /**
	 * detect there is language parameter supplied in the request, if there is
	 * difference between the session and target session, update the session
	 * variables and userprofile object use chgLocale(Locale locale) method
	 */
	private void detectLangChg(String traceID) {

		String strToLocale = (String) this.httpReq.getParameter(CommConst.LANG_REQ_SWAP);

		Locale currLocale = null;

		if (strToLocale != null) {
			currLocale = (Locale) this.httpSession.getAttribute(Globals.LOCALE_KEY);

			if (currLocale == null || !(currLocale.toString()).equals(strToLocale)) {

				logger.log(traceID, LogConst.SEV_ROUTINE, className
						+ ": chgLocale from: " + currLocale + ", to: "
						+ strToLocale);

				if (strToLocale.equals(Locale.TRADITIONAL_CHINESE.toString())) {
					chgLang(Locale.TRADITIONAL_CHINESE);
				} else if (strToLocale.equals(Locale.SIMPLIFIED_CHINESE.toString())) {
					chgLang(Locale.SIMPLIFIED_CHINESE);
				} else if (strToLocale.equals(Locale.ENGLISH.toString())) {
					chgLang(Locale.ENGLISH);
				} else// Default based on sys default language 
					{
					
					if (CommonConst.SYS_DEF_LANG.equals(CommonConst.LANG_TRADITIONAL_CHINESE)) {
						chgLang(Locale.TRADITIONAL_CHINESE);
					} else if (CommonConst.SYS_DEF_LANG.equals(CommonConst.LANG_SIMPLIFIED_CHINESE)) {
						chgLang(Locale.SIMPLIFIED_CHINESE);
					} else if (CommonConst.SYS_DEF_LANG.equals(CommonConst.LANG_ENGLISH)) {
						chgLang(Locale.ENGLISH);
					}

				}

			}
		}
	}

	/**
	 * update the locale in session variables, 
	 *  userprofile object, web bank helper class variable
	 */
	private void chgLang(Locale locale) {

		Config.set(this.httpSession, Config.FMT_LOCALE, locale);
		httpSession.setAttribute(Globals.LOCALE_KEY, locale);
		String userLang = "";
		if (locale.equals(locale.TRADITIONAL_CHINESE)) {
			userLang = CommonConst.LANG_TRADITIONAL_CHINESE;
		} else if (locale.equals(locale.SIMPLIFIED_CHINESE)) {
			userLang = CommonConst.LANG_SIMPLIFIED_CHINESE;
		} else if (locale.equals(locale.ENGLISH)) {
			userLang = CommonConst.LANG_ENGLISH;
		}
		
		//update user profile in session
		userProfile.setUserLanguage(userLang, traceID);
		
		//update the class variable in the web bank helper		
		language = userProfile.getUserLanguage(traceID);
		
		// ? cannot find related code to use this variable
        httpSession.setAttribute("Language", language); 
 
	}
	
    protected String getIpAddressFromRequest(HttpServletRequest httpReq, String traceID){
  	  logger.log(traceID, Log.SEV_ROUTINE, className + ": getIpAddressFromRequest starts");
  	  boolean ipFromX = true;
  	     String ip = httpReq.getHeader("x-forwarded-for");
  	     if(ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
  	      ip =  httpReq.getRemoteAddr();
  	      ipFromX = false;
  	     }
  	     ip = (ip.split(","))[0];
  	     logger.log(traceID, Log.SEV_ROUTINE, className + ": getIpAddressFromRequest ends with ip="+ip+" from " + (ipFromX?"Request Header x-forwarded-for":"Request.getRemoteAddr()"));
  	     return ip;
  } 
    
    protected String getUserAgentFromRequest(HttpServletRequest httpReq, String traceID){
    	logger.log(traceID, LogConst.SEV_ROUTINE, className + ": getUserAgentFromRequest starts");
    	
    	String userAgent = httpReq.getHeader("user-agent");
    	int endIdx = userAgent.length();
    	if (endIdx > 250)
    		endIdx = 250;
    	  	
    	userAgent = userAgent.substring(0, endIdx);
    	
    	logger.log(traceID, LogConst.SEV_ROUTINE, className + ": getUserAgentFromRequest ends with user agent="+userAgent+" from Request Header user-agent");
  	    return userAgent;
    }
    
    
	/**
	 * PRJ2700 CUP Card Implementation Phase 1 - Retrieve Credit Card List in form of Vector<br>
	 * Please call this method after execution of <b>prepareCreditCardList()</b>
	 * @return 	Vector of Credit Card List For the specific Trxcode defined in the sub-class <br>
	 * 			Index 0	:	CC_WEBBANKHELPER_LIST_IDX_CARD_NO<br>
	 *			Index 1	:	CC_WEBBANKHELPER_LIST_IDX_CARD_DESC
	 */
    public Vector getCreditCardListVec() {
    	return creditCardList;
    }
    
	/**
	 * PRJ2700 CUP Card Implementation Phase 1 - Retrieve Credit Card List in for of Linked Hash Map<br>
	 * Please call this method after execution of <b>prepareCreditCardList()</b>
	 * @return 	Linked Hash Map of Credit Card List For the specific Trxcode defined in the sub-class <br>
	 * 			Key		:	CC_WEBBANKHELPER_LIST_IDX_CARD_NO<br>
	 *			Value	:	CC_WEBBANKHELPER_LIST_IDX_CARD_DESC
	 */
    public LinkedHashMap getCreditCardListLHM() {
		LinkedHashMap<String, String> creditCardListLHM = new LinkedHashMap<String, String>();
		int size = creditCardList==null? 0:creditCardList.size();
		for (int i = 0; i < size; i++) {
			Vector creditCardItemForDisplay = (Vector) this.creditCardList.get(i);
			creditCardListLHM.put((String) creditCardItemForDisplay.get(CCardCommConst.CC_WEBBANKHELPER_LIST_IDX_CARD_NO), 
					(String) creditCardItemForDisplay.get(CCardCommConst.CC_WEBBANKHELPER_LIST_IDX_CARD_DESC));
		}
		return creditCardListLHM;
	}    

    /**
     *  For function is called by check accessiblity or any function requires the TA/Credit Card Bal should be available in the user profile
     *  it is recommended to call this if the chkAccessibility flag is false. if the chkAccessibility flag is set to true, the method is called in web bank helper 
     */
    protected void prepareHostSysBal(){
    	if (!userProfile.isHostSysBalLoadedFlag())//if TA a/c and Card Link not load
		{			
			reloadAccount(traceID);
			userProfile.setHostSysBalLoadedFlag(true);					
			//FIXME: Spencer:add exception handling
		}   
    	
    }
    
	/**
	 * Prepare Credit Card List<br>
	 * Please call this method before retrieving credit card list from <b>getCreditCardListVec()</b> or <b>getCreditCardListLHM()</b>
	 */
    protected void prepareCreditCardList(){
    	logger.log(traceID, LogConst.SEV_WARNING, className + ": prepareCreditCardList(): Start...");
    	prepareHostSysBal();
    	creditCardList = new Vector();
    	Vector tempCreditCardList = userProfile.getCreditCardList();
    	int size = tempCreditCardList==null? 0:tempCreditCardList.size();
    	logger.log(traceID, LogConst.SEV_WARNING, className + ": prepareCreditCardList(): Number of credit card record at UserProfile = " + size);
    	if(size > 0){
    		try
    		{
    			// Prepare the configuration instances: 
    			// Config 1. Trx Accessibility
    			CCTrxAccessConfig cCTrxAccessConfig = CCTrxAccessConfig.getInstance(ConfigConst.FILE_CC_TRX_ACCESS_CFG, traceID);
    			
    			// Config 2. Card Description
	    		Vector creditCardItemFromUserprofile = null;
		    	Vector creditCardItemForDisplay = null;
		    	
		    	for(int i = 0; i< size; i++)
		    	{
		    		// Credit Card Record retrieved from HLLAPI
		    		creditCardItemFromUserprofile = (Vector)tempCreditCardList.get(i);
		    		
		    		// Check accessibility by Trxcode, Card Org and Card Type
		    		if(cCTrxAccessConfig.isCreditCardTrxAccessible(responsibleTrx, 
		    				creditCardItemFromUserprofile.get(CCardCommConst.CC_USERPROFILE_LIST_IDX_CARD_ORG).toString(),
		    				creditCardItemFromUserprofile.get(CCardCommConst.CC_USERPROFILE_LIST_IDX_CARD_TYPE).toString(),
		    				traceID)) 
		    		{
		    			// If the access is allowed, prepare the credit card description and add into the vector for output 
			    		creditCardItemForDisplay = new Vector();
			    		
			    		// Value
			    		creditCardItemForDisplay.add(CCardCommConst.CC_WEBBANKHELPER_LIST_IDX_CARD_NO, creditCardItemFromUserprofile.get(CCardCommConst.CC_USERPROFILE_LIST_IDX_CARD_NO).toString());
			    		
			    		// Description (format: "<Card Desc> XXXX-XXXX-XXXX-XXXX")
			    		creditCardItemForDisplay.add(CCardCommConst.CC_WEBBANKHELPER_LIST_IDX_CARD_DESC,
				    		CreditCardFormatter.formatCardNumberWithDescription(
				    				creditCardItemFromUserprofile.get(CCardCommConst.CC_USERPROFILE_LIST_IDX_CARD_NO).toString(),
					    			creditCardItemFromUserprofile.get(CCardCommConst.CC_USERPROFILE_LIST_IDX_CARD_ORG).toString(),
					    			creditCardItemFromUserprofile.get(CCardCommConst.CC_USERPROFILE_LIST_IDX_CARD_TYPE).toString(),
					    			language, traceID)
		    			);
			    		creditCardItemForDisplay.add(CCardCommConst.CC_WEBBANKHELPER_LIST_IDX_CARD_ORG, creditCardItemFromUserprofile.get(CCardCommConst.CC_USERPROFILE_LIST_IDX_CARD_ORG).toString());
			    		creditCardItemForDisplay.add(CCardCommConst.CC_WEBBANKHELPER_LIST_IDX_CARD_TYPE, creditCardItemFromUserprofile.get(CCardCommConst.CC_USERPROFILE_LIST_IDX_CARD_TYPE).toString());
			    		creditCardList.add(creditCardItemForDisplay);
		    		}
		    	}
		    	logger.log(traceID, LogConst.SEV_WARNING, className + ": prepareCreditCardList(): Filtered Credit Card List For Display= " + creditCardList);
    		}
    		catch (LoadConfigException e)
    		{
    			logger.log(traceID, LogConst.SEV_ERROR, className + ": prepareCreditCardList(): loadConfigTbl: LoadConfigException: " + e.toString());
    			errCode = TransactionException.EC_LOAD_SYS_CFG;
    		}
    	}else{
    		logger.log(traceID, LogConst.SEV_WARNING, className + ": prepareCreditCardList(): CcCardLinkList at UserProfile is empty.");
    	}
    	logger.log(traceID, LogConst.SEV_WARNING, className + ": prepareCreditCardList(): End.");
    }

	/**
	 *  Retrieve vector of Credit Card Credit Limit by Credit Card Number<br>
	 * @param creditCardNumber
	 * @return Vector of Credit Card Credit Limit
	 */    
    protected Vector getCreditCardCreditLimitVec(String creditCardNumber) {
    	Vector accSummaryList = userProfile.getAcctSummary(traceID);
    	ContentReader cr  = new ContentReader(accSummaryList, traceID);
    	short i = 1;
		boolean endOfList = false;
    	Vector availCreditLimitVector = null;
    	String creditCardNo = "";
    	/* 
    	 *	Comment about the while loop: 	
    	 *	Retrieve the hash map value from content reader by the key of CCardCommConst.CC_AVAILCREDITLIMIT_VECLIST with the row number i in each loop until no value is found
    	 *	Therefore, only Available Credit Limit related items would be looped for consideration.
    	 */    	
        while (!endOfList) {
        	availCreditLimitVector = (Vector)cr.getContent(CCardCommConst.CC_AVAILCREDITLIMIT_VECLIST, CommConst.MSGPOS_CONTENT, i, traceID);
        	if(availCreditLimitVector != null && availCreditLimitVector.size() > 0) {
				creditCardNo = availCreditLimitVector.elementAt(CCardCommConst.CC_CREDITLIMIT_IDX_CREDIT_CARD_NO).toString().trim();
				if(creditCardNo != null && creditCardNo.equals(creditCardNumber)){
					break;
				}
				i++;
        	}
        	else
        	{
        		endOfList = true;
        	}			
        }
        logger.log(traceID, LogConst.SEV_WARNING, className + ": getCreditCardCreditLimitVec() for " + creditCardNumber + ": " + (availCreditLimitVector==null?"Not found":availCreditLimitVector));
        return availCreditLimitVector;
	}

	/**
	 * Update Account Summary at User Profile by vector of Credit Card Credit Limit<br>
	 * @param availCreditLimitVec
	 */     
    protected void setCreditCardCreditLimitVec(Vector availCreditLimitVec) {
    	
    	// Variables for Account Summary and its content
    	Vector accSummaryList = userProfile.getAcctSummary(traceID);
    	ContentReader cr  = new ContentReader(accSummaryList, traceID);
    	Vector availCreditLimitVecFromAccSummary = null;
    	
    	// Variables for credit card number
    	String creditCardNoFromList = "";
    	String creditCardNoFromParameter = availCreditLimitVec.get(CCardCommConst.CC_CREDITLIMIT_IDX_CREDIT_CARD_NO).toString().trim();
    	
    	// Variables for loops
    	short i = 1;
    	boolean endOfList = false;
    	VecList vecList = new VecList();
    	
    	/* 
    	 *	Comment about the while loop: 	
    	 *	Retrieve the hash map value from content reader by the key of CCardCommConst.CC_AVAILCREDITLIMIT_VECLIST with the row number i in each loop until no value is found
    	 *	Therefore, only Available Credit Limit related items would be looped for consideration.
    	 */
    	while (!endOfList) 
    	{
    		// Available Credit Limit Item from Account Summary
    		availCreditLimitVecFromAccSummary = (Vector)cr.getContent(CCardCommConst.CC_AVAILCREDITLIMIT_VECLIST, CommConst.MSGPOS_CONTENT, i, traceID);
    		
    		// If the item is valid, then compare its credit card number with the credit card number of Available Credit Limit Item from parameter 
    		if(availCreditLimitVecFromAccSummary != null && availCreditLimitVecFromAccSummary.size() > 0) 
    		{
    			creditCardNoFromList = availCreditLimitVecFromAccSummary.elementAt(CCardCommConst.CC_CREDITLIMIT_IDX_CREDIT_CARD_NO).toString().trim();
    			try{
    				// If credit card numbers are the same, then replace the Available Credit Limit Item at Account Summary 
	    			if(creditCardNoFromList != null && creditCardNoFromList.equals(creditCardNoFromParameter))
	    			{
	    				vecList.addItem(accSummaryList, CCardCommConst.CC_AVAILCREDITLIMIT_VECLIST, availCreditLimitVec, Integer.toString(i), traceID);
	    			}
    			}catch (TransactionException e) {
    	            logger.log(traceID, LogConst.SEV_WARNING, className +": setCreditCardCreditLimitVec() - TransactionException, e = " + e.toString());
				}
    			i++;
    		}
    		else
    		{
    			endOfList = true;
    		}			
    	}
    }
    
	/**
	 *  Retrieve Card Org<br>
	 * @param creditCardNumber
	 * @return String cardOrg
	 */    
    protected String getCreditCardOrg(String creditCardNumber) {
    	String cardOrg = "";
    	Vector curVec = null;
    	
		int size = creditCardList==null? 0:creditCardList.size();
		
		for (int i = 0; i < size; i++) {
			curVec = (Vector) this.creditCardList.get(i);
			if (((String)curVec.get(CCardCommConst.CC_WEBBANKHELPER_LIST_IDX_CARD_NO)).equals(creditCardNumber)) {
				cardOrg = (String)curVec.get(CCardCommConst.CC_WEBBANKHELPER_LIST_IDX_CARD_ORG);
				logger.log(traceID, LogConst.SEV_WARNING, className + ": getCreditCardOrg() for " + creditCardNumber + ": " + cardOrg);
				return cardOrg;
			}
		}
		logger.log(traceID, LogConst.SEV_WARNING, className + ": getCreditCardOrg() for " + creditCardNumber + ": Not found.");
    	return cardOrg;
	}
    
	/** 
	 * Find Card Brand for given Card Number.
	 * eg. Core, AIA, CUP
	 * 
	 * @param cardNo
	 * @return Return empty string if not found 
	 */
	public String getCardBrand(String cardNo){
		Vector<Vector> creditCards = getCreditCardListVec();
		try {
			CCardTypeConfig cctCfg = CCardTypeConfig.getInstance(null, traceID);
			
			for (Vector card: creditCards) {
				if(cardNo.equals(card.get(CCardCommConst.CC_WEBBANKHELPER_LIST_IDX_CARD_NO))){
					String cardType = (String)card.get(CCardCommConst.CC_WEBBANKHELPER_LIST_IDX_CARD_TYPE);
					return cctCfg.getBrandName(cardType);
				}
			}
		} catch (Exception e) {
			logger.log(traceID, Log.SEV_ERROR, className + 
					": Exception when creating cradBrandNameMap - " + e);
			e.printStackTrace();
		}
		
		return "";
	}
	/**
	 * To refresh the balances of TA/MCSSA Account, get a list of credit card
	 * @param traceID
	 * @return
	 */
	 protected Vector reloadAccount(String traceID)
	    {  
			Vector rspMsg = new Vector();  	
	        String reqRefresh = "";
	        Vector result = new Vector();

	        UserProfile userProfileOld = null;        
	        
			Vector acctSummary			= userProfile.getAcctSummary(traceID);		
			ContentReader CRAcctSummary = new ContentReader();
			ContentReader CRLocal		= new ContentReader();
			CRAcctSummary.setContent(acctSummary,traceID);  	
	    
			String haveMCSSA	= (String)CRAcctSummary.getContent(CommConst.CID_FLD_HAVE_MCSSA		  ,CommConst.MSGPOS_CONTENT,(short)0,traceID);    
			short numberOfMCSSA = ((Short)CRAcctSummary.getContent(CommConst.CID_FLD_NUMBER_OF_MCSSA  ,CommConst.MSGPOS_CONTENT,(short)0,traceID)).shortValue();    
			logger.log(traceID,LogConst.SEV_ROUTINE, className + ": haveMCSSA = " + haveMCSSA + " number of MCSSA = " + numberOfMCSSA) ;
	        
	        userProfileOld = this.userProfile;    
	        Vector list = new Vector(0);
	        Vector item = new Vector(0);
	        VecList vecList = new VecList();
	        Vector submitReqInfo = new Vector();
	        String refreshType = "F";
	        
	        try {
	            // format request message
	          vecList.addItem(submitReqInfo, CommConst.COM_FLD_SELECT_LANGUAGE, language, traceID);
	          vecList.addItem(submitReqInfo, CommConst.COM_FLD_CUST_ID, bbpID, traceID);
	          vecList.addItem(submitReqInfo, CommConst.COM_FLD_CIF_NUM, userProfile.getUserCIF(traceID), traceID);
	          vecList.addItem(submitReqInfo, CommConst.COM_FLD_PWD, userProfile.getUserPWD(traceID), traceID);
	          vecList.addItem(submitReqInfo, "RefreshType", refreshType, traceID);
	          vecList.addItem(submitReqInfo, "AcctSummary", userProfileOld.getAcctSummary(traceID), traceID);
	          //For Gold Trading - Get Customer Type
	          vecList.addItem(submitReqInfo, GDTCommConst.GDT_FLD_CUSTOMER_TYPE, userProfile.convertCustGroup(), traceID);

	          //For Credit Card (added for PRJ3904)	          
	          vecList.addItem(submitReqInfo, CCardCommConst.CC_MESSAGEKEY_HKID, userProfile.getHKID(traceID), traceID);	          
	          vecList.addItem(submitReqInfo, CommConst.CID_DATE_OF_BIRTH, userProfile.getDateOfBirth(), traceID);
	          vecList.addItem(submitReqInfo, CommConst.CID_FLD_CUST_NAME, userProfile.getCustomerName(traceID), traceID);
	          if(userProfile.isCreditCardHolder()){
	        	  vecList.addItem(submitReqInfo, CommConst.COM_FLD_CC_AVAIL, "true", traceID);
	        	  if(userProfile.getCreditCardList()!=null)//the credit card list is empty on first call or never be initialized by successful call HLLAPI
	        	  {
	        		  this.prepareCreditCardList();
	        		  //in the etran layer, if the CID_FLD_CC_LIST is not null, then etran will not submit a A01 call
	        		  vecList.addItem(submitReqInfo, CommConst.CID_FLD_CC_LIST, this.getCreditCardListVec(), traceID);
	        		  
	        	  }
	          }
	          result = submitReq(submitReqInfo, ConfigConst.TRX_REFRESH, traceID);                            
	          if (errCode == TransactionException.EC_SUCCESS) {
	               acctSummary = new Vector();
	               for(int i=0;i<result.size();i++) {
	                   acctSummary.addElement((Vector)result.elementAt(i));
	               }
	               userProfileOld.setAcctSummary(acctSummary,traceID);
	               ContentReader cr = new ContentReader();
	               cr.setContent(result, traceID);
	               Vector creditCardListForUserProfile = (Vector) cr.getContent(CommConst.CID_FLD_CC_LIST, CommConst.MSGPOS_CONTENT, traceID);
	               if( creditCardListForUserProfile != null){
	            	   logger.log(traceID,LogConst.SEV_ROUTINE, className + ": creditCardListFromHllapiVec = " + creditCardListForUserProfile.toString());
	            	   userProfile.setCreditCardList(creditCardListForUserProfile, traceID);
	               }
	               //FIXME spencer: add credit card down case
	           } else {
	                // override error code
	                errCode = TransactionException.EC_SUCCESS;
	            }
	            httpSession.putValue(getUserProfileSessionKey(), userProfileOld);            
	        }
	        catch (Exception e) {
	            logger.log(traceID,LogConst.SEV_WARNING, className + ":  submitReq for Saving/Checking :Exception: " + e.toString());
	                return rspMsg;
	        }
	           
			return rspMsg;
		}
	    
	 public int chkBrowserBack(String traceID){
		 errCode = TransactionException.EC_SUCCESS;
		 if(reqToChkBrowserBack){
			 logger.log(traceID,LogConst.SEV_INFO, className + ":  chkBrowserBack in WebBankHelper");
			 if(formObj instanceof BaseForm ){
				 String s1 = ((BaseForm)formObj).getFormRandomNum();
				 String s2 = this.getHandlerRandomNum();
				 
				 if (isEmpty(s1)|| isEmpty(s2)){
					 errCode = TransactionException.EC_INVALID_BACK;
				 }
				 else{
					 if(!s1.equals(this.getHandlerRandomNum())){
						 errCode = TransactionException.EC_INVALID_BACK;
					 }
				 }
			 }else{
				 errCode = TransactionException.EC_UNKNOWN_ERROR;
			 }
		 }
		 return errCode;
	 }

	 public String generateBrowserToken()
	 {
		 UUID uuid  =  UUID.randomUUID();
		 handlerRandomNum = uuid.toString();
  		 return handlerRandomNum; 
			 		 
	 }

	public boolean isReqToChkBrowserBack() {
		return reqToChkBrowserBack;
	}

	public void setReqToChkBrowserBack(boolean reqToChkBrowserBack) {
		this.reqToChkBrowserBack = reqToChkBrowserBack;
	}
	
	public boolean getReqToChkBrowserBack()
	{
		return reqToChkBrowserBack;
	}
	
	public String getHandlerRandomNum() {
		return handlerRandomNum;
	}

	private void setHandlerRandomNum(String handlerRandomNum) {
		this.handlerRandomNum = handlerRandomNum;
	}
	public boolean isEmpty(String val){
		boolean result = false;
		if(val == null){
			result = true;
		}else{
			if (val.trim().equals("")){
				result = true;
			}else{
				result = false;
			}
		}
		return result;
	}
	
	protected void setSession(String key,Object obj){
		logger.log(traceID, LogConst.SEV_ROUTINE, className + ": setSession starts");
		HttpSession sess = httpReq.getSession(false);
		sess.setAttribute(key, obj);
		logger.log(traceID, LogConst.SEV_ROUTINE, className + ": setSession finished");
	}
	
	protected Object getSession(String key){
		logger.log(traceID, LogConst.SEV_ROUTINE, className + ": getSession starts");
		HttpSession sess = httpReq.getSession(false);
		Object obj = sess.getAttribute(key);
		
		if (obj == null) {
			Log.writeDebugLog(traceID, Log.SEV_WARNING, className + ": getSession Exception: sessionInfo is null");
			throw new RuntimeException(""+TransactionException.EC_ST_NO_SESSION_CONTENT);
		}
		
		logger.log(traceID, LogConst.SEV_ROUTINE, className + ": getSession finished");
		return obj;
	}
}
