<?php
define("DB_HOST", "db.host");
define("DB_PORT", "db.port");
define("DB_BASENAME", "db.basename");
define("DB_USER", "db.user");
define("DB_PASSWORD", "db.password");
define("PATH", "path");
?>