<?php

namespace common;

use PDO;

class ConnectionDB {
	
	private static $instance;
	
	private function _construct() {
	}
	
	public static function getInstance() {
		if (self::$instance === null) {
			self::$instance = new ConnectionDB ();
		}
		return self::$instance;
	}
	function getConnection() {
		$connPDO = null;
		try {
			// building data source name from config
			$dsn = 'mysql:host=' . ConfigUtil::read ( DB_HOST ) . 
			 ';dbname=' . ConfigUtil::read ( DB_BASENAME ) . 
			 ';port=' . ConfigUtil::read ( DB_PORT ) . 
			';connect_timeout=15';
			// getting DB user from config
			$user = ConfigUtil::read ( DB_USER );
			// getting DB password from config
			$password = ConfigUtil::read ( DB_PASSWORD );
			$connPDO = new PDO ( $dsn, $user, $password );
			$connPDO->setAttribute ( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
		} catch ( PDOException $e ) {
			throw $e;
		} catch ( Exception $e ) {
			throw $e;
		}
		
		return $connPDO;
	}
}

?>