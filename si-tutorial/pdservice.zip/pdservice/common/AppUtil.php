<?php
namespace common;
class AppUtil{
	
	public static function IsNullOrEmptyString($value){
		return (!isset($value) || trim($value)==='');
	}
	
	public static function IsNotNullOrEmptyString($value){
		return !(!isset($value) || trim($value)==='');
	}
}
?>