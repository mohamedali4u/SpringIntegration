<?php
namespace common;
class AppUtil{
	
	public static function IsNullOrEmptyString($value){
		return (!isset($value) || trim($value)==='');
	}
	
	public static function IsNotNullOrEmptyString($value){
		return !(!isset($value) || trim($value)==='');
	}
	
	public static function isDoctor($value){
		return (strcasecmp(ConfigUtil::read ( DOCTOR ), $value) == 0) ;
	}
	
	public static function isHospital($value){
		return (strcasecmp(ConfigUtil::read ( HOSPITAL ), $value) == 0) ;
	}
	
	public static function isLab($value){
		return (strcasecmp(ConfigUtil::read ( LAB ), $value) == 0) ;
	}
	
	public static function isPharmacy($value){
		return (strcasecmp(ConfigUtil::read ( PHARMACY ), $value) == 0) ;
	}
	
}
?>