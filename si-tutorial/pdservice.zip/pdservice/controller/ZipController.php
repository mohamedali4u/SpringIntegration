<?php


namespace controller;

require 'model/ZipDA.php';

use model\ZipDA;

$app->get('/zip/allStates', function() {
		$response = array();
		$zipDA = new ZipDA();
		$response = $zipDA->getAllStates();
		jsonResponse(0, $response);
});

?>
