<?php


namespace controller;

require 'model/TaxonomyDA.php';

use model\TaxonomyDA;

$app->get('/taxonomy/allGroup', function() {
		$response = array();
		$taxonomyDA = new TaxonomyDA();
		$response = $taxonomyDA->getAllTaxonomyGroup();
		jsonResponse(0, $response);
});

$app->get('/taxonomy/allClassifyByGroup/:txGroupCode/:txGroup', function($txGroupCode, $txGroup) {
		$response = array();
		$taxonomyDA = new TaxonomyDA();
		$txGroup = str_replace("&", "\\&", $txGroup);
		$response = $taxonomyDA->getAllClassifyByGroup($txGroupCode, $txGroup);
		jsonResponse(0, $response);
});
	
$app->get('/taxonomy/allSplByGroup/:txGroupCode/:txGroup/:txClassify', function($txGroupCode, $txGroup, $txClassify) {
		$response = array();
		$taxonomyDA = new TaxonomyDA();
		$txGroup = str_replace("&", "\\&", $txGroup);
		$txClassify = str_replace("&", "\\&", $txClassify);
		$response = $taxonomyDA->getAllSplByGroup($txGroupCode, $txGroup, $txClassify);
		jsonResponse(0, $response);
});

?>
