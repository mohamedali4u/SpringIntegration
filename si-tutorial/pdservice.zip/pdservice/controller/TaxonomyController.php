<?php


namespace controller;

require 'model/TaxonomyDA.php';

use model\TaxonomyDA;

$app->get('/taxonomy/allSpl', function() {
		$response = array();
		$taxonomyDA = new TaxonomyDA();
		$response = $taxonomyDA->getAllSpeciality();
		jsonResponse(0, $response);
});

?>
