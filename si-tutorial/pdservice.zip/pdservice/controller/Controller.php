<?php
namespace controller;

require 'common/AppConstants.php';
require 'common/ConfigUtil.php';
require 'resource/config.php';
require 'common/ConnectionDB.php';
require 'common/AppUtil.php';

function jsonResponse($status_code, $response) {
	$app = \Slim\Slim::getInstance();
	$app->status($status_code);
	$app->contentType('application/json');
	echo json_encode($response);
}
?>
