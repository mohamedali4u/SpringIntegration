<?php

namespace controller;

require 'model/ProviderDA.php';

use model\ProviderDA;

$app->get ( '/', function () {
	$response ["error"] = false;
	$response ["message"] = "Welcome to Provider Directory!";
	jsonResponse ( 0, $response );
} );

// $app->get('/providerByNPI/:npi', 'getProviderByNPI');

$app->get ( '/providerByNPI/:npi', function ($npi) {
	$response = array ();
	$providerDA = new ProviderDA ();
	$response = $providerDA->getProviderByNPI ( $npi );
	jsonResponse ( 0, $response );
} );

// $app->get('/allProvider', function() {
// $response = array();
// $providerDA = new ProviderDA();
// $response = $providerDA->getAllProvider();
// jsonResponse(0, $response);
// });

// $app->get('/providerBySpl/:spl', function($spl) {
// $response = array();
// $providerDA = new ProviderDA();
// $response = $providerDA->getProviderBySpl($spl);
// jsonResponse(0, $response);
// });

$app->post ( '/providerByCriteria', function () use($app) {
	$entity = $app->request->getBody ();
	$criteria = json_decode ( $entity, true );
	$providerDA = new ProviderDA ();
	$response = $providerDA->getProviderByCriteria ( $criteria );
	jsonResponse ( 0, $response );
} );

$app->post ( '/doctorByCriteria', function () use($app) {
	$entity = $app->request->getBody ();
	$criteria = json_decode ( $entity, true );
	$providerDA = new ProviderDA ();
	$response = $providerDA->getPDInfoByCriteria ( $criteria, true );
	jsonResponse ( 0, $response );
} );

$app->post ( '/orgByCriteria', function () use($app) {
	$entity = $app->request->getBody ();
	$criteria = json_decode ( $entity, true );
	$providerDA = new ProviderDA ();
	$response = $providerDA->getPDInfoByCriteria ( $criteria, false );
	jsonResponse ( 0, $response );
} );

$app->get ( '/providerMstByNPI/:npi', function ($npi) {
	$response = array ();
	$providerDA = new ProviderDA ();
	$response = $providerDA->getProviderMstByNPI ( $npi );
	jsonResponse ( 0, $response );
} );

$app->get ( '/providerOrgDtlByNPI/:npi', function ($npi) {
	$response = array ();
	$providerDA = new ProviderDA ();
	$response = $providerDA->getProviderOrgDtlByNPI ( $npi );
	jsonResponse ( 0, $response );
} );

$app->get ( '/providerAddrsDtlByNPI/:npi', function ($npi) {
	$response = array ();
	$providerDA = new ProviderDA ();
	$response = $providerDA->getProviderAddrsDtlByNPI ( $npi );
	jsonResponse ( 0, $response );
} );

$app->get ( '/providerIdentifierDtlByNPI/:npi', function ($npi) {
	$response = array ();
	$providerDA = new ProviderDA ();
	$response = $providerDA->getProviderIdentifierDtlByNPI ( $npi );
	jsonResponse ( 0, $response );
} );

$app->get ( '/providerTaxonomyDtlByNPI/:npi', function ($npi) {
	$response = array ();
	$providerDA = new ProviderDA ();
	$response = $providerDA->getProviderTaxonomyDtlByNPI ( $npi );
	jsonResponse ( 0, $response );
} );

// $app->get('/getSomething/:input', function($input) {

// $response = array();

// // add your business logic here

// $response["error"] = false;
// $response["message"] = "Response from Slim RESTful Webservice - ".$input;
// jsonResponse(200, $response);
// });

// $app->post('/postSomething', function() use ($app) {

// $response = array();
// $input = $app->request->post('input'); // reading post params
// // add your business logic here

// $response["error"] = false;
// $response["message"] = "Response from Slim RESTful Webservice - ".$input;
// jsonResponse(200, $response);
// });

// $app->put('/putSomething', function() use($app) {

// $response = array();
// $input = $app->request->put('input'); // reading post params

// // add your business logic here
// $result = true;
// if ($result) {
// // Updated successfully
// $response["error"] = false;
// $response["message"] = "Updated successfully";
// } else {
// // Failed to update
// $response["error"] = true;
// $response["message"] = "Failed to update. Please try again!";
// }
// jsonResponse(200, $response);
// });

// $app->delete('/deleteSomething', function() use($app) {

// $response = array();
// $input = $app->request->put('input'); // reading post params

// // add your business logic here
// $result = true;
// if ($result) {
// //deleted successfully
// $response["error"] = false;
// $response["message"] = "Deleted succesfully";
// } else {
// //failed to delete
// $response["error"] = true;
// $response["message"] = "Failed to delete. Please try again!";
// }
// jsonResponse(200, $response);
// });

?>
