<?php
use common\ConfigUtil;
// DB Config
ConfigUtil::write(DB_HOST, 'localhost');
ConfigUtil::write(DB_PORT, '');
ConfigUtil::write(DB_BASENAME, 'providerdb');
ConfigUtil::write(DB_USER, 'root');
ConfigUtil::write(DB_PASSWORD, '');
// Project Config
ConfigUtil::write('path', 'http://localhost/pdservice');
?>