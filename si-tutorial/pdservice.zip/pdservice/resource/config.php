<?php
use common\ConfigUtil;
// DB Config
ConfigUtil::write(DB_HOST, 'hostname');
ConfigUtil::write(DB_PORT, 'port');
ConfigUtil::write(DB_BASENAME, 'database');
ConfigUtil::write(DB_USER, 'username');
ConfigUtil::write(DB_PASSWORD, 'password');
// Project Config
ConfigUtil::write('path', 'http://localhost/pdservice');
?>