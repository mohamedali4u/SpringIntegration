<?php
namespace model;

use common\ConnectionDB;
use common\AppUtil;
use PDO;

class ZipDA {
	
	public function getAllStates() {
		$connPDO = null;
		$stmt = null;
		$result = array ();
		try {
			//if ($this->connectionDB !== null) {
				$connPDO = ConnectionDB::getInstance ()->getConnection();
				//$connPDO = $this->connectionDB->getConnection ();
				if ($connPDO !== null) {
					$connPDO->beginTransaction ();
					$qryAllStates = "select state_name as stateName, state_abbr as stateCode from zip_mst group by state_name, state_abbr;";
					$stmt = $connPDO->prepare ( $qryAllStates );
					$stmt->setFetchMode ( PDO::FETCH_ASSOC );
					$stmt->execute ();
					$result = $stmt->fetchAll ();
					$connPDO->commit ();
				}
			//}
		} catch ( PDOException $e ) {
			if ($connPDO) {
				$connPDO->rollBack ();
			}
			
			die ( "getAllStates - Failed: " . $e->getMessage () );
		} catch ( Exception $e ) {
			if ($connPDO) {
				$connPDO->rollBack ();
			}
			
			die ( "getAllStates - Failed: " . $e->getMessage () );
		} finally {
			if ($stmt !== null) {
				$stmt = null;
			}
			
			if ($connPDO !== null) {
				$connPDO = null;
			}
		}
		return $result;
	}
	
}

?>