<?php
namespace model;

use common\ConnectionDB;
use common\AppUtil;
use PDO;

class ProviderDA {
	
// 	public function getProviderByNPI($npi) {
// 		$connPDO = null;
// 		$stmt = null;
// 		$result = array ();
// 		try {
// 			//if ($this->connectionDB !== null) {
// 				$connPDO = ConnectionDB::getInstance ()->getConnection();
// 				//$connPDO = $this->connectionDB->getConnection ();
// 				if ($connPDO !== null) {
// 					$connPDO->beginTransaction ();
// 					$qryProviderByNPI = "select * from provider_mst where npi = :npi";
// 					$stmt = $connPDO->prepare ( $qryProviderByNPI );
// 					$stmt->bindParam ( ":npi", $npi );
// 					$stmt->setFetchMode ( PDO::FETCH_ASSOC );
// 					$stmt->execute ();
// 					$result = $stmt->fetchAll ();
// 					$connPDO->commit ();
// 				}
// 			//}
// 		} catch ( PDOException $e ) {
// 			if ($connPDO) {
// 				$connPDO->rollBack ();
// 			}
			
// 			die ( "getProviderByNPI - Failed: " . $e->getMessage () );
// 		} catch ( Exception $e ) {
// 			if ($connPDO) {
// 				$connPDO->rollBack ();
// 			}
			
// 			die ( "getProviderByNPI - Failed: " . $e->getMessage () );
// 		} finally {
// 			if ($stmt !== null) {
// 				$stmt = null;
// 			}
			
// 			if ($connPDO !== null) {
// 				$connPDO = null;
// 			}
// 		}
// 		return $result;
// 	}
	
// 	public function getAllProvider() {
// 		$connPDO = null;
// 		$stmt = null;
// 		$result = array ();
// 		try {
// 			//if ($this->connectionDB !== null) {
// 			$connPDO = ConnectionDB::getInstance ()->getConnection();
// 			//$connPDO = $this->connectionDB->getConnection ();
// 			if ($connPDO !== null) {
// 				$connPDO->beginTransaction ();
// 				$qryAllProvider = "select pm.npi as npi, pm.entity_type_code as entityCode, pm.name_prefix as namePrefix," .
// 						" pm.first_name as firstName, pm.last_name as lastName, pm.middle_name as middleName, pm.gender_code as gender," .
// 						" tm.taxonomy_code  as taxonomyCode, REPLACE(tm.taxonomy_group,'\"','') as taxonomyGroup," .
// 						" REPLACE(REPLACE(trim(tm.taxonomy_spl),'\"',''), '\/', ' ') as taxonomySpl," .
// 						" REPLACE(REPLACE(trim(tm.taxonomy_classify),'\"',''), '\/', ' ') as taxonomyClsfy".
// 						" from provider_mst pm, provider_taxonomy_dtl ptd, taxonomy_mst tm " .
// 						" where pm.npi = ptd.npi and ptd.taxonomy_code is not null and ptd.taxonomy_code = tm.taxonomy_code" .
// 						" group by npi, entityCode, namePrefix, firstName, lastName, middleName, gender,  taxonomyCode, taxonomyGroup, taxonomySpl, taxonomyClsfy";
				
// 				$stmt = $connPDO->prepare ( $qryAllProvider );
// 				$stmt->setFetchMode ( PDO::FETCH_ASSOC );
// 				$stmt->execute ();
// 				$result = $stmt->fetchAll ();
// 				$connPDO->commit ();
// 			}
// 			//}
// 		} catch ( PDOException $e ) {
// 			if ($connPDO) {
// 				$connPDO->rollBack ();
// 			}
				
// 			die ( "getProviderByNPI - Failed: " . $e->getMessage () );
// 		} catch ( Exception $e ) {
// 			if ($connPDO) {
// 				$connPDO->rollBack ();
// 			}
				
// 			die ( "getProviderByNPI - Failed: " . $e->getMessage () );
// 		} finally {
// 			if ($stmt !== null) {
// 				$stmt = null;
// 			}
				
// 			if ($connPDO !== null) {
// 				$connPDO = null;
// 			}
// 		}
// 		return $result;
// 	}

// 	public function getProviderBySpl($spl) {
// 		$connPDO = null;
// 		$stmt = null;
// 		$result = array ();
// 		try {
// 			//if ($this->connectionDB !== null) {
// 			$connPDO = ConnectionDB::getInstance ()->getConnection();
// 			//$connPDO = $this->connectionDB->getConnection ();
// 			if ($connPDO !== null) {
// 				$connPDO->beginTransaction ();
// 				$qryProviderBySpl = "select pm.npi as npi, pm.entity_type_code as entityCode, pm.name_prefix as namePrefix," .
// 						" pm.first_name as firstName, pm.last_name as lastName, pm.middle_name as middleName, pm.gender_code as gender," .
// 						" tm.taxonomy_code  as taxonomyCode, REPLACE(tm.taxonomy_group,'\"','') as taxonomyGroup," .
// 						" REPLACE(REPLACE(trim(tm.taxonomy_spl),'\"',''), '\/', ' ') as taxonomySpl," .
// 						" REPLACE(REPLACE(trim(tm.taxonomy_classify),'\"',''), '\/', ' ') as taxonomyClsfy".
// 						" from provider_mst pm, provider_taxonomy_dtl ptd, taxonomy_mst tm " .
// 						" where pm.npi = ptd.npi and ptd.taxonomy_code is not null and ptd.taxonomy_code = tm.taxonomy_code" . 
// 						" and (tm.taxonomy_spl like '%" . $spl . "%' or tm.taxonomy_group like '%" . $spl . "%' or tm.taxonomy_classify like '%" . $spl . "%')" .
// 						" group by npi, entityCode, namePrefix, firstName, lastName, middleName, gender,  taxonomyCode, taxonomyGroup, taxonomySpl, taxonomyClsfy";
// 				$stmt = $connPDO->prepare ( $qryProviderBySpl );
// 				//$stmt->bindParam ( ":spl", $spl );
// 				$stmt->setFetchMode ( PDO::FETCH_ASSOC );
// 				$stmt->execute ();
// 				$result = $stmt->fetchAll ();
// 				$connPDO->commit ();
// 			}
// 			//}
// 		} catch ( PDOException $e ) {
// 			if ($connPDO) {
// 				$connPDO->rollBack ();
// 			}
				
// 			die ( "getProviderBySpl - Failed: " . $e->getMessage () );
// 		} catch ( Exception $e ) {
// 			if ($connPDO) {
// 				$connPDO->rollBack ();
// 			}
				
// 			die ( "getProviderBySpl - Failed: " . $e->getMessage () );
// 		} finally {
// 			if ($stmt !== null) {
// 				$stmt = null;
// 			}
				
// 			if ($connPDO !== null) {
// 				$connPDO = null;
// 			}
// 		}
// 		return $result;
// 	}
	
// 	public function getProviderByCriteria($criteria) {
// 		$connPDO = null;
// 		$stmt = null;
// 		$result = array ();
// 		try {
// 			//if ($this->connectionDB !== null) {
// 			$connPDO = ConnectionDB::getInstance ()->getConnection();
// 			//$connPDO = $this->connectionDB->getConnection ();
// 			if ($connPDO !== null) {
// 				$connPDO->beginTransaction ();
				
// 				$qryProviderByCriteria = $this->getCriteriaQuery($criteria);
// 				$stmt = $connPDO->prepare ( $qryProviderByCriteria );
// 				//$stmt->bindParam ( ":spl", $spl );
// 				$stmt->setFetchMode ( PDO::FETCH_ASSOC );
// 				$stmt->execute ();
// 				$result = $stmt->fetchAll ();
// 				$connPDO->commit ();
// 			}
// 			//}
// 		} catch ( PDOException $e ) {
// 			if ($connPDO) {
// 				$connPDO->rollBack ();
// 			}
	
// 			die ( "getProviderByCriteria - Failed: " . $e->getMessage () );
// 		} catch ( Exception $e ) {
// 			if ($connPDO) {
// 				$connPDO->rollBack ();
// 			}
	
// 			die ( "getProviderByCriteria - Failed: " . $e->getMessage () );
// 		} finally {
// 			if ($stmt !== null) {
// 				$stmt = null;
// 			}
	
// 			if ($connPDO !== null) {
// 				$connPDO = null;
// 			}
// 		}
// 		return $result;
// 	}
	
	public function getPDInfoByCriteria($criteria, $providerType) {
		$connPDO = null;
		$stmt = null;
		$result = array ();
		try {
			//if ($this->connectionDB !== null) {
			$connPDO = ConnectionDB::getInstance ()->getConnection();
			//$connPDO = $this->connectionDB->getConnection ();
			if ($connPDO !== null) {
				$connPDO->beginTransaction ();
	
				$qryProviderByCriteria = $this->getDoctorQry($criteria, $providerType);
				//print_r($qryProviderByCriteria);
				$stmt = $connPDO->prepare ( $qryProviderByCriteria );
				//$stmt->bindParam ( ":spl", $spl );
				$stmt->setFetchMode ( PDO::FETCH_ASSOC );
				$stmt->execute ();
				$result = $stmt->fetchAll ();
				$connPDO->commit ();
			}
			//}
		} catch ( PDOException $e ) {
			if ($connPDO) {
				$connPDO->rollBack ();
			}
	
			die ( "getProviderByCriteria - Failed: " . $e->getMessage () );
		} catch ( Exception $e ) {
			if ($connPDO) {
				$connPDO->rollBack ();
			}
	
			die ( "getProviderByCriteria - Failed: " . $e->getMessage () );
		} finally {
			if ($stmt !== null) {
				$stmt = null;
			}
	
			if ($connPDO !== null) {
				$connPDO = null;
			}
		}
		return $result;
	}
	
	private function getDoctorQry($criteria, $providerType){
		$searchKeyword = $criteria['search_keyword'];
		$searchTaxonomyCode = $criteria['search_taxonomy_code'];
		$searchStateCode = $criteria['search_state_code'];
		$searchGender = $criteria['search_gender'];
		$searchTxGroupCode = $criteria['search_tx_group_code'];
		$searchTxGroup = $criteria['search_tx_group'];
		$searchTxClassify = $criteria['search_tx_classify'];
		
		$isWhereClause = false;
	
		$qryProviderByCriteria = null;
	
		$qryProviderByCriteria = "select pm.npi as npi, pm.entity_type_code as entityCode, pm.name_prefix as namePrefix," .
					" pm.first_name as firstName, pm.last_name as lastName, pm.middle_name as middleName," .
					" pm.gender_code as gender, pm.ofc_first_line_addrs as firstLineAddress," .
					" pm.ofc_second_line_addrs secondLineAddress, pm.ofc_city_name as cityName," .
					" pm.ofc_state_name as stateName, pm.ofc_postal_code as postalCode, ".
					" pm.ofc_country_code as countryCode, pm.ofc_telephone_num as telephoneNum, ".
					" pm.ofc_fax_num as faxNum, pm.taxonomy_code_info as taxonomyCode, ".
					" pm.taxonomy_code_info as taxonomyGroup, taxonomy_spl_info as taxonomySpl, '' as taxonomyClsfy ".										
					" from provider_mst pm";
					
			
			if (AppUtil::IsNotNullOrEmptyString($searchGender)) {
				if ($isWhereClause){
					$qryProviderByCriteria = $qryProviderByCriteria . " and pm.gender_code in ('".$searchGender."')";
				}else{
					$qryProviderByCriteria = $qryProviderByCriteria . " where pm.gender_code in ('".$searchGender."')";
					$isWhereClause = true;
				}
			}

			if (AppUtil::IsNotNullOrEmptyString($searchStateCode)) {
				if ($isWhereClause){
					$qryProviderByCriteria = $qryProviderByCriteria . " and pm.ofc_state_name = '".$searchStateCode."'";
				}else{
					$qryProviderByCriteria = $qryProviderByCriteria . " where pm.ofc_state_name = '".$searchStateCode."'";
					$isWhereClause = true;
				}
				
			}
			
			
			if (AppUtil::IsNotNullOrEmptyString($searchTaxonomyCode)) {
				if ($isWhereClause){
					$qryProviderByCriteria = $qryProviderByCriteria . " and find_in_set ('".$searchTaxonomyCode."',pm.taxonomy_code_info) ";
				}else{
					$qryProviderByCriteria = $qryProviderByCriteria . " where find_in_set ('".$searchTaxonomyCode."',pm.taxonomy_code_info)";
					$isWhereClause = true;
				}
			}else{
				if (AppUtil::IsNotNullOrEmptyString($searchTxGroupCode)) {
					if ($isWhereClause){
						$qryProviderByCriteria = $qryProviderByCriteria . " and find_in_set ('".$searchTxGroup."',pm.taxonomy_group_info)  ";
					}else{
						$qryProviderByCriteria = $qryProviderByCriteria . " where and find_in_set ('".$searchTxGroup."',pm.taxonomy_group_info) ";
						$isWhereClause = true;
					}
				}
				
				if (AppUtil::IsNotNullOrEmptyString($searchTxClassify)) {
					if ($isWhereClause){
						$qryProviderByCriteria = $qryProviderByCriteria . " and find_in_set ('".$searchTxClassify."',pm.taxonomy_classify_info)  ";
					}else{
						$qryProviderByCriteria = $qryProviderByCriteria . " where and find_in_set ('".$searchTxClassify."',pm.taxonomy_classify_info) ";
						$isWhereClause = true;
					}
				}
			}

			
			if (AppUtil::isDoctor($providerType)){
				if ($isWhereClause){
					$qryProviderByCriteria = $qryProviderByCriteria . " and ((TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',1), '&',-1)) like '10%')"
							. " or (TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',2), '&',-1)) like '10%')"
							. " or (TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',3), '&',-1)) like '10%')"
							. " or (TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',1), '&',-1)) like '10%')"
							. " or (TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',2), '&',-1)) like '10%')"
							. " or (TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',3), '&',-1)) like '10%'))";
				}else{
					$qryProviderByCriteria = $qryProviderByCriteria . " where ((TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',1), '&',-1)) like '10%')"
							. " or (TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',2), '&',-1)) like '10%')"
							. " or (TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',3), '&',-1)) like '10%')"
							. " or (TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',1), '&',-1)) like '10%')"
							. " or (TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',2), '&',-1)) like '10%')"
							. " or (TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',3), '&',-1)) like '10%'))";
					$isWhereClause = true;
				}
			}
			
			if (AppUtil::isHospital($providerType)){
				if ($isWhereClause){
					$qryProviderByCriteria = $qryProviderByCriteria . " and ((TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',1), '&',-1)) like '10%')"
							. " or (TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',2), '&',-1)) like '10%')"
							. " or (TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',3), '&',-1)) like '10%')"
							. " or (TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',1), '&',-1)) like '10%')"
							. " or (TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',2), '&',-1)) like '10%')"
							. " or (TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',3), '&',-1)) like '10%'))";
				}else{
					$qryProviderByCriteria = $qryProviderByCriteria . " where ((TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',1), '&',-1)) like '10%')"
							. " or (TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',2), '&',-1)) like '10%')"
							. " or (TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',3), '&',-1)) like '10%')"
							. " or (TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',1), '&',-1)) like '10%')"
							. " or (TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',2), '&',-1)) like '10%')"
							. " or (TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',3), '&',-1)) like '10%'))";
							$isWhereClause = true;
				}
			}
			
			if (AppUtil::isLab($providerType)){
				if ($isWhereClause){
					$qryProviderByCriteria = $qryProviderByCriteria . " and ((TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',1), '&',-1)) like '10%')"
							. " or (TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',2), '&',-1)) like '10%')"
							. " or (TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',3), '&',-1)) like '10%')"
							. " or (TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',1), '&',-1)) like '10%')"
							. " or (TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',2), '&',-1)) like '10%')"
							. " or (TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',3), '&',-1)) like '10%'))";
				}else{
					$qryProviderByCriteria = $qryProviderByCriteria . " where ((TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',1), '&',-1)) like '10%')"
							. " or (TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',2), '&',-1)) like '10%')"
							. " or (TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',3), '&',-1)) like '10%')"
							. " or (TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',1), '&',-1)) like '10%')"
							. " or (TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',2), '&',-1)) like '10%')"
							. " or (TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',3), '&',-1)) like '10%'))";
							$isWhereClause = true;
				}
			}
			
			if (AppUtil::isPharmacy($providerType)){
				if ($isWhereClause){
					$qryProviderByCriteria = $qryProviderByCriteria . " and ((TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',1), '&',-1)) like '10%')"
							. " or (TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',2), '&',-1)) like '10%')"
							. " or (TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',3), '&',-1)) like '10%')"
							. " or (TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',1), '&',-1)) like '10%')"
							. " or (TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',2), '&',-1)) like '10%')"
							. " or (TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',3), '&',-1)) like '10%'))";
				}else{
					$qryProviderByCriteria = $qryProviderByCriteria . " where ((TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',1), '&',-1)) like '10%')"
							. " or (TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',2), '&',-1)) like '10%')"
							. " or (TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',3), '&',-1)) like '10%')"
							. " or (TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',1), '&',-1)) like '10%')"
							. " or (TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',2), '&',-1)) like '10%')"
							. " or (TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.taxonomy_code_info,'&',3), '&',-1)) like '10%'))";
															$isWhereClause = true;
				}
			}
			
			
			
			
			
			$qryProviderByCriteria = $qryProviderByCriteria . " group by npi, entityCode, namePrefix, firstName, lastName, middleName, ".
					" gender,  firstLineAddress, secondLineAddress,  cityName, stateName,  postalCode,".
					" countryCode,  telephoneNum, faxNum, taxonomyCode, taxonomyGroup, taxonomySpl, taxonomyClsfy";
			
			$qryProviderByCriteria = $qryProviderByCriteria . " limit 100";
		//print_r($qryProviderByCriteria);
		return $qryProviderByCriteria;
	}
	
// 	private function getCriteriaQuery($criteria){
// 		$searchNpi = $criteria['search_npi'];
// 		$searchName = $criteria['search_name'];
// 		$searchAddress = $criteria['search_address'];
// 		//$searchMiles = $criteria['search_miles'];
// 		$searchGender = $criteria['search_gender'];
// 		$searchSpl = $criteria['search_specialist'];
// 		//$searchCarrier = $criteria['search_carrier'];
// 		//$sortBy = $criteria['sortby'];
// 		$withAddrs = $criteria['with_addrs'];
// 		//$start = $criteria['start'];
// 		//$length = $criteria['length'];
		
// 		$qryProviderByCriteria = null;
		
// 		if ($withAddrs){
// 			$qryProviderByCriteria = "select pm.npi as npi, pm.entity_type_code as entityCode, pm.name_prefix as namePrefix, pm.first_name as firstName, " .
// 					" pm.last_name as lastName, pm.middle_name as middleName, pm.gender_code as gender, pad.addrs_type as addrsType," .
// 					" pad.first_line_addrs as firstLineAddrs, pad.second_line_addrs as secLineAddrs, pad.city_name as city," .
// 					" pad.state_name as state, pad.postal_code as postalCode, pad.telephone_num as telephoneNum, pad.fax_num as faxNum," .
// 					" tm.taxonomy_code  as taxonomyCode, REPLACE(tm.taxonomy_group,'\"','') as taxonomyGroup," .
// 					" REPLACE(REPLACE(trim(tm.taxonomy_spl),'\"',''), '\/', ' ') as taxonomySpl," .
// 					" REPLACE(REPLACE(trim(tm.taxonomy_classify),'\"',''), '\/', ' ') as taxonomyClsfy".
// 					" from provider_mst pm";
				
			
// 			$qryProviderByCriteria = $qryProviderByCriteria . ", provider_addrs_dtl pad";
			
// 			$qryProviderByCriteria = $qryProviderByCriteria . ", provider_taxonomy_dtl ptd, taxonomy_mst tm where 1=1";
			
			
// 			if (AppUtil::IsNotNullOrEmptyString($searchNpi)) {
// 				$qryProviderByCriteria = $qryProviderByCriteria . " and pm.npi like '%".$searchNpi."%'";
// 			}
			
// 			if (AppUtil::IsNotNullOrEmptyString($searchGender)) {
// 				$qryProviderByCriteria = $qryProviderByCriteria . " and pm.gender_code like '%".$searchGender."%'";
// 			}
			
// 			if (AppUtil::IsNotNullOrEmptyString($searchName)) {
// 				$qryProviderByCriteria = $qryProviderByCriteria . " and (pm.first_name like '%".$searchName."%' or pm.middle_name like '%".$searchName."%' or pm.last_name like '%".$searchName."%')";
// 			}
			
// 			$qryProviderByCriteria = $qryProviderByCriteria . " and pm.npi = pad.npi";
// 			if (AppUtil::IsNotNullOrEmptyString($searchAddress)) {
// 				$qryProviderByCriteria = $qryProviderByCriteria . " and (pad.first_line_addrs like '%".$searchAddress."%' or pad.second_line_addrs like '%".$searchAddress."%'  or pad.city_name like '%".$searchAddress."%' or pad.postal_code like '%".$searchAddress."%')";
// 			}
			
// 			$qryProviderByCriteria = $qryProviderByCriteria . " and pm.npi = ptd.npi and ptd.taxonomy_code is not null and ptd.taxonomy_code = tm.taxonomy_code";
// 			if (AppUtil::IsNotNullOrEmptyString($searchSpl)) {
// 				$qryProviderByCriteria = $qryProviderByCriteria . " and (tm.taxonomy_spl like '%".$searchSpl."%' or tm.taxonomy_group like '%".$searchSpl."%' or tm.taxonomy_classify like '%".$searchSpl."%')";
// 			}
				
// 			$qryProviderByCriteria = $qryProviderByCriteria . " group by npi, entityCode, namePrefix, firstName, lastName, middleName, gender, addrsType, firstLineAddrs, secLineAddrs, city, state, postalCode, telephoneNum, faxNum, taxonomyCode, taxonomyGroup, taxonomySpl, taxonomyClsfy";
			
// 		}else {
// 			$qryProviderByCriteria = "select pm.npi as npi, pm.entity_type_code as entityCode, pm.name_prefix as namePrefix, pm.first_name as firstName, " .
// 					" pm.last_name as lastName, pm.middle_name as middleName, pm.gender_code as gender," .
// 					" tm.taxonomy_code  as taxonomyCode, REPLACE(tm.taxonomy_group,'\"','') as taxonomyGroup," .
// 					" REPLACE(REPLACE(trim(tm.taxonomy_spl),'\"',''), '\/', ' ') as taxonomySpl," .
// 					" REPLACE(REPLACE(trim(tm.taxonomy_classify),'\"',''), '\/', ' ') as taxonomyClsfy".
// 					" from provider_mst pm";
			
// 				if (AppUtil::IsNotNullOrEmptyString($searchAddress)) {
// 					$qryProviderByCriteria = $qryProviderByCriteria . ", provider_addrs_dtl pad";
// 				}	
				
// 				$qryProviderByCriteria = $qryProviderByCriteria . ", provider_taxonomy_dtl ptd, taxonomy_mst tm where 1=1";

// 				if (AppUtil::IsNotNullOrEmptyString($searchNpi)) {
// 					$qryProviderByCriteria = $qryProviderByCriteria . " and pm.npi like '%".$searchNpi."%'";
// 				}
				
// 				if (AppUtil::IsNotNullOrEmptyString($searchGender)) {
// 					$qryProviderByCriteria = $qryProviderByCriteria . " and pm.gender_code like '%".$searchGender."%'";
// 				}
				
// 				if (AppUtil::IsNotNullOrEmptyString($searchName)) {
// 					$qryProviderByCriteria = $qryProviderByCriteria . " and (pm.first_name like '%".$searchName."%' or pm.middle_name like '%".$searchName."%' or pm.last_name like '%".$searchName."%')";
// 				}

// 				if (AppUtil::IsNotNullOrEmptyString($searchAddress)) {
// 					$qryProviderByCriteria = $qryProviderByCriteria . " and pm.npi = pad.npi";
// 					$qryProviderByCriteria = $qryProviderByCriteria . " and (pad.first_line_addrs like '%".$searchAddress."%' or pad.second_line_addrs like '%".$searchAddress."%'  or pad.city_name like '%".$searchAddress."%' or pad.postal_code like '%".$searchAddress."%')";
// 				}
				
// 				$qryProviderByCriteria = $qryProviderByCriteria . " and pm.npi = ptd.npi and ptd.taxonomy_code is not null and ptd.taxonomy_code = tm.taxonomy_code";
// 				if (AppUtil::IsNotNullOrEmptyString($searchSpl)) {
// 					$qryProviderByCriteria = $qryProviderByCriteria . " and (tm.taxonomy_spl like '%".$searchSpl."%' or tm.taxonomy_group like '%".$searchSpl."%' or tm.taxonomy_classify like '%".$searchSpl."%')";
// 				}
					
// 				$qryProviderByCriteria = $qryProviderByCriteria . " group by npi, entityCode, namePrefix, firstName, lastName, middleName, gender, taxonomyCode, taxonomyGroup, taxonomySpl, taxonomyClsfy";
				
// 				$qryProviderByCriteria = $qryProviderByCriteria . " limit 100";
// 		}
// 		//print_r($qryProviderByCriteria);
// 		return $qryProviderByCriteria;
// 	}
	
	
	public function getProviderMstByNPI($npi) {
		$connPDO = null;
		$stmt = null;
		$result = array ();
		try {
			//if ($this->connectionDB !== null) {
			$connPDO = ConnectionDB::getInstance ()->getConnection();
			//$connPDO = $this->connectionDB->getConnection ();
			if ($connPDO !== null) {
				$connPDO->beginTransaction ();
				$qryProviderBySpl = "select npi, entity_type_code, replace_npi, emp_id_num, org_name, last_name, first_name,".
						" middle_name, name_prefix, name_suffix, credential_text, enum_date, last_update_date,".
						" npi_deactivation_reason_code, npi_deactivation_date, npi_reactivation_date, gender_code,".
						" official_last_name, official_first_name, official_middle_name, official_title_position,".
						" official_telephone_num, official_name_prefix, official_name_suffix, official_credential_text,".
						" is_sole_proprietor, is_org_subpart, parent_org_lbn, parent_org_tin".
						" from provider_mst where npi = ".$npi;
				$stmt = $connPDO->prepare ( $qryProviderBySpl );
				//$stmt->bindParam ( ":spl", $spl );
				$stmt->setFetchMode ( PDO::FETCH_ASSOC );
				$stmt->execute ();
				$result = $stmt->fetchAll ();
				$connPDO->commit ();
			}
			//}
		} catch ( PDOException $e ) {
			if ($connPDO) {
				$connPDO->rollBack ();
			}
	
			die ( "getProviderMstByNPI - Failed: " . $e->getMessage () );
		} catch ( Exception $e ) {
			if ($connPDO) {
				$connPDO->rollBack ();
			}
	
			die ( "getProviderMstByNPI - Failed: " . $e->getMessage () );
		} finally {
			if ($stmt !== null) {
				$stmt = null;
			}
	
			if ($connPDO !== null) {
				$connPDO = null;
			}
		}
		return $result;
	}
	
	public function getProviderOrgDtlByNPI($npi) {
		$connPDO = null;
		$stmt = null;
		$result = array ();
		try {
			//if ($this->connectionDB !== null) {
			$connPDO = ConnectionDB::getInstance ()->getConnection();
			//$connPDO = $this->connectionDB->getConnection ();
			if ($connPDO !== null) {
				$connPDO->beginTransaction ();
				$qryProviderBySpl = "select npi, npi_org_num, oth_org_name, oth_org_type_code, oth_org_last_name, oth_org_first_name, ".
						" oth_org_middle_name, oth_org_name_prefix, oth_org_name_suffix, oth_credential_text, oth_last_name_type_code".
						" from provider_org_dtl where npi =  ".$npi;
				$stmt = $connPDO->prepare ( $qryProviderBySpl );
				//$stmt->bindParam ( ":spl", $spl );
				$stmt->setFetchMode ( PDO::FETCH_ASSOC );
				$stmt->execute ();
				$result = $stmt->fetchAll ();
				$connPDO->commit ();
			}
			//}
		} catch ( PDOException $e ) {
			if ($connPDO) {
				$connPDO->rollBack ();
			}
	
			die ( "getProviderOrgDtlByNPI - Failed: " . $e->getMessage () );
		} catch ( Exception $e ) {
			if ($connPDO) {
				$connPDO->rollBack ();
			}
	
			die ( "getProviderOrgDtlByNPI - Failed: " . $e->getMessage () );
		} finally {
			if ($stmt !== null) {
				$stmt = null;
			}
	
			if ($connPDO !== null) {
				$connPDO = null;
			}
		}
		return $result;
	}
	
	public function getProviderAddrsDtlByNPI($npi) {
		$connPDO = null;
		$stmt = null;
		$result = array ();
		try {
			//if ($this->connectionDB !== null) {
			$connPDO = ConnectionDB::getInstance ()->getConnection();
			//$connPDO = $this->connectionDB->getConnection ();
			if ($connPDO !== null) {
				$connPDO->beginTransaction ();
				$qryProviderBySpl = " select pa.npi, pa.npi_addrs_num, pa.addrs_type, pa.first_line_addrs, pa.second_line_addrs, pa.city_name, ".
						" pa.state_name as state_code, zm.state_name, pa.postal_code, pa.country_code, zm.country_name,".
						" zm.latitude, zm.longtitude, pa.telephone_num, pa.fax_num".
						" from provider_addrs_dtl pa left outer join zip_mst zm on zip_code = SUBSTRING(postal_code, 1, 5)".
						" where npi = ".$npi.
						" group by pa.npi, pa.npi_addrs_num, pa.addrs_type, pa.first_line_addrs, pa.second_line_addrs, pa.city_name, ".
						" state_code, zm.state_name, pa.postal_code, pa.country_code, zm.country_name, zm.latitude, zm.longtitude,".
						" pa.telephone_num, pa.fax_num";
				$stmt = $connPDO->prepare ( $qryProviderBySpl );
				//$stmt->bindParam ( ":spl", $spl );
				$stmt->setFetchMode ( PDO::FETCH_ASSOC );
				$stmt->execute ();
				$result = $stmt->fetchAll ();
				$connPDO->commit ();
			}
			//}
		} catch ( PDOException $e ) {
			if ($connPDO) {
				$connPDO->rollBack ();
			}
	
			die ( "getProviderAddrsDtlByNPI - Failed: " . $e->getMessage () );
		} catch ( Exception $e ) {
			if ($connPDO) {
				$connPDO->rollBack ();
			}
	
			die ( "getProviderAddrsDtlByNPI - Failed: " . $e->getMessage () );
		} finally {
			if ($stmt !== null) {
				$stmt = null;
			}
	
			if ($connPDO !== null) {
				$connPDO = null;
			}
		}
		return $result;
	}
	
	public function getProviderIdentifierDtlByNPI($npi) {
		$connPDO = null;
		$stmt = null;
		$result = array ();
		try {
			//if ($this->connectionDB !== null) {
			$connPDO = ConnectionDB::getInstance ()->getConnection();
			//$connPDO = $this->connectionDB->getConnection ();
			if ($connPDO !== null) {
				$connPDO->beginTransaction ();
				$qryProviderBySpl = "select npi, npi_identifier_num, oth_identifier, oth_identifier_code,".
						" oth_identifier_state, oth_identifier_issuer from provider_identifier_dtl".
						"  where npi = ".$npi;
				$stmt = $connPDO->prepare ( $qryProviderBySpl );
				//$stmt->bindParam ( ":spl", $spl );
				$stmt->setFetchMode ( PDO::FETCH_ASSOC );
				$stmt->execute ();
				$result = $stmt->fetchAll ();
				$connPDO->commit ();
			}
			//}
		} catch ( PDOException $e ) {
			if ($connPDO) {
				$connPDO->rollBack ();
			}
	
			die ( "getProviderIdentifierDtlByNPI - Failed: " . $e->getMessage () );
		} catch ( Exception $e ) {
			if ($connPDO) {
				$connPDO->rollBack ();
			}
	
			die ( "getProviderIdentifierDtlByNPI - Failed: " . $e->getMessage () );
		} finally {
			if ($stmt !== null) {
				$stmt = null;
			}
	
			if ($connPDO !== null) {
				$connPDO = null;
			}
		}
		return $result;
	}
	
	public function getProviderTaxonomyDtlByNPI($npi) {
		$connPDO = null;
		$stmt = null;
		$result = array ();
		try {
			//if ($this->connectionDB !== null) {
			$connPDO = ConnectionDB::getInstance ()->getConnection();
			//$connPDO = $this->connectionDB->getConnection ();
			if ($connPDO !== null) {
				$connPDO->beginTransaction ();
				$qryProviderBySpl = "select pt.npi, pt.npi_taxonomy_num, pt.taxonomy_code, tm.taxonomy_spl,".
						" tm.taxonomy_group, tm.taxonomy_classify, tm.taxonomy_definition, taxonomy_notes,".
						" pt.license_num, pt.license_state_code, pt.primary_taxonomy_switch".
						" from provider_taxonomy_dtl pt left outer join taxonomy_mst tm".
						" on tm.taxonomy_code = pt.taxonomy_code".
						"  where npi = ".$npi.
						" group by pt.npi, pt.npi_taxonomy_num, pt.taxonomy_code, tm.taxonomy_spl,".
						" tm.taxonomy_group, tm.taxonomy_classify, tm.taxonomy_definition, taxonomy_notes,".
						" pt.license_num, pt.license_state_code, pt.primary_taxonomy_switch";
				$stmt = $connPDO->prepare ( $qryProviderBySpl );
				//$stmt->bindParam ( ":spl", $spl );
				$stmt->setFetchMode ( PDO::FETCH_ASSOC );
				$stmt->execute ();
				$result = $stmt->fetchAll ();
				$connPDO->commit ();
			}
			//}
		} catch ( PDOException $e ) {
			if ($connPDO) {
				$connPDO->rollBack ();
			}
	
			die ( "getProviderTaxonomyDtlByNPI - Failed: " . $e->getMessage () );
		} catch ( Exception $e ) {
			if ($connPDO) {
				$connPDO->rollBack ();
			}
	
			die ( "getProviderTaxonomyDtlByNPI - Failed: " . $e->getMessage () );
		} finally {
			if ($stmt !== null) {
				$stmt = null;
			}
	
			if ($connPDO !== null) {
				$connPDO = null;
			}
		}
		return $result;
	}
}

?>