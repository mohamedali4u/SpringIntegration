<?php
namespace model;

use common\ConnectionDB;
use common\AppUtil;
use PDO;

class TaxonomyDA {
	
	public function getAllSpeciality() {
		$connPDO = null;
		$stmt = null;
		$result = array ();
		try {
			//if ($this->connectionDB !== null) {
				$connPDO = ConnectionDB::getInstance ()->getConnection();
				//$connPDO = $this->connectionDB->getConnection ();
				if ($connPDO !== null) {
					$connPDO->beginTransaction ();
					$qryAllTaxonomy = "select tm.taxonomy_spl as taxonomySpl, tm.taxonomy_code as taxonomyCode" 
							. " from provider_taxonomy_dtl ptd, taxonomy_mst tm "
							. " where ptd.taxonomy_code is not null "
							. " and ptd.taxonomy_code = tm.taxonomy_code "
							. " and tm.taxonomy_spl is not null"
							. " group by tm.taxonomy_code, tm.taxonomy_spl";
					$stmt = $connPDO->prepare ( $qryAllTaxonomy );
					$stmt->setFetchMode ( PDO::FETCH_ASSOC );
					$stmt->execute ();
					$result = $stmt->fetchAll ();
					$connPDO->commit ();
				}
			//}
		} catch ( PDOException $e ) {
			if ($connPDO) {
				$connPDO->rollBack ();
			}
			
			die ( "getAllStates - Failed: " . $e->getMessage () );
		} catch ( Exception $e ) {
			if ($connPDO) {
				$connPDO->rollBack ();
			}
			
			die ( "getAllStates - Failed: " . $e->getMessage () );
		} finally {
			if ($stmt !== null) {
				$stmt = null;
			}
			
			if ($connPDO !== null) {
				$connPDO = null;
			}
		}
		return $result;
	}
	
}

?>