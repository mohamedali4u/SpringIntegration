<?php
namespace model;

use common\ConnectionDB;
use common\AppUtil;
use PDO;

class TaxonomyDA {
	
	public function getAllTaxonomyGroup() {
		$connPDO = null;
		$stmt = null;
		$result = array ();
		try {
			//if ($this->connectionDB !== null) {
			$connPDO = ConnectionDB::getInstance ()->getConnection();
			//$connPDO = $this->connectionDB->getConnection ();
			if ($connPDO !== null) {
				$connPDO->beginTransaction ();
				$qryAllGroup = "select distinct substring(taxonomy_code, 1, 2) as txGroupCode, taxonomy_group as txGroup" 
						. " from taxonomy_mst"
						. " where taxonomy_code is not null and taxonomy_group is not null" 
						. " and length(taxonomy_code) > 0 and length(taxonomy_group) > 0";
				$stmt = $connPDO->prepare ( $qryAllGroup );
				$stmt->setFetchMode ( PDO::FETCH_ASSOC );
				$stmt->execute ();
				$result = $stmt->fetchAll ();
				$connPDO->commit ();
			}
			//}
		} catch ( PDOException $e ) {
			if ($connPDO) {
				$connPDO->rollBack ();
			}
				
			die ( "getAllTaxonomyGroup - Failed: " . $e->getMessage () );
		} catch ( Exception $e ) {
			if ($connPDO) {
				$connPDO->rollBack ();
			}
				
			die ( "getAllTaxonomyGroup - Failed: " . $e->getMessage () );
		} finally {
			if ($stmt !== null) {
				$stmt = null;
			}
				
			if ($connPDO !== null) {
				$connPDO = null;
			}
		}
		return $result;
	}
	
	
	public function getAllClassifyByGroup($txGroupCode, $txGroup) {
		$connPDO = null;
		$stmt = null;
		$result = array ();
		try {
			//if ($this->connectionDB !== null) {
			$connPDO = ConnectionDB::getInstance ()->getConnection();
			//$connPDO = $this->connectionDB->getConnection ();
			if ($connPDO !== null) {
				$connPDO->beginTransaction ();
				$qryAllClassify = "select distinct taxonomy_classify as txClassifyCode, taxonomy_classify as txClassify"
						. " from taxonomy_mst"
						. " where taxonomy_classify is not null and length(taxonomy_classify) > 0" 
						. " and (substring(taxonomy_code, 1, 2) = '".$txGroupCode."') "
						. " and taxonomy_group like '" . $txGroup ."'" ;
				$stmt = $connPDO->prepare ( $qryAllClassify );
				$stmt->setFetchMode ( PDO::FETCH_ASSOC );
				$stmt->execute ();
				$result = $stmt->fetchAll ();
				$connPDO->commit ();
			}
			//}
		} catch ( PDOException $e ) {
			if ($connPDO) {
				$connPDO->rollBack ();
			}
	
			die ( "getAllTaxonomyGroup - Failed: " . $e->getMessage () );
		} catch ( Exception $e ) {
			if ($connPDO) {
				$connPDO->rollBack ();
			}
	
			die ( "getAllTaxonomyGroup - Failed: " . $e->getMessage () );
		} finally {
			if ($stmt !== null) {
				$stmt = null;
			}
	
			if ($connPDO !== null) {
				$connPDO = null;
			}
		}
		return $result;
	}
	
	public function getAllSplByGroup($txGroupCode, $txGroup, $txClassify) {
		$connPDO = null;
		$stmt = null;
		$result = array ();
		try {
			//if ($this->connectionDB !== null) {
			$connPDO = ConnectionDB::getInstance ()->getConnection();
			//$connPDO = $this->connectionDB->getConnection ();
			if ($connPDO !== null) {
				$connPDO->beginTransaction ();
				$qryAllTaxonomy = "select distinct taxonomy_code as taxonomyCode, taxonomy_spl as taxonomySpl" 
						. " from taxonomy_mst"
						. " where taxonomy_spl is not null and length(taxonomy_spl) > 0 "
						. " and (substring(taxonomy_code, 1, 2) = '". $txGroupCode ."') "
						. " and taxonomy_group like '". $txGroup ."' "
						. " and taxonomy_classify like '". $txClassify. "'";
				$stmt = $connPDO->prepare ( $qryAllTaxonomy );
				$stmt->setFetchMode ( PDO::FETCH_ASSOC );
				$stmt->execute ();
				$result = $stmt->fetchAll ();
				$connPDO->commit ();
			}
			//}
		} catch ( PDOException $e ) {
			if ($connPDO) {
				$connPDO->rollBack ();
			}
				
			die ( "getAllStates - Failed: " . $e->getMessage () );
		} catch ( Exception $e ) {
			if ($connPDO) {
				$connPDO->rollBack ();
			}
				
			die ( "getAllStates - Failed: " . $e->getMessage () );
		} finally {
			if ($stmt !== null) {
				$stmt = null;
			}
				
			if ($connPDO !== null) {
				$connPDO = null;
			}
		}
		return $result;
	}
}

?>