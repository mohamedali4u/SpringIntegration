<?php
require 'common/AppConstants.php';
require 'common/ConfigUtil.php';
require 'resource/config.php';
require 'common/ConnectionDB.php';
require 'model/ProviderDA.php';
require 'common/AppUtil.php';

use model\ProviderDA;
$response = array();
$providerDA = new ProviderDA();
//$criteria = array("search_npi"=>"1811990971", "search_name"=>"ROSEANN","search_address"=>"NASHVILLE", "search_gender"=>"F", "search_specialist"=>"Obstetrics", "with_addrs"=>false);
//$response = $providerDA->getProviderByCriteria($criteria);

$criteria = array("search_keyword"=>"", "search_taxonomy_code"=>"1223G0001X","search_state_code"=>"", "search_gender"=>"F");
$response = $providerDA->getPDInfoByCriteria($criteria, true);
print_r($response);

// $criteria = array("search_keyword"=>"", "search_taxonomy_code"=>"","search_state_code"=>"NY", "search_gender"=>"M");
// $response = $providerDA->getPDInfoByCriteria($criteria, true);
// print_r($response);

?>