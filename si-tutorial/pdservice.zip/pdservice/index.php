<?php
require 'Slim/Slim.php';

\Slim\Slim::registerAutoloader();

$app = new \Slim\Slim();

// Automatically load Controller files
$routers = glob('controller/*Controller.php');
foreach ($routers as $router) {
    require $router;
}

$app->run();

?>