use providerdb;
select * from taxonomy_mst;

select distinct substring(taxonomy_code, 1, 2) as txGroupCode, taxonomy_group as txGroup from taxonomy_mst
where taxonomy_code is not null and taxonomy_group is not null
and length(taxonomy_code) > 0 and length(taxonomy_group) > 0

set escape on;

select distinct taxonomy_classify as txClassifyCode, taxonomy_classify as txClassify from taxonomy_mst 
where taxonomy_classify is not null and length(taxonomy_classify) > 0
and (substring(taxonomy_code, 1, 2) = '10')
and taxonomy_group like 'Behavioral Health \& Social Service Providers'

select distinct taxonomy_code as taxonomyCode, taxonomy_spl as taxonomySpl from taxonomy_mst 
where taxonomy_spl is not null and length(taxonomy_spl) > 0
and (substring(taxonomy_code, 1, 2) = '10')
and taxonomy_group like 'Behavioral Health \& Social Service Providers'
and taxonomy_classify like 'Counselor'

SELECT SUBSTRING_INDEX('www.mytestpage.info','.',1);
SELECT SUBSTRING_INDEX('www.mytestpage.info','.',2);
SELECT SUBSTRING_INDEX('www.mytestpage.info','.',3);

SELECT SUBSTRING_INDEX(SUBSTRING_INDEX('www.mytestpage.info','.',1), '.',-1);
SELECT SUBSTRING_INDEX(SUBSTRING_INDEX('www.mytestpage.info','.',2), '.',-1);
SELECT SUBSTRING_INDEX(SUBSTRING_INDEX('www.mytestpage.info','.',3), '.',-1);

select * from taxonomy_mst 
where SUBSTRING_INDEX(taxonomy_group,'&',2) like 'Beh%'

select * from taxonomy_mst 
where TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(taxonomy_group,'&',2), '&',-1)) like 'Soc%'

SELECT ip, SUBSTRING_INDEX(ip,'.',1) AS part1, 
SUBSTRING_INDEX(SUBSTRING_INDEX(ip,'.',2),'.',-1) AS part2, 
SUBSTRING_INDEX(SUBSTRING_INDEX(ip,'.',-2),'.',1) AS part3, 
SUBSTRING_INDEX(ip,'.',-1) AS part4  FROM log_file;

