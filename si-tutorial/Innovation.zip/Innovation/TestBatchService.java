
public class TestBatchService {
	public static void main(String[] args) {
		int i = 1;
		for(;;){
			System.out.println("Hello Batch");
			i++;
			//if (i == 20) {
			//	break;
			//}
		}
	}

}
