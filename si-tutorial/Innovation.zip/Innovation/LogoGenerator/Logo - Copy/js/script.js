var canvas, ctx,
    save, inputText,
    imgW, imgH, setSize,
    fontSize, size,
    text, linehight,
    font1, font2, font3,
    fontStyle1, fontStyle2, fontStyle3,
    fontExample1, fontExample2, fontExample3,
    sizesetFB, sizesetSQ, sizesetTW, sizesetCU,
    colorsetBW, colorsetRW, colorsetWR, customCU, customContainer,
    random, randomNeue, reset,
    bgImg, bgImg2, bgWidth, bgHeight, bgWidth2, bgHeight2,
    showUnderline;


var emdashWidth;

var font = ["NeueDisplay", "Neue", "Matrix", "ITCFranklinGothicStd", "Irma"];
var fontStyle = [
    ['Black', 'Wide', 'Ultra'],
    ['Regular', 'RegularItalic', 'Black', 'Bold', 'BoldItalic'],
    ['Regular', 'Bold'],
    ['BookCondensed', 'MediumCondensed'],
    ['Extralight', 'Light', 'Medium', 'Bold']
]
var defaultFontStyle = [0, 1, 2];
var currentFont = {font1: "NeueDisplay-Black", font2: "NeueDisplay-Wide", font3: "NeueDisplay-Ultra"};
var colorset = {fg: '#fff', bg: '#e82e21'};
var customFontColor = '#fff';

function init () {
    resizeSecondFix();

    canvas = document.getElementById('cvs');
    ctx = canvas.getContext('2d');
    font1 = document.getElementById('font1');
    fontStyle1 = document.getElementById('font1-style');
    font2 = document.getElementById('font2');
    fontStyle2 = document.getElementById('font2-style'); 
    font3 = document.getElementById('font3');
    fontStyle3 = document.getElementById('font3-style');
    fontExample1 = document.getElementById('font1-example');
    fontExample2 = document.getElementById('font2-example');
    fontExample3 = document.getElementById('font3-example');
    colorsetBW = document.getElementById('black-white');
    colorsetRW = document.getElementById('red-white');
    colorsetWR = document.getElementById('white-red');
    colorsetCU = document.getElementById('custom');
    customContainer = document.getElementById('custom-container');
    fontColor = document.getElementById('font-color-selection');
    bgUpload = document.getElementById('bg-upload');
    random = document.getElementById('random');
    randomNeue = document.getElementById('random-neue');
    reset = document.getElementById('reset');
    sizesetFB = document.getElementById('fb-cover');
    sizesetSQ = document.getElementById('square');
    sizesetTW = document.getElementById('twitter-header');
    sizesetCU = document.getElementById('size-custom');
    showUnderline = document.getElementById('show-underline-check');

    save = document.getElementById('save');
    imgW = document.getElementById('imgW');
    imgH = document.getElementById('imgH');
    setSize = document.getElementById('setSize');
    fontSize = document.getElementById('fontSize');
    inputText = document.getElementById('inputText');

	text = inputText.value;
	ctx.font = fontSize.value + 'px ' + "NeueDisplay-Black";
	ctx.textBaseline = 'top';

    bgImg = new Image();
    bgImg2 = new Image();

    emdashWidth = ctx.measureText("â€”").width;
    // console.log(emdashWidth);

    initfont();
	setTest();
    bind();
}

function initfont () {
    selectFont(font1, fontStyle1, 0, 0, fontExample1);
    selectFont(font2, fontStyle2, 0, 1, fontExample2);
    selectFont(font3, fontStyle3, 0, 2, fontExample3);
}

function bind () {
    inputText.addEventListener("keyup", function (e) {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        setTest();
    });
    save.addEventListener("click", function (e) {
        download(canvas, 'logo.png');
    });
    sizesetFB.addEventListener("click", function (e) {
        canvas.width = 851;
        canvas.height = 315;
        imgW.value = 851;
        imgH.value = 315;
        ctx.textBaseline = 'top';
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        if(colorsetCU.checked && bgImg2 != undefined) {
            changeBG();
        }
        setTest();
    });
    sizesetSQ.addEventListener("click", function (e) {
        canvas.width = 400;
        canvas.height = 400;
        imgW.value = 400;
        imgH.value = 400;
        ctx.textBaseline = 'top';
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        if(colorsetCU.checked && bgImg2 != undefined) {
            changeBG();
        }
        setTest();
    });
    sizesetTW.addEventListener("click", function (e) {
        canvas.width = 1050;
        canvas.height = 350;
        imgW.value = 1050;
        imgH.value = 350;
        ctx.textBaseline = 'top';
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        if(colorsetCU.checked && bgImg2 != undefined) {
            changeBG();
        }
        setTest();
    });
    imgW.addEventListener("keydown", function (e) {
        canvas.width = imgW.value;
        ctx.textBaseline = 'top';
        setTest();
    });
    imgW.addEventListener("change", function (e) {
        canvas.width = imgW.value;
        ctx.textBaseline = 'top';
        sizesetCU.checked = true;
        changeBG();
        setTest();
    });
    imgH.addEventListener("keydown", function (e) {
        canvas.height = imgH.value;
        ctx.textBaseline = 'top';
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        setTest();
    });
    imgH.addEventListener("change", function (e) {
        canvas.height = imgH.value;
        ctx.textBaseline = 'top';
        sizesetCU.checked = true;
        changeBG();
        setTest();
    });
    fontSize.addEventListener("keydown", function (e) {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        setTest();
    });
    fontSize.addEventListener("change", function (e) {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        setTest();
    });
    // setSize.addEventListener("click", function (e) {
    //     canvas.width = imgW.value;
    //     canvas.height = imgH.value;
    //     ctx.textBaseline = 'top';
    //     setTest();
    // });
    setFont.addEventListener("click", function (e) {
        setTest();
    });
    font1.addEventListener("change", function (e) {
        selectFontStyle(font1, fontStyle1, 0, fontExample1);
    });
    font2.addEventListener("change", function (e) {
        selectFontStyle(font2, fontStyle2, 0, fontExample2);
    });
    font3.addEventListener("change", function (e) {
        selectFontStyle(font3, fontStyle3, 0, fontExample3);
    });
    fontStyle1.addEventListener("change", function (e) {
        selectFontStyle(font1, fontStyle1, fontStyle1.selectedIndex, fontExample1);
    });
    fontStyle2.addEventListener("change", function (e) {
        selectFontStyle(font2, fontStyle2, fontStyle2.selectedIndex, fontExample2);
    });
    fontStyle3.addEventListener("change", function (e) {
        selectFontStyle(font3, fontStyle3, fontStyle3.selectedIndex, fontExample3);
    });
    colorsetBW.addEventListener("click", function (e) {
        colorset['fg'] = '#000';
        colorset['bg'] = '#fff';
        // customContainer.style.maxHeight = "0px";
        // customContainer.style.visibility = "hidden";
        // customContainer.style.opacity = 0;
        setTest();
    });
    colorsetRW.addEventListener("click", function (e) {
        colorset['fg'] = '#e82e21';
        colorset['bg'] = '#fff';
        // customContainer.style.maxHeight = "0px";
        // customContainer.style.visibility = "hidden";
        // customContainer.style.opacity = 0;
        setTest();
    });
    colorsetWR.addEventListener("click", function (e) {
        colorset['fg'] = '#fff';
        colorset['bg'] = '#e82e21';
        // customContainer.style.maxHeight = "0px";
        // customContainer.style.visibility = "hidden";
        // customContainer.style.opacity = 0;
        setTest();
    });
    colorsetCU.addEventListener("click", function (e) {
        colorset['fg'] = customFontColor;
        // customContainer.style.maxHeight = "45px";
        // customContainer.style.visibility = "visible";
        // customContainer.style.opacity = 1;
        setTest();
    });
    fontColor.addEventListener("change", function (e) {
        switch(fontColor.selectedIndex) {
            case 0:
                customFontColor = '#fff'
                break;
            case 1:
                customFontColor = '#e82e21';
                break;
            case 2:
                customFontColor = '#000';
                break;
        }
        colorsetCU.checked = true;
        colorset['fg'] = customFontColor;
        setTest();
    });
    bgUpload.addEventListener("click", function (e) {
        this.value = null;
    });
    bgUpload.addEventListener("change", function (e) {
        var URL = window.webkitURL || window.URL;
        var url = URL.createObjectURL(e.target.files[0]);
        bgImg.src = url;

        colorsetCU.checked = true;

        bgImg.addEventListener("load", function (e) {
            bgWidth = bgImg.width;
            bgHeight = bgImg.height;

            changeBG();
        });
    });
    // random.addEventListener("click", function (e) {
    //     randomFont(font.length);
    // });
    randomNeue.addEventListener("click", function (e) {
        randomFont(2);
    });
    reset.addEventListener("click", function (e) {
        initfont();
        setTest();
    });
    showUnderline.addEventListener("change", function (e) {
        setTest();
    });
    canvas.addEventListener("scrollTop", function (e) {
        
    });
}

// var elementPosition = $('#cvs').offset();

// $(window).scroll(function(){
//         if($(window).scrollTop() > elementPosition.top){
//               $('#cvs').css('position','fixed').css('top','0');
//         } else {
//             $('#cvs').css('position','static');
//         }    
// });

function changeBG () {
    bgWidth2 = 0;
    bgHeight2 = 0;

    if (bgWidth > bgHeight) {
        bgWidth2 = canvas.width;
        bgHeight2 = (canvas.width*bgHeight)/bgWidth;
        if (bgHeight2 < canvas.height) {
            bgWidth2 = (canvas.height*bgWidth)/bgHeight;
            bgHeight2 = canvas.height;
        }
    }
    else if (bgHeight > bgWidth) {
        bgWidth2 = (canvas.height*bgWidth)/bgHeight;
        bgHeight2 = canvas.height;
        if (bgWidth2 < canvas.width) {
            bgWidth2 = canvas.width;
            bgHeight2 = (canvas.width*bgHeight)/bgWidth;
        }
    }
    else {
        if (canvas.width < canvas.height) {
            bgWidth2 = canvas.width;
            bgHeight2 = canvas.width;
        }
        else  {
            bgWidth2 = canvas.height;
            bgHeight2 = canvas.height;
        }
    }
    ctx.drawImage(bgImg, 0, 0, bgWidth2, bgHeight2);
    bgImg2.src = canvas.toDataURL();
    setTest();
}

function selectFont (master, detail, selectedFontType, selectedFontStyle, example) {
    master.options.length = font.length;
    for(var i = 0; i < font.length; i++) {
        // Option(text, value);
        master.options[i] = new Option(font[i], font[i]);
    }
    master.selectedIndex = selectedFontType;
    selectFontStyle(master, detail, selectedFontStyle, example);
}

function randomSelect(max) {
    return Math.floor(Math.random() * max);
}

function randomFont(range) {
    // Math.floor(Math.random() * (max - min)) + min;

    randomType1 = randomSelect(range);
    randomType2 = randomSelect(range);
    randomType3 = randomSelect(range);

    randomStyle1 = randomSelect(fontStyle[randomType1].length);
    randomStyle2 = randomSelect(fontStyle[randomType2].length);
    randomStyle3 = randomSelect(fontStyle[randomType3].length);

     // console.log(font.length + "*");
     // console.log("1) " + randomType1 + " | " + randomStyle1);
     // console.log("2) " + randomType2 + " | " + randomStyle2);
     // console.log("3) " + randomType3 + " | " + randomStyle3);

    selectFont(font1, fontStyle1, randomType1, randomStyle1, fontExample1);
    selectFont(font2, fontStyle2, randomType2, randomStyle2, fontExample2);
    selectFont(font3, fontStyle3, randomType3, randomStyle3, fontExample3);
}

function selectFontStyle(master, detail, selectedFontStyle, example) {
    detail.options.length = fontStyle[master.selectedIndex].length;
    for(var i = 0; i < fontStyle[master.selectedIndex].length; i++) {
        detail.options[i] = new Option(fontStyle[master.selectedIndex][i],
                                       font[master.selectedIndex] + "-" +fontStyle[master.selectedIndex][i]);
    // console.log(detail.options[i].value);
    }
    detail.selectedIndex = selectedFontStyle;
    currentFont[master.id] = detail.options[selectedFontStyle].value;
    example.style.fontFamily = detail.options[selectedFontStyle].value;
    setTest();
    // console.log(currentFont);
}

function setTest () {
	// when size ~=10, we want to have more spacing between lines (like 1px)
	// when size ~=50, no spacing, i.e. 0px.
	// use this interporlation to give some space, but we cap the spacing at min=0.
	var lineSpace = ((0 - 2) / (50 - 10)) * (size - 10) + 2;
	lineSpace = Math.max(0, lineSpace);

        ctx.fillStyle = colorset['bg'];
        // ctx.fillStyle = '#fff';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = colorset['fg'];
        // ctx.fillStyle = "#e82e21";
		text = inputText.value.toUpperCase();
    	var lines = text.split('\n');

        // the integer 800 is T height in em units
        var clearspace = Math.floor(800 / 1000 * emdashWidth);

        if (colorsetCU.checked && bgImg2 != undefined) {
            ctx.drawImage(bgImg2, 0, 0, canvas.width, canvas.height);
        }

        var kerningTable = [
            {prev: 'B', next: 'A', kerning: 0.012},
            {prev: 'F', next: 'A', kerning: 0.062},
            {prev: 'F', next: 'J', kerning: 0.119},
            {prev: 'K', next: 'C', kerning: 0.059},
            {prev: 'K', next: 'G', kerning: 0.059},
            {prev: 'K', next: 'O', kerning: 0.059},
            {prev: 'K', next: 'Q', kerning: 0.059},
            {prev: 'S', next: 'A', kerning: 0.030},
            {prev: 'A', next: 'C', kerning: 0.049},
            {prev: 'A', next: 'T', kerning: 0.089},
            {prev: 'A', next: 'U', kerning: 0.039},
            {prev: 'A', next: 'V', kerning: 0.069},
            {prev: 'A', next: '-', kerning: 0.053},
            {prev: 'D', next: 'A', kerning: 0.049},
            {prev: 'D', next: 'J', kerning: 0.029},
            {prev: 'D', next: 'T', kerning: 0.039},
            {prev: 'D', next: 'V', kerning: 0.039},
            {prev: 'D', next: 'X', kerning: 0.049},
            {prev: 'J', next: 'A', kerning: 0.039},
            {prev: 'L', next: 'C', kerning: 0.020},
            {prev: 'L', next: 'T', kerning: 0.149},
            {prev: 'L', next: 'U', kerning: 0.030},
            {prev: 'L', next: 'V', kerning: 0.089},
            {prev: 'L', next: '-', kerning: 0.093},
            {prev: 'P', next: 'A', kerning: 0.079},
            {prev: 'P', next: 'J', kerning: 0.119},
            {prev: 'P', next: 'X', kerning: 0.040},
            {prev: 'R', next: 'V', kerning: 0.049},
            {prev: 'T', next: 'A', kerning: 0.089},
            {prev: 'T', next: 'C', kerning: 0.040},
            {prev: 'T', next: 'J', kerning: 0.108},
            {prev: 'T', next: '-', kerning: 0.080},
            {prev: 'U', next: 'A', kerning: 0.040},
            {prev: 'V', next: 'A', kerning: 0.079},
            {prev: 'V', next: 'C', kerning: 0.040},
            {prev: 'V', next: 'J', kerning: 0.069},
            {prev: 'V', next: '-', kerning: 0.054},
            {prev: 'X', next: 'C', kerning: 0.050},
            {prev: '-', next: 'A', kerning: 0.040},
            {prev: '-', next: 'T', kerning: 0.080},
            {prev: '-', next: 'V', kerning: 0.040},
        ];
        var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        var setOfCircle = "ABCDOPQRS";
        var setOfSquare = "EFGH";
        var setOfOther = "IJKLMNTUVWXYZ"

        size = fontSize.value*0.92;
        linehight = 0.16 * fontSize.value;

		for (var i = 0; i < lines.length; i++) {
            var eachLineArray = Array.prototype.slice.apply(lines[i]);
            var cursorPositionX = 0;
            var eachLine = [];

            for (var j = 0; j < eachLineArray.length; j++) {
                if (alphabet.indexOf(eachLineArray[j]) != -1) {
                    if (setOfCircle.indexOf(eachLineArray[j]) != -1) {
                        eachLine[j] = {ch: eachLineArray[j], font: "narrow", type: "alphabet", set: "circle"};
                    }
                    else if (setOfSquare.indexOf(eachLineArray[j]) != -1) {
                        eachLine[j] = {ch: eachLineArray[j], font: "narrow", type: "alphabet", set: "square"};
                    }
                    else if (setOfOther.indexOf(eachLineArray[j]) != -1) {
                        eachLine[j] = {ch: eachLineArray[j], font: "narrow", type: "alphabet", set: "other"};
                    }
                }
                else {
                    eachLine[j] = {ch: eachLineArray[j], font: "narrow", type: "non-alphabet", set: ""};
                }
            }

            for (var j = 0; j < eachLine.length; j++) {

                var transformOO = function(){
                    // narrow O + wide O -> two narrow Os
                    if (j >= 1 &&
                        eachLine[j-1]["ch"] == "O" && eachLine[j-1]["font"] == "narrow" &&
                        eachLine[j]["ch"] == "O") {
                        eachLine[j]["font"] = "narrow";
                        // console.log("#"+j+"* narrow O + wide O -> narrow Os * "+eachLine[j]["font"]);
                    }
                    if (j >= 3 &&
                        eachLine[j-3]["ch"] == "O" && eachLine[j-3]["font"] == "narrow" &&
                        eachLine[j-2]["ch"] == "O" && eachLine[j-2]["font"] == "narrow" &&
                        eachLine[j-1]["font"] == "medium") {
                        eachLine[j]["font"] = "wide";
                        // console.log("#"+j+"* narrow Os + medium + \"narrow\" -> wide * "+eachLine[j]["font"]);
                    }
                }

                // if current character is a letter
                if (eachLine[j]["type"] == "alphabet") {
                    if (j == 0) {
                        // console.log("#"+j+"* no change "+eachLine[j]["font"]);
                    }
                    // letter + letter + letter + current letter
                    if (j >= 3 &&
                        eachLine[j-3]["type"] == "alphabet" &&
                        eachLine[j-2]["type"] == "alphabet" &&
                        eachLine[j-1]["type"] == "alphabet") {
                        // narrow + wide + medium + current letter
                        if (eachLine[j-3]["font"] == "narrow" &&
                            eachLine[j-2]["font"] == "wide" &&
                            eachLine[j-1]["font"] == "medium") {
                            eachLine[j]["font"] = "wide";
                            // console.log("#"+j+"* narrow + wide + medium + current letter -> wide * "+eachLine[j]["font"]);
                            continue;
                        }
                        // wide + narrow + medium + current letter
                        else if (eachLine[j-3]["font"] == "wide" &&
                                 eachLine[j-2]["font"] == "narrow" &&
                                 eachLine[j-1]["font"] == "medium") {
                            eachLine[j]["font"] = "narrow";
                            // console.log("#"+j+"* wide + narrow + medium + current letter -> narrow * "+eachLine[j]["font"]);
                            continue;
                        }
                    }

                    // non-medium + non-medium + current letter
                    if (j >= 2 &&
                        eachLine[j-2]["type"] == "alphabet" && eachLine[j-2]["font"] != "medium" &&
                        eachLine[j-1]["type"] == "alphabet" && eachLine[j-1]["font"] != "medium") {
                        eachLine[j]["font"] = "medium";
                        // console.log("#"+j+"* non-medium + non-medium + current letter * "+eachLine[j]["font"]);
                        continue;
                    }

                    // non-letter + "narrow letter" + 3 of non-letters + current letter
                    if (j >= 5 &&
                             eachLine[j-5]["type"] == "non-alphabet" &&
                             eachLine[j-4]["type"] == "alphabet" && eachLine[j-4]["font"] == "narrow" &&
                             eachLine[j-3]["type"] == "non-alphabet" &&
                             eachLine[j-2]["type"] == "non-alphabet" &&
                             eachLine[j-1]["type"] == "non-alphabet") {
                        // if current letter is "circle letter", change "narrow letter" to wide
                        if (eachLine[j]["set"] == "circle") {
                            eachLine[j-4]["font"] = "wide";
                            // console.log("#"+j+"* non-letter + \"narrow letter\" + 3 of non-letters + current circle letter -> wide * "+eachLine[j]["font"]);
                            continue;
                        }
                        // if current letter is "square letter", change "narrow letter" to medium
                        else if (eachLine[j]["set"] == "square") {
                            eachLine[j-4]["font"] = "medium";
                            // console.log("#"+j+"* non-letter + \"narrow letter\" + 3 of non-letters + current square letter -> medium * "+eachLine[j]["font"]);
                            continue;
                        }
                    }

                    // "narrow letter" + 3 of non-letters + current letter
                    if (j == 4 &&
                             eachLine[j-4]["type"] == "alphabet" && eachLine[j-4]["font"] == "narrow" &&
                             eachLine[j-3]["type"] == "non-alphabet" &&
                             eachLine[j-2]["type"] == "non-alphabet" &&
                             eachLine[j-1]["type"] == "non-alphabet") {
                        // if current letter is "circle letter", change "narrow letter" to wide
                        if (eachLine[j]["set"] == "circle") {
                            eachLine[j-4]["font"] = "wide";
                            // console.log("#"+j+"* non-letter + \"narrow letter\" + 3 of non-letters + current circle letter -> wide * "+eachLine[j]["font"]);
                            continue;
                        }
                        // if current letter is "square letter", change "narrow letter" to medium
                        else if (eachLine[j]["set"] == "square") {
                            eachLine[j-4]["font"] = "medium";
                            // console.log("#"+j+"* non-letter + \"narrow letter\" + 3 of non-letters + current square letter -> medium * "+eachLine[j]["font"]);
                            continue;
                        }
                    }

                    // non-letter + "narrow letter" + 2 of non-letters + current letter
                    if (j >= 4 &&
                             eachLine[j-4]["type"] == "non-alphabet" &&
                             eachLine[j-3]["type"] == "alphabet" && eachLine[j-3]["font"] == "narrow" &&
                             eachLine[j-2]["type"] == "non-alphabet" &&
                             eachLine[j-1]["type"] == "non-alphabet") {
                        // if current letter is "circle letter", change "narrow letter" to wide
                        if (eachLine[j]["set"] == "circle") {
                            eachLine[j-3]["font"] = "wide";
                            // console.log("#"+j+"* non-letter + \"narrow letter\" + 2 of non-letters + current circle letter -> wide * "+eachLine[j]["font"]);
                            continue;
                        }
                        // if current letter is "square letter", change "narrow letter" to medium
                        else if (eachLine[j]["set"] == "square") {
                            eachLine[j-3]["font"] = "medium";
                            // console.log("#"+j+"* non-letter + \"narrow letter\" + 2 of non-letters + current square letter -> medium * "+eachLine[j]["font"]);
                            continue;
                        }
                    }

                    // "narrow letter" + 2 of non-letters + current letter
                    if (j == 3 &&
                             eachLine[j-3]["type"] == "alphabet" && eachLine[j-3]["font"] == "narrow" &&
                             eachLine[j-2]["type"] == "non-alphabet" &&
                             eachLine[j-1]["type"] == "non-alphabet") {
                        // if current letter is "circle letter", change "narrow letter" to wide
                        if (eachLine[j]["set"] == "circle") {
                            eachLine[j-3]["font"] = "wide";
                            // console.log("#"+j+"* non-letter + \"narrow letter\" + 2 of non-letters + current circle letter -> wide * "+eachLine[j]["font"]);
                            continue;
                        }
                        // if current letter is "square letter", change "narrow letter" to medium
                        else if (eachLine[j]["set"] == "square") {
                            eachLine[j-3]["font"] = "medium";
                            console.log("#"+j+"* non-letter + \"narrow letter\" + 2 of non-letters + current square letter -> medium * "+eachLine[j]["font"]);
                            continue;
                        }
                    }

                    // non-letter + "narrow letter" + 1 of non-letters + current letter
                    if (j >= 3 &&
                             eachLine[j-3]["type"] == "non-alphabet" &&
                             eachLine[j-2]["type"] == "alphabet" && eachLine[j-2]["font"] == "narrow" &&
                             eachLine[j-1]["type"] == "non-alphabet") {
                        // if current letter is "circle letter", change "narrow letter" to wide
                        if (eachLine[j]["set"] == "circle") {
                            eachLine[j-2]["font"] = "wide";
                            // console.log("#"+j+"* non-letter + \"narrow letter\" + 1 of non-letters + current circle letter -> wide * "+eachLine[j]["font"]);
                            continue;
                        }
                        // if current letter is "square letter", change "narrow letter" to medium
                        else if (eachLine[j]["set"] == "square") {
                            eachLine[j-2]["font"] = "medium";
                            // console.log("#"+j+"* non-letter + \"narrow letter\" + 1 of non-letters + current square letter -> medium * "+eachLine[j]["font"]);
                            continue;
                        }
                    }

                    // non-letter + "narrow letter" + 1 of non-letters + current letter
                    if (j == 2 &&
                             eachLine[j-2]["type"] == "alphabet" && eachLine[j-2]["font"] == "narrow" &&
                             eachLine[j-1]["type"] == "non-alphabet") {
                        // if current letter is "circle letter", change "narrow letter" to wide
                        if (eachLine[j]["set"] == "circle") {
                            eachLine[j-2]["font"] = "wide";
                            // console.log("#"+j+"* non-letter + \"narrow letter\" + 1 of non-letters + current circle letter -> wide * "+eachLine[j]["font"]);
                            continue;
                        }
                        // if current letter is "square letter", change "narrow letter" to medium
                        else if (eachLine[j]["set"] == "square") {
                            eachLine[j-2]["font"] = "medium";
                            // console.log("#"+j+"* non-letter + \"narrow letter\" + 1 of non-letters + current square letter -> medium * "+eachLine[j]["font"]);
                            continue;
                        }
                    }

                    // (non-letter +) "narrow letter" + current letter
                    if (j >= 2 &&
                             eachLine[j-1]["type"] == "alphabet" && eachLine[j-1]["font"] == "narrow") {
                        // if (non-letter +)
                        if(eachLine[j-2]["type"] == "non-alphabet") {
                            // if current letter is "circle letter", change "narrow letter" to wide
                            if (eachLine[j]["set"] == "circle") {
                                eachLine[j-1]["font"] = "wide";
                                // console.log("#"+j+"* non-letter + narrow + circle narrow -> wide narrow * "+eachLine[j]["font"]);
                                transformOO();
                                continue;
                            }
                            // if current letter is "square letter", change "narrow letter" to medium
                            else if (eachLine[j]["set"] == "square") {
                                eachLine[j-1]["font"] = "medium";
                                console.log("#"+j+"* non-letter + narrow + square narrow -> medium narrow * "+eachLine[j]["font"]);
                                continue;
                            }
                        }
                        // if current letter is "other letter", change "current letter" to wide
                        else {             
                            eachLine[j]["font"] = "wide";
                            // console.log("#"+j+"* two narrows -> narrow wide * "+eachLine[j]["font"]);
                            transformOO();
                            continue;
                        }
                    }

                    // "narrow letter" + current letter
                    if (j >= 1 &&
                             eachLine[j-1]["type"] == "alphabet" && eachLine[j-1]["font"] == "narrow") {
                        // set current letter to wide for default
                        eachLine[j]["font"] = "wide";
                        // if current letter is "circle letter", change "narrow letter" to wide
                        if (eachLine[j]["set"] == "circle") {
                            eachLine[j-1]["font"] = "wide";
                            eachLine[j]["font"] = "narrow";
                            // console.log("#"+j+"* first two narrows -> wide narrow * "+eachLine[j]["font"]);
                            transformOO();
                            continue;
                        }
                        // if current letter is "square letter", change "narrow letter" to medium
                        else if (eachLine[j]["set"] == "square") {
                            eachLine[j-1]["font"] = "medium";
                            eachLine[j]["font"] = "narrow";
                            // console.log("#"+j+"* first two narrows -> medium narrow * "+eachLine[j]["font"]);
                            continue;
                        }
                        // if current letter is "other letter", change "current letter" to wide
                        else {
                            eachLine[j]["font"] = "wide";
                            // console.log("#"+j+"* first two narrows -> narrow wide * "+eachLine[j]["font"]);
                            transformOO();
                            continue;
                        }
                    }

                    transformOO();
                }
            }

             // console.log("lilililili!!!!!");
            for (var j = 0; j < eachLine.length; j++) {
                var descenderAdjust = 0;

                if (eachLine[j]["font"] == "narrow") { 
                    ctx.font = fontSize.value + 'px ' + currentFont['font1'];                   
                    if (currentFont['font1'] == "NeueDisplay-Wide") {
                        // console.log(ctx.measureText("â€”").width);
                        descenderAdjust = 0.05*emdashWidth;
                    }
                    else if (currentFont['font1'] == "Matrix-Regular") {
                        ctx.font = fontSize.value*1.35 + 'px ' + currentFont['font1'];
                        descenderAdjust = -0.28*emdashWidth;
                    }
                    else if (currentFont['font1'] == "Matrix-Bold") {
                        ctx.font = fontSize.value*1.35 + 'px ' + currentFont['font1'];
                        descenderAdjust = -0.22*emdashWidth;
                    }
                    else if (currentFont['font1'].indexOf("ITCFranklinGothicStd") !== -1) {
                        ctx.font = fontSize.value*1.19 + 'px ' + currentFont['font1'];
                        descenderAdjust = -0.02*emdashWidth;
                    }
                    else if (currentFont['font1'] == "Irma-Extralight" ||
                             currentFont['font1'] == "Irma-Light") {
                        ctx.font = fontSize.value*1 + 'px ' + currentFont['font1'];
                        descenderAdjust = -0.25*emdashWidth;
                    }
                    else if (currentFont['font1'] == "Irma-Medium") {
                        ctx.font = fontSize.value*1 + 'px ' + currentFont['font1'];
                        descenderAdjust = -0.26*emdashWidth;
                    }
                    else if (currentFont['font1'] == "Irma-Bold") {
                        ctx.font = fontSize.value*1 + 'px ' + currentFont['font1'];
                        descenderAdjust = -0.28*emdashWidth;
                    }
                }
                else if (eachLine[j]["font"] == "medium") {
                    ctx.font = fontSize.value + 'px ' + currentFont['font2'];
                    // ctx.font = fontSize.value + 'px ' + "NeueDisplay-Wide";
                    if (currentFont['font2'] == "NeueDisplay-Wide") {
                        // console.log(ctx.measureText("â€”").width);                           
                        descenderAdjust = 0.05*emdashWidth;
                    }
                    else if (currentFont['font2'] == "Matrix-Regular") {
                        ctx.font = fontSize.value*1.35 + 'px ' + currentFont['font2'];
                        descenderAdjust = -0.28*emdashWidth;
                    }
                    else if (currentFont['font2'] == "Matrix-Bold") {
                        ctx.font = fontSize.value*1.35 + 'px ' + currentFont['font2'];
                        descenderAdjust = -0.22*emdashWidth;
                    }
                    else if (currentFont['font2'].indexOf("ITCFranklinGothicStd") !== -1) {
                        ctx.font = fontSize.value*1.19 + 'px ' + currentFont['font2'];
                        descenderAdjust = -0.02*emdashWidth;
                    }
                    else if (currentFont['font2'] == "Irma-Extralight" ||
                             currentFont['font2'] == "Irma-Light") {
                        ctx.font = fontSize.value*1 + 'px ' + currentFont['font2'];
                        descenderAdjust = -0.25*emdashWidth;
                    }
                    else if (currentFont['font2'] == "Irma-Medium") {
                        ctx.font = fontSize.value*1 + 'px ' + currentFont['font2'];
                        descenderAdjust = -0.26*emdashWidth;
                    }
                    else if (currentFont['font2'] == "Irma-Bold") {
                        ctx.font = fontSize.value*1 + 'px ' + currentFont['font2'];
                        descenderAdjust = -0.28*emdashWidth;
                    }
                }
                else if (eachLine[j]["font"] == "wide") {
                    ctx.font = fontSize.value + 'px ' + currentFont['font3'];
                    // ctx.font = fontSize.value + 'px ' + "NeueDisplay-Ultra";
                    if (currentFont['font3'] == "NeueDisplay-Wide") {
                        // console.log(ctx.measureText("â€”").width);                           
                        descenderAdjust = 0.05*emdashWidth;
                    }
                    else if (currentFont['font3'] == "Matrix-Regular") {
                        ctx.font = fontSize.value*1.35 + 'px ' + currentFont['font3'];
                        descenderAdjust = -0.28*emdashWidth;
                    }
                    else if (currentFont['font3'] == "Matrix-Bold") {
                        ctx.font = fontSize.value*1.35 + 'px ' + currentFont['font3'];
                        descenderAdjust = -0.22*emdashWidth;
                    }
                    else if (currentFont['font3'].indexOf("ITCFranklinGothicStd") !== -1) {
                        ctx.font = fontSize.value*1.19 + 'px ' + currentFont['font3'];
                        descenderAdjust = -0.02*emdashWidth;
                    }
                    else if (currentFont['font3'] == "Irma-Extralight" ||
                             currentFont['font3'] == "Irma-Light") {
                        ctx.font = fontSize.value*1 + 'px ' + currentFont['font3'];
                        descenderAdjust = -0.25*emdashWidth;
                    }
                    else if (currentFont['font3'] == "Irma-Medium") {
                        ctx.font = fontSize.value*1 + 'px ' + currentFont['font3'];
                        descenderAdjust = -0.26*emdashWidth;
                    }
                    else if (currentFont['font3'] == "Irma-Bold") {
                        ctx.font = fontSize.value*1 + 'px ' + currentFont['font3'];
                        descenderAdjust = -0.28*emdashWidth;
                    }
                }

                var charWidth = ctx.measureText(eachLine[j]["ch"]);
                // console.log(j + " * " + clearspace);

                // console.log("YYYYY", 5+i*(size+lineSpace)+descenderAdjust+clearspace);

			    ctx.fillText(eachLine[j]["ch"], cursorPositionX+clearspace, 5+i*(size+lineSpace)+descenderAdjust+clearspace);
                cursorPositionX += charWidth.width;
                for(var k = 0; k < kerningTable.length; k++) {
                    if(eachLine[j]["ch"] == kerningTable[k]['prev'] && eachLine[j+1] && eachLine[j+1]["ch"] == kerningTable[k]['next']) {
                        console.log(ctx.measureText("â€”").width);                           
                        cursorPositionX -= kerningTable[k]['kerning']*emdashWidth;
                        // console.log(eachLine[j]["ch"] + " | " + kerningTable[k]['kerning']*emdashWidth);
                        break;
                    }
                }
            }
		}

	// when size ~=10, we want to have more spacing between text & lines (like 6px)
	// when size ~=50, no spacing, i.e. 0px.
	// use this interporlation to give some space, but we cap the spacing at min=0.
	var textLineSpace = ((0 - 4) / (50 - 10)) * (size - 10) + 4;
	textLineSpace = Math.max(0, textLineSpace);

    if (showUnderline.checked) {
	   ctx.fillRect(clearspace, (lines.length*(size+lineSpace))+textLineSpace+linehight+clearspace, canvas.width, linehight);
	   ctx.fillRect(clearspace, (lines.length*(size+lineSpace))+textLineSpace+linehight*3+clearspace, canvas.width, linehight);
    }
    ctx.fillStyle = colorset['bg'];
    ctx.fillRect(canvas.width-clearspace, 0, canvas.width, canvas.height);
    ctx.fillRect(0, canvas.height-clearspace, canvas.width, canvas.height);

    if (colorsetCU.checked && bgImg2 != undefined) {
        ctx.drawImage(bgImg2, canvas.width-clearspace, 0, clearspace, canvas.height, canvas.width-clearspace, 0, clearspace, canvas.height);
        ctx.drawImage(bgImg2, 0, canvas.height-clearspace, canvas.width, clearspace, 0, canvas.height-clearspace, canvas.width, clearspace);
    }
}

//this function is from @Ken Fyrstenberg from Stackoverflow
function download(c, filename) {

    // create an "off-screen" anchor tag
    var lnk = document.createElement('a'),
        e;

    // the key here is to set the download attribute of the a tag
    lnk.download = filename;

    // convert canvas content to data-uri for link. When download
    // attribute is set the content pointed to by link will be
    // pushed as "download" in HTML5 capable browsers
    lnk.href = c.toDataURL();

    // create a "fake" click-event to trigger the download
    if (document.createEvent) {

        e = document.createEvent("MouseEvents");
        e.initMouseEvent("click", true, true, window,
                         0, 0, 0, 0, 0, false, false, false,
                         false, 0, null);

        lnk.dispatchEvent(e);

    } else if (lnk.fireEvent) {

        lnk.fireEvent("onclick");
    }
}

function resizeSecondFix(){
    var secondFixed = document.getElementById('second-fixed');
    var bodyMarginTop = parseInt(window.getComputedStyle(document.body).marginTop);
    var fixedHeight = document.getElementsByClassName('fixed')[0].clientHeight;
    var secondFixMarginTop = parseInt(window.getComputedStyle(secondFixed).marginTop);

    secondFixed.style.height = (window.innerHeight - bodyMarginTop - fixedHeight - secondFixMarginTop) + 'px';
}

onload = init;

onresize = resizeSecondFix;