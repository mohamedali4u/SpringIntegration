// "nl" means "non-letter"
/*var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
var setOfCircle = "ABCDOPQRS";
var setOfSquare = "EFGH";
var setOfNL = "0123456789;:/,.'*-_"

function randomChar(str) {
    return str[Math.floor(str.length * Math.random())];
}

// use "-1" to denote uninitialized values because "undefined" == 0...
var ruleStatuses = {
    'rule1-zero-three-nl': {
        currentTotalCount: -1,
        currentCount: -1
    },
    'rule1-four-nl': {
        currentTotalCount: -1,
        currentCount: -1
    },
    'rule2-zero-three-nl': {
        currentTotalCount: -1,
        currentCount: -1
    },
    'rule2-four-nl': {
        currentTotalCount: -1,
        currentCount: -1
    }
};

function clearClick(e){
    var subRuleKey = e.target.id.substr(0, e.target.id.indexOf('-clear'));
    document.getElementById(subRuleKey + '-display').textContent = "";    
    ruleStatuses[subRuleKey].currentTotalCount = -1;
    ruleStatuses[subRuleKey].currentCount = -1;
}

document.getElementById('rule1-zero-three-nl-clear').addEventListener('click', clearClick);
document.getElementById('rule1-four-nl-clear').addEventListener('click', clearClick);
document.getElementById('rule2-zero-three-nl-clear').addEventListener('click', clearClick);
document.getElementById('rule2-four-nl-clear').addEventListener('click', clearClick);

function rule1And2Handler(subRuleKey, totalCount, setOfString) {
    // we were not generating zero non-letter. clear everything and restart.
    if(ruleStatuses[subRuleKey].currentTotalCount !== totalCount) {
        document.getElementById(subRuleKey + '-clear').click();
        ruleStatuses[subRuleKey].currentTotalCount = totalCount;
        ruleStatuses[subRuleKey].currentCount = 0;
    }

    if (ruleStatuses[subRuleKey].currentCount == 0) {
        document.getElementById(subRuleKey + '-display').textContent += randomChar(setOfString);
        ruleStatuses[subRuleKey].currentCount++;
    } else if (ruleStatuses[subRuleKey].currentCount == totalCount - 1) {
        document.getElementById(subRuleKey + '-display').textContent += randomChar(setOfString);
        // we're done: reset.
        ruleStatuses[subRuleKey].currentTotalCount = -1;
        ruleStatuses[subRuleKey].currentCount = -1;
    } else {
        document.getElementById(subRuleKey + '-display').textContent += randomChar(setOfNL);
        ruleStatuses[subRuleKey].currentCount++;
    }
}

function rule1Handler(subRuleKey, totalCount){
    rule1And2Handler(subRuleKey, totalCount, setOfCircle);
};

function rule2Handler(subRuleKey, totalCount){
    rule1And2Handler(subRuleKey, totalCount, setOfSquare);
};

/*document.getElementById('rule1-zero-three-nl-gen-zero').addEventListener('click', function(e){
    var subRuleKey = e.target.id.substr(0, e.target.id.indexOf('-gen'));

    rule1Handler(subRuleKey, 2);
});

document.getElementById('rule1-zero-three-nl-gen-one').addEventListener('click', function(e){
    var subRuleKey = e.target.id.substr(0, e.target.id.indexOf('-gen'));

    rule1Handler(subRuleKey, 3);
});

document.getElementById('rule1-zero-three-nl-gen-two').addEventListener('click', function(e){
    var subRuleKey = e.target.id.substr(0, e.target.id.indexOf('-gen'));

    rule1Handler(subRuleKey, 4);
});

document.getElementById('rule1-zero-three-nl-gen-three').addEventListener('click', function(e){
    var subRuleKey = e.target.id.substr(0, e.target.id.indexOf('-gen'));

    rule1Handler(subRuleKey, 5);
});

document.getElementById('rule1-four-nl-gen').addEventListener('click', function(e){
    var subRuleKey = e.target.id.substr(0, e.target.id.indexOf('-gen'));

    rule1Handler(subRuleKey, 6);
});

document.getElementById('rule2-zero-three-nl-gen-zero').addEventListener('click', function(e){
    var subRuleKey = e.target.id.substr(0, e.target.id.indexOf('-gen'));

    rule2Handler(subRuleKey, 2);
});

document.getElementById('rule2-zero-three-nl-gen-one').addEventListener('click', function(e){
    var subRuleKey = e.target.id.substr(0, e.target.id.indexOf('-gen'));

    rule2Handler(subRuleKey, 3);
});

document.getElementById('rule2-zero-three-nl-gen-two').addEventListener('click', function(e){
    var subRuleKey = e.target.id.substr(0, e.target.id.indexOf('-gen'));

    rule2Handler(subRuleKey, 4);
});

document.getElementById('rule2-zero-three-nl-gen-three').addEventListener('click', function(e){
    var subRuleKey = e.target.id.substr(0, e.target.id.indexOf('-gen'));

    rule2Handler(subRuleKey, 5);
});

document.getElementById('rule2-four-nl-gen').addEventListener('click', function(e){
    var subRuleKey = e.target.id.substr(0, e.target.id.indexOf('-gen'));

    rule2Handler(subRuleKey, 6);
});
*/

var DEMO_IMG_WIDTH = 800;
var DEMO_IMG_HEIGHT = 296;

var SPEED_MILLISECONDS = [1000, 500, 250];
var SPEED_TEXT = ['SLOW', 'MEDIUM', 'FAST']

function attachPlayerLogics(imgContainer, ctrlContainer, numframes){
    var currentFrameIdx = 0;
    var currentIntervalId;

    var playpauseButton = ctrlContainer.getElementsByClassName('demo-player-playpause')[0];
    var nextButton = ctrlContainer.getElementsByClassName('demo-player-next')[0];
    var prevButton = ctrlContainer.getElementsByClassName('demo-player-prev')[0];
    var rangeSlider = ctrlContainer.getElementsByClassName('demo-player-speed')[0];

    var isPlaying = function(){
        return playpauseButton.dataset.status != 'paused';
    };

    var reRender = function(){
        imgContainer.style.backgroundPosition = '0 ' + ((-1) * currentFrameIdx * DEMO_IMG_HEIGHT) + 'px';
    };

    var goNextFrame = function(){
        currentFrameIdx++;

        if(currentFrameIdx >= numframes) {
            currentFrameIdx = 0;
        }
        reRender();
    };

    var goPrevFrame = function(){
        currentFrameIdx--;

        if(currentFrameIdx < 0) {
            currentFrameIdx = numframes - 1;
        }
        reRender();
    };

    var showSpeed = function(){
        var speedIdx = rangeSlider.value;

        ctrlContainer.getElementsByClassName('demo-player-speed-text')[0].innerHTML = SPEED_TEXT[speedIdx];
    };

    var changeSpeed = function(){
        var speedIdx = rangeSlider.value;

        clearInterval(currentIntervalId);
        currentIntervalId = setInterval(function(){
            goNextFrame();
        }, SPEED_MILLISECONDS[speedIdx]);
    };

    var pause = function(){
        playpauseButton.innerHTML = 'â–¶';
        clearInterval(currentIntervalId);    
        playpauseButton.dataset.status = 'paused';
    }

    playpauseButton.addEventListener('click', function(e){
        if(isPlaying()){
            pause();
        }else{
            playpauseButton.innerHTML = '||';
            changeSpeed();
            playpauseButton.dataset.status = 'playing';
        }
    });

    nextButton.addEventListener('click', function(e){
        pause();
        goNextFrame();
    });

    prevButton.addEventListener('click', function(e){
        pause();
        goPrevFrame();
    });

    rangeSlider.addEventListener('change', function(e){
        showSpeed();
        if(isPlaying()){
            changeSpeed();
        }
    });

    showSpeed();
}

var demoPlayerContainers = document.getElementsByClassName('demo-player-container');

for (var i = 0; i < demoPlayerContainers.length;i ++) {
    var container = demoPlayerContainers[i];
    var rule = parseInt(container.dataset.rule);
    var subrule = parseInt(container.dataset.subrule);
    var numframes = parseInt(container.dataset.numframes);

    var imgContainer = container.getElementsByClassName('demo-player-image')[0];

    var imgFilename = 'url(img/rule' + rule + '_' + subrule + '.gif)';

    imgContainer.style.backgroundImage = imgFilename;
    imgContainer.style.backgroundSize = DEMO_IMG_WIDTH + 'px ' + (DEMO_IMG_HEIGHT * numframes) + 'px';

    var controls = document.getElementById('demo-player-controls-template').cloneNode(true);

    controls.removeAttribute('id');

    controls.getElementsByClassName('demo-player-playpause')[0].dataset.status = 'paused';

    container.appendChild(controls);

    attachPlayerLogics(imgContainer, controls, numframes);
}



var demoPlayerSelects = document.getElementsByClassName('demo-player-select');

for (var i = 0; i < demoPlayerSelects.length;i ++) {
    var select = demoPlayerSelects[i];
    var rule = parseInt(select.dataset.rule);

    select.addEventListener('change', function(e){
        var subrule = e.target.options[e.target.selectedIndex].value;
        // get rule again because this is not in a closure
        var rule = e.target.dataset.rule;
        var multiContainer = document.querySelector('.demo-player-multi-container[data-rule="' + rule + '"]');

        var containers = multiContainer.getElementsByClassName('demo-player-container');
        for(var j = 0; j < containers.length; j++){
            containers[j].style.display = 'none';
        }

        var targetContainer = multiContainer.querySelector('.demo-player-container[data-subrule="' + subrule + '"]');

        targetContainer.style.display = 'block';

        var playpauseButton = targetContainer.getElementsByClassName('demo-player-playpause')[0];
        if(playpauseButton.dataset.status == 'paused') {
            playpauseButton.click();
        }
    });

    select.dispatchEvent(new Event('change'));
}

var singleDemoPlayerContainers = document.querySelectorAll('.demo-player-container[data-subrule="0"]');
for (var i = 0; i < singleDemoPlayerContainers.length; i++) {
    var container = singleDemoPlayerContainers[i];

    container.getElementsByClassName('demo-player-playpause')[0].click();
}