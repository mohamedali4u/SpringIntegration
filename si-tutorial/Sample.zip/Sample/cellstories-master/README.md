cellstories
===========

holy crap, this is some old code.

Cellstories ran from fall 2008 to mid-2010, publishing short fiction 5 days a week specifically for mobile devices. It was awesome, even if the whole thing was written as one gigantic hack.

I got caught in an airport for eight hours in 2013 and decided to actually get the code running again locally, push it up to github, and eventually get it onto Heroku. Why? because airports are fucking boring places and this has been on my to-do list for approximately a thousand years.

