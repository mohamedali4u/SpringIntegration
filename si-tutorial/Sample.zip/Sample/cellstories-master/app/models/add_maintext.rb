class AddMaintext < ActiveRecord::Base
end
