class Library < ActiveRecord::Base
  has_many :stories
end
