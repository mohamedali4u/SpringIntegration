require File.dirname(__FILE__) + '/../test_helper'

class AuthorTest < Test::Unit::TestCase
  fixtures :authors

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
