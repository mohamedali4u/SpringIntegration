class AddAuthorLink < ActiveRecord::Migration
  def self.up
    
  end

  def self.down
    remove_column :stories, :author_id, :string
  end
end
