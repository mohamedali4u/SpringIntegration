class AddEmail < ActiveRecord::Migration
  def self.up
    add_column :authors, :email, :string
  end

  def self.down
    remove_column :authors, :email, :string
  end
end
