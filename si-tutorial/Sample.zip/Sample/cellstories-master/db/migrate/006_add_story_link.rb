class AddStoryLink < ActiveRecord::Migration
  def self.up
    add_column :authors, :story_id, :string
  end

  def self.down
    remove_column :authors, :story_id, :string
  end
end
