package com.cts.abcbpm.ui;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Enumeration;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import com.cts.abcbpm.bean.UserBean;
import com.cts.abcbpm.utils.AuthUserUtils;
import com.cts.abcbpm.utils.RestUtils;
import com.cts.abcbpm.utils.XMLtUtils;

public class ABCAccountTask extends JFrame {
	private static final long serialVersionUID = 1L;
	private JTextField nameText;
	private JTextField currencyTxt;
	private JTextField phoneTxt;
	private JTextField addressTxt;

	private String taskId;

	public ABCAccountTask(String taskId, String taskDisplayName) {
		super("ABC Client - Task Detail");
		this.taskId = taskId;
		this.setSize(555, 260);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JPanel panel = new JPanel();
		this.getContentPane().add(panel);
		placeComponents(panel);
		JLabel lblAbcBpm = new JLabel("ABC - BPM Client");
		lblAbcBpm.setHorizontalAlignment(SwingConstants.CENTER);
		lblAbcBpm.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblAbcBpm.setBounds(156, 11, 221, 25);
		panel.add(lblAbcBpm);
		
		JLabel lblTaskName = new JLabel(taskDisplayName);
		lblTaskName.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblTaskName.setBounds(25, 53, 352, 14);
		panel.add(lblTaskName);
		this.setVisible(true);
	}

	private void placeComponents(JPanel panel) {
		panel.setLayout(null);
		JLabel lblUsername = new JLabel(AuthUserUtils.getUser().getUserName());
		lblUsername.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblUsername.setHorizontalAlignment(SwingConstants.RIGHT);
		lblUsername.setBounds(465, 11, 64, 14);
		panel.add(lblUsername);
		JLabel lblCurrency = new JLabel("Currency");
		lblCurrency.setBounds(25, 114, 70, 25);
		panel.add(lblCurrency);
		nameText = new JTextField(20);
		nameText.setBounds(105, 78, 160, 25);
		panel.add(nameText);
		
		JLabel lblName = new JLabel("Name");
		lblName.setBounds(25, 78, 70, 25);
		panel.add(lblName);
		currencyTxt = new JTextField(20);
		currencyTxt.setBounds(105, 114, 160, 25);
		panel.add(currencyTxt);
		JLabel lblPhone = new JLabel("Phone");
		lblPhone.setBounds(291, 78, 55, 25);
		panel.add(lblPhone);
		phoneTxt = new JTextField(20);
		phoneTxt.setBounds(369, 78, 160, 25);
		panel.add(phoneTxt);
		JLabel lblAddress = new JLabel("Address");
		lblAddress.setBounds(289, 114, 70, 25);
		panel.add(lblAddress);
		addressTxt = new JTextField(20);
		addressTxt.setBounds(369, 114, 160, 25);
		panel.add(addressTxt);
		
		JButton btnSubmit = new JButton("Submit");
		btnSubmit.setBounds(125, 165, 80, 25);
		panel.add(btnSubmit);
		
		JButton btnFetchDemoData = new JButton("Fetch Demo Data");
		btnFetchDemoData.setBounds(225, 166, 150, 25);
		panel.add(btnFetchDemoData);
		
		btnSubmit.addActionListener(new AccountTaskListener(this));
		btnFetchDemoData.addActionListener(new AccountTaskListener(this));
		
		
		JButton btnClose = new JButton("Close");
		btnClose.setBounds(400, 166, 80, 25);
		panel.add(btnClose);
		
		btnClose.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				closeAction();
				
			}
		});
		
		
	}
	
	public void closeAction(){
		this.setVisible(false);
	}

	public void submitAction() {
		System.out.println("Submit Action");

		String name = nameText.getText();
		String ccy = currencyTxt.getText();
		String phone = phoneTxt.getText();
		String address = addressTxt.getText();
		
		String data = "{'phone':'"+phone+"','address':'"+address+"','name':'"+name+"','currency':'"+ccy+"'}";
		System.out.println("Fetch Demo Action");
		
		String params = "action=setData&params="+data;

		UserBean user = AuthUserUtils.getUser();

		if (user != null && user.getUserName() != null
				&& user.getPassword() != null) {
			String urlAccountSet = "https://ibmbpm:9443/rest/bpm/wle/v1/task/"+this.taskId;
			StringBuffer response;
			try {
				
				//TASK.TKIID
				response = RestUtils.INSTANCE.submitAccountDataTask(urlAccountSet, user.getUserName(), user.getPassword(), params);
				Vector<String> taskVec = XMLtUtils.INSTANCE.getAccountDetail(response);
				System.out.println("Task Vector: " + taskVec.size() + " -- "
						+ taskVec);
				if (taskVec != null && taskVec.size() > 0) {
					Enumeration<String> eTask = taskVec.elements();
					 phone = (String) eTask.nextElement();
					 address = (String) eTask.nextElement();
					 name = (String) eTask.nextElement();
					 ccy = (String) eTask.nextElement();
					
					nameText.setText(name);
					currencyTxt.setText(ccy);
					phoneTxt.setText(phone);
					addressTxt.setText(address);
					
					//
					String urlFinishTask = "https://ibmbpm:9443/rest/bpm/wle/v1/task/"+this.taskId+"?action=finish&parts=all";
					RestUtils.INSTANCE.submitAccountDataTask(urlFinishTask, user.getUserName(), user.getPassword(), params);
					JOptionPane.showMessageDialog(this, "Data Post -Success!!!");
					
				}else{
					JOptionPane.showMessageDialog(this, "Request Service Failed or No Data!!!");
				}
				System.out.println(taskVec);
			} catch (Exception e) {
				e.printStackTrace();
				JOptionPane.showMessageDialog(this, "Request Service Failed!!!");
			}

		}
	

	}

	public void fetchDemoAction() {
		System.out.println("Fetch Demo Action");

		UserBean user = AuthUserUtils.getUser();

		if (user != null && user.getUserName() != null
				&& user.getPassword() != null) {
			String param = "phone,address,name,currency";
			// phone%2Caddress%2Cname%2Ccurrency
			String urlAccountGet = "https://ibmbpm:9443/rest/bpm/wle/v1/task/"+this.taskId+"?action=getData&fields="
					+ param;
			StringBuffer response;
			try {
				response = RestUtils.INSTANCE.getAccountDataTask(urlAccountGet, user.getUserName(), user.getPassword());
				Vector<String> taskVec = XMLtUtils.INSTANCE.getAccountDetail(response);
				System.out.println("Task Vector: " + taskVec.size() + " -- "
						+ taskVec);
				if (taskVec != null && taskVec.size() > 0) {
					Enumeration<String> eTask = taskVec.elements();
					String phone = (String) eTask.nextElement().trim();
					String address = (String) eTask.nextElement().trim();
					String name = (String) eTask.nextElement().trim();
					String ccy = (String) eTask.nextElement().trim();
					
					 
					if(phone.length() == 0 && address.length() == 0 && name.length() == 0 && ccy.length() == 0) {
						JOptionPane.showMessageDialog(this, "No Data for task "+this.taskId);
						return;
					}
					
					nameText.setText(name);
					currencyTxt.setText(ccy);
					phoneTxt.setText(phone);
					addressTxt.setText(address);
				}else{
					JOptionPane.showMessageDialog(this, "Request Service Failed or No Data!!!");
				}
				System.out.println(taskVec);
			} catch (Exception e) {
				e.printStackTrace();
				JOptionPane.showMessageDialog(this, "Request Service Failed!!!");
			}

		}
	}

}

class AccountTaskListener implements ActionListener {

	ABCAccountTask abcAccountTask;

	public AccountTaskListener(ABCAccountTask abcAccountTask) {
		this.abcAccountTask = abcAccountTask;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String eventStr = e.getActionCommand();
		int ei = 0;
		if ("Submit".equalsIgnoreCase(eventStr)) {
			ei = 1;
		}else if ("Fetch Demo Data".equalsIgnoreCase(eventStr)) {
			ei = 2;
		}
		switch (ei) {
		case 1:
			this.abcAccountTask.submitAction();
			break;
		case 2:
			this.abcAccountTask.fetchDemoAction();
			break;
		default:
			break;
		}

	}
}
