package com.cts.abcbpm.ui;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import com.cts.abcbpm.utils.RestUtils;
import com.cts.abcbpm.utils.XMLtUtils;

public class ABCLogin extends JFrame {

	private static final long serialVersionUID = 1L;
	private JTextField userText;
	private JPasswordField passwordText;
	public ABCLogin() {
		super("ABC Client - Login");
		this.setSize(422, 272);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JPanel panel = new JPanel();
		this.getContentPane().add(panel);
		placeComponents(panel);

		JLabel lblAbcBpm = new JLabel("ABC - BPM Client");
		lblAbcBpm.setHorizontalAlignment(SwingConstants.CENTER);
		lblAbcBpm.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblAbcBpm.setBounds(90, 29, 221, 25);
		panel.add(lblAbcBpm);

		this.addWindowListener(new ABCWindowAdaptor(this));

		this.setVisible(true);
	}

	private void placeComponents(JPanel panel) {

		panel.setLayout(null);

		JLabel userLabel = new JLabel("Username");
		userLabel.setBounds(90, 81, 72, 25);
		panel.add(userLabel);

		userText = new JTextField(20);
		userText.setBounds(167, 81, 160, 25);
		panel.add(userText);

		JLabel passwordLabel = new JLabel("Password");
		passwordLabel.setBounds(90, 117, 80, 25);
		panel.add(passwordLabel);

		passwordText = new JPasswordField(20);
		passwordText.setBounds(167, 117, 160, 25);
		panel.add(passwordText);

		JButton loginButton = new JButton("Login");
		loginButton.setBounds(111, 153, 80, 25);
		panel.add(loginButton);

		JButton resetButton = new JButton("Reset");
		resetButton.setBounds(201, 153, 80, 25);
		panel.add(resetButton);

		loginButton.addActionListener(new LoginListener(this));

		resetButton.addActionListener(new LoginListener(this));
	}

	public boolean loginAction() {
		String username = userText.getText();
		String password = passwordText.getText();
		
		if (username != null & username.length() > 0) {
			if (password != null & password.length() > 0) {
				String urlUser = "https://ibmbpm:9443/rest/bpm/wle/v1/user?userName="+username+"&includeInternalMemberships=true&refreshUser=false&parts=all";
				StringBuffer response;
				try {
					response = RestUtils.INSTANCE.userRequest(urlUser, username, password);
				} catch (Exception e) {
					e.printStackTrace();
					return false;
				}
				boolean flag = XMLtUtils.INSTANCE.userDataCheck(response, password);
				
				if (!flag) {
					JOptionPane.showMessageDialog(this, "Invalid Username or Password");
					userText.setText("");
					passwordText.setText("");
				}
				return flag;
			}else{
				JOptionPane.showMessageDialog(this, "Password cannot be empty!!!");
			}
		}else{
			JOptionPane.showMessageDialog(this, "Username cannot be empty!!!");
		}
		 
		
		return true;
	}

	public boolean resetAction() {
		this.userText.setText(null);
		this.passwordText.setText(null);
		return true;
	}
}

class LoginListener implements ActionListener {
	ABCLogin abcLogin;

	public LoginListener(ABCLogin abcLogin) {
		this.abcLogin = abcLogin;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		System.out.println(e.getActionCommand());
		String eventStr = e.getActionCommand();
		int ei = 0;
		if ("Login".equalsIgnoreCase(eventStr)) {
			ei = 1;
		}else if ("Reset".equalsIgnoreCase(eventStr)) {
			ei = 2;
		}
		switch (ei) {
		case 1:
			if (this.abcLogin.loginAction()) {
				this.abcLogin.setVisible(false);
				EventQueue.invokeLater(new Runnable() {
					public void run() {
						try {
							new ABCTaskList();
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
			}
			
			break;
		case 2:
			this.abcLogin.resetAction();
			break;
		default:
			break;
		}
		
		
	}
}
