package com.cts.abcbpm.ui;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

class ABCWindowAdaptor extends WindowAdapter{
	JFrame jFrame;
	public ABCWindowAdaptor(JFrame jFrame) {
		this.jFrame = jFrame;
	}
	@Override
	public void windowClosing(WindowEvent e) {
		if (JOptionPane.showConfirmDialog(this.jFrame, 
	            "Are you sure to close this window?", "Really Closing?", 
	            JOptionPane.YES_NO_OPTION,
	            JOptionPane.QUESTION_MESSAGE) == JOptionPane.YES_OPTION){
	            System.exit(0);
	        }
	}
	
}
