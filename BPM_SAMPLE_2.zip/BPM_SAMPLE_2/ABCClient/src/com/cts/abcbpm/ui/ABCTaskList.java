package com.cts.abcbpm.ui;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Enumeration;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import com.cts.abcbpm.bean.UserBean;
import com.cts.abcbpm.utils.AuthUserUtils;
import com.cts.abcbpm.utils.BrowserUtils;
import com.cts.abcbpm.utils.RestUtils;
import com.cts.abcbpm.utils.XMLtUtils;

public class ABCTaskList extends JFrame {

	private static final long serialVersionUID = 1L;
	private JTable table;
	private JTextField criteriaText;
	private JPopupMenu popupMenu;
	private JMenuItem showTaskDetailMenu;
	private JMenuItem showTaskDetailBrowserMenu;

	public ABCTaskList() {
		super("ABC Client - Task List");
		this.setSize(575, 371);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JPanel panel = new JPanel();
		this.getContentPane().add(panel);
		placeComponents(panel);

		JLabel lblAbcBpm = new JLabel("ABC - BPM Client");
		lblAbcBpm.setHorizontalAlignment(SwingConstants.CENTER);
		lblAbcBpm.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblAbcBpm.setBounds(156, 11, 221, 25);
		panel.add(lblAbcBpm);

		this.setVisible(true);
		this.addWindowListener(new ABCWindowAdaptor(this));
	}

	private void placeComponents(JPanel panel) {

		panel.setLayout(null);

		JLabel lblUsername = new JLabel(AuthUserUtils.getUser().getUserName());
		lblUsername.setHorizontalAlignment(SwingConstants.RIGHT);
		lblUsername.setBounds(465, 11, 64, 14);
		panel.add(lblUsername);

		JLabel userLabel = new JLabel("BPM API");
		userLabel.setBounds(67, 54, 70, 25);
		panel.add(userLabel);

		criteriaText = new JTextField(20);
		criteriaText.setBounds(142, 54, 160, 25);
		panel.add(criteriaText);
		criteriaText.setText("Task");
		criteriaText.setEditable(false);
		criteriaText.setEnabled(false);
		criteriaText.setDisabledTextColor(new Color(37, 7, 7));

		JButton btnSearch = new JButton("Search");
		btnSearch.setBounds(321, 54, 80, 25);
		panel.add(btnSearch);

		JLabel lblGoBPM = new JLabel("<HTML><U>Go BPM Portal (Case 3)</U></HTML>");
		lblGoBPM.setCursor(new Cursor(Cursor.HAND_CURSOR));
		lblGoBPM.setBounds(421, 54, 150, 25);
		lblGoBPM.setForeground(new Color(30, 30, 250));
		panel.add(lblGoBPM);
		
		lblGoBPM.addMouseListener(new MouseListener() {
			
			@Override
			public void mouseReleased(MouseEvent e) {}
			
			@Override
			public void mousePressed(MouseEvent e) {}
			
			@Override
			public void mouseExited(MouseEvent e) {}
			
			@Override
			public void mouseEntered(MouseEvent e) {}
			
			@Override
			public void mouseClicked(MouseEvent e) {
				BrowserUtils.INSTANCE.openTaskHttpReq(0, "ibmbpm", 9443);
				
			}
		});
		
		

		Object columnNames[] = { "Task ID", "Task Name", "TAD Display Name", "Status"};

		TableModel model = new DefaultTableModel(null, columnNames);
		table = new JTable(model);

		//table.getColumnModel().getColumn(0).setMinWidth(0);
		//table.getColumnModel().getColumn(0).setMaxWidth(0);

		popupMenu = new JPopupMenu();
		showTaskDetailMenu = new JMenuItem("Show Task Detail (Case 2)");
		showTaskDetailBrowserMenu = new JMenuItem("Show Task Detail - BPM Web (Case 1)");

		popupMenu.add(showTaskDetailMenu);
		popupMenu.add(showTaskDetailBrowserMenu);
		table.setComponentPopupMenu(popupMenu);
		table.addMouseListener(new TableMouseListener(table));

		showTaskDetailMenu.addActionListener(new MenuListener(this));
		showTaskDetailBrowserMenu.addActionListener(new MenuListener(this));

		btnSearch.addActionListener(new TaskListListener(this));

		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setBounds(10, 103, 519, 219);
		panel.add(scrollPane);
	}

	public void searchAction() {
		System.out.println("Search Action");

		UserBean user = AuthUserUtils.getUser();

		if (user != null && user.getUserName() != null
				&& user.getPassword() != null) {
			//String urlTaskList = "https://ibmbpm:9443/rest/bpm/wle/v1/tasks/query/IBM.DEFAULTALLTASKSLIST_75?calcStats=false";
			String urlTaskList = "https://ibmbpm:9443/rest/bpm/wle/v1/tasks/query/IBM.DEFAULTALLTASKSLIST_75?parts=all";
			StringBuffer response;
			try {
				response = RestUtils.INSTANCE.getAllTask(urlTaskList, user.getUserName(), user.getPassword());
				Vector<String> taskVec = XMLtUtils.INSTANCE.getTaskList(response);
				System.out.println("Task Vector: "+taskVec.size()+" -- "+taskVec);
				if (taskVec != null && taskVec.size() > 0) {
					DefaultTableModel model = new DefaultTableModel();
					String headers[] = { "Task ID", "Task Name", "TAD Display Name", "Status"};
					model.setColumnIdentifiers(headers);
					
					Enumeration<String> enTask = taskVec.elements();
					while (enTask.hasMoreElements()) {
						String id = (String) enTask.nextElement();
						String status = (String) enTask.nextElement();
						String name = (String) enTask.nextElement();
						String owner = (String) enTask.nextElement();
						String description = (String) enTask.nextElement();
						
						if (owner.length() > 0) {
							owner = owner.trim();
						}
						
						if ((user.getUserName().equalsIgnoreCase(owner) || owner.length() == 0) && description.contains("Capture")) {
							Object[] val = {id, name, description, status};
							model.addRow(val);
						}
						
						if (user.isManager() && (user.getUserName().equalsIgnoreCase(owner)  || owner.length() == 0) && description.contains("Review")) {
							Object[] val = {id, name, description, status};
							model.addRow(val);
						}
						
					}
					table.removeAll();
					table.setModel(model);
					table.repaint();

				}else{
					JOptionPane.showMessageDialog(this, "Request Service Failed!!!");
				}
				System.out.println(taskVec);
			} catch (Exception e) {
				e.printStackTrace();
				JOptionPane.showMessageDialog(this, "Request Service Failed!!!");
			}

		}
	}

	public void showTaskDetailAction() {
		System.out.println("Show Task Detail");
		int selectedRow = table.getSelectedRow();
		System.out.println(table.getValueAt(selectedRow, 0));
		String taskId = (String)table.getValueAt(selectedRow, 0);
		String taskDisplayName = (String)table.getValueAt(selectedRow, 2);
		new ABCAccountTask(taskId, taskDisplayName);

	}

	public void showTaskDetailBPMAction() {
		System.out.println("Show Task Detail - BPM Web");
		int selectedRow = table.getSelectedRow();
		String taskId = (String)table.getValueAt(selectedRow, 0);
		BrowserUtils.INSTANCE.openTaskHttpReq(Integer.parseInt(taskId), "ibmbpm", 9443);
		
	}
}

class TaskListListener implements ActionListener {
	ABCTaskList abcTaskList;

	public TaskListListener(ABCTaskList abcTaskList) {
		this.abcTaskList = abcTaskList;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String eventStr = e.getActionCommand();
		int ei = 0;
		if ("Search".equalsIgnoreCase(eventStr)) {
			ei = 1;
		}
		switch (ei) {
		case 1:
			this.abcTaskList.searchAction();
			break;
		default:
			break;
		}

	}
}

class MenuListener implements ActionListener {
	ABCTaskList abcTaskList;

	public MenuListener(ABCTaskList abcTaskList) {
		this.abcTaskList = abcTaskList;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String eventStr = e.getActionCommand();
		int ei = 0;
		if ("Show Task Detail (Case 2)".equalsIgnoreCase(eventStr)) {
			ei = 1;
		}else if ("Show Task Detail - BPM Web (Case 1)".equalsIgnoreCase(eventStr)) {
			ei = 2;
		}
		switch (ei) {
		case 1:
			this.abcTaskList.showTaskDetailAction();
			break;
		case 2:
			this.abcTaskList.showTaskDetailBPMAction();
			break;
		default:
			break;
		}

	}
}

class TableMouseListener extends MouseAdapter {

	private JTable table;

	public TableMouseListener(JTable table) {
		this.table = table;
	}

	@Override
	public void mousePressed(MouseEvent event) {
		Point point = event.getPoint();
		int currentRow = table.rowAtPoint(point);
		table.setRowSelectionInterval(currentRow, currentRow);
	}
}
