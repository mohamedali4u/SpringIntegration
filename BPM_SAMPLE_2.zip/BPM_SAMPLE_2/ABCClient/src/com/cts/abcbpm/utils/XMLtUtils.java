package com.cts.abcbpm.utils;

import java.io.StringReader;
import java.util.Vector;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

public enum XMLtUtils {
	INSTANCE;

	public boolean userDataCheck(StringBuffer response, String password) {

		//System.out.println(response);
		String status = "";
		String userId = "";
		String username = "";
		boolean isManager = false;
		try {

			// File fXmlFile = new File("test.xml");
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory
					.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			// Document doc = dBuilder.parse(fXmlFile);

			InputSource is = new InputSource();
			is.setCharacterStream(new StringReader(response.toString()));

			Document doc = dBuilder.parse(is);

			// optional, but recommended
			doc.getDocumentElement().normalize();

			System.out.println("Root element :"
					+ doc.getDocumentElement().getNodeName());

			NodeList nList = doc.getElementsByTagName(doc.getDocumentElement()
					.getNodeName());

			//System.out.println("----------------------------");

			for (int temp = 0; temp < nList.getLength(); temp++) {

				Node nNode = nList.item(temp);

				//System.out.println("\nCurrent Element :" + nNode.getNodeName());

				if (nNode.getNodeType() == Node.ELEMENT_NODE) {

					Element eElement = (Element) nNode;

					status = eElement.getElementsByTagName("status").item(0)
							.getTextContent();
					if (!status.equalsIgnoreCase("200")) {
						return false;
					}
					userId = eElement.getElementsByTagName("userID").item(0)
							.getTextContent();
					username = eElement.getElementsByTagName("userName")
							.item(0).getTextContent();

				}
			}
			
			NodeList itemList = doc.getElementsByTagName("memberships");
			//System.out.println("----------------------------");
			for (int temp = 0; temp < itemList.getLength(); temp++) {
				Node nNode = itemList.item(temp);
				//System.out.println("\nCurrent Element :" + nNode.getTextContent());
				if (nNode.getTextContent().contains("Branch Manager")) {
					isManager = true;
					break;
				}
			}
			
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

		//System.out.println("UserId : " + userId);
		//System.out.println("Username : " + username);
		AuthUserUtils.setUser(userId, username, password, isManager);
		return true;

	}

	public Vector<String> getTaskList(StringBuffer response) {

		String status = "";
		Vector<String> taskVec = new Vector<String>();
		try {

			// File fXmlFile = new File("test.xml");
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory
					.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			// Document doc = dBuilder.parse(fXmlFile);

			InputSource is = new InputSource();
			is.setCharacterStream(new StringReader(response.toString()));

			Document doc = dBuilder.parse(is);

			// optional, but recommended
			doc.getDocumentElement().normalize();

			//System.out.println("Root element :"
			//		+ doc.getDocumentElement().getNodeName());

			NodeList nList = doc.getElementsByTagName(doc.getDocumentElement()
					.getNodeName());

			//System.out.println("----------------------------");
			boolean successFlag = false;
			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					status = eElement.getElementsByTagName("status").item(0)
							.getTextContent();
					if (status.equalsIgnoreCase("200")) {
						//System.out.println("------------Status :: " + 200
						//		+ "----------------");
						successFlag = true;
						break;
					}
				}
			}

			if (!successFlag) {
				return null;
			}

			NodeList itemList = doc.getElementsByTagName("item");
			//System.out.println("----------------------------");
			for (int temp = 0; temp < itemList.getLength(); temp++) {
				Node nNode = itemList.item(temp);
				//System.out.println("\nCurrent Element :" + nNode.getNodeName());
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;

					//TASK.TKIID
					//PI_NAME
					//TAD_DISPLAY_NAME
					
					// Element itemElement = (Element) itemNode;
					String key = eElement.getAttribute("key");

					//TASK.TKIID
					
					if (key!= null && "TASK.TKIID".equalsIgnoreCase(key.trim())) {
						String value = eElement.getElementsByTagName("value")
								.item(0).getTextContent();
						//System.out.println("Key : " + key);
						//System.out.println("value : " + value);
						taskVec.add(value.trim());
					}
					
					if (key!= null && "PI_NAME".equalsIgnoreCase(key.trim())) {
						String value = eElement.getElementsByTagName("value")
								.item(0).getTextContent();
						//System.out.println("Key : " + key);
						//System.out.println("value : " + value);
						taskVec.add(value.trim());
					}

					if ("TAD_DISPLAY_NAME".equalsIgnoreCase(key.trim())) {
						String value = eElement.getElementsByTagName("value")
								.item(0).getTextContent();
						//System.out.println("Key : " + key);
						//System.out.println("value : " + value);
						taskVec.add(value.trim());
					}
					
					if ("OWNER".equalsIgnoreCase(key.trim())) {
						NodeList valNode = eElement.getElementsByTagName("value");
						//System.out.println(valNode);
						String value = "";
						if (valNode != null) {
							Node nod = eElement.getElementsByTagName("value")
									.item(0);
							if (nod != null) {
								value = nod.getTextContent();
							}
							//System.out.println("Key : " + key);
							//System.out.println("value : " + value);
						}
						
						taskVec.add(value.trim());
					}
					
					if ("STATUS".equalsIgnoreCase(key.trim())) {
						NodeList valNode = eElement.getElementsByTagName("value");
						//System.out.println(valNode);
						String value = "";
						if (valNode != null) {
							Node nod = eElement.getElementsByTagName("value")
									.item(0);
							if (nod != null) {
								value = nod.getTextContent();
							}
							//System.out.println("Key : " + key);
							//System.out.println("value : " + value);
						}
						
						taskVec.add(value.trim());
					}
				}
				
				
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return taskVec;
	}
	
	public Vector<String> getAccountDetail(StringBuffer response) {

		String status = "";
		Vector<String> accountVec = new Vector<String>();
		try {

			// File fXmlFile = new File("test.xml");
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory
					.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			// Document doc = dBuilder.parse(fXmlFile);

			InputSource is = new InputSource();
			is.setCharacterStream(new StringReader(response.toString()));

			Document doc = dBuilder.parse(is);

			// optional, but recommended
			doc.getDocumentElement().normalize();

			//System.out.println("Root element :"
			//		+ doc.getDocumentElement().getNodeName());

			NodeList nList = doc.getElementsByTagName(doc.getDocumentElement()
					.getNodeName());

			//System.out.println("----------------------------");
			boolean successFlag = false;
			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					status = eElement.getElementsByTagName("status").item(0)
							.getTextContent();
					if (status.equalsIgnoreCase("200")) {
						//System.out.println("------------Status :: " + 200
						//		+ "----------------");
						successFlag = true;
						break;
					}
				}
			}

			if (!successFlag) {
				return null;
			}

			NodeList itemList = doc.getElementsByTagName("item");
			//System.out.println("----------------------------");
			for (int temp = 0; temp < itemList.getLength(); temp++) {
				Node nNode = itemList.item(temp);
				//System.out.println("\nCurrent Element :" + nNode.getNodeName());
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;

					//TASK.TKIID
					//PI_NAME
					//TAD_DISPLAY_NAME
					
					// Element itemElement = (Element) itemNode;
					String key = eElement.getAttribute("key");

					if (key!= null && "phone".equalsIgnoreCase(key.trim())) {
						String value = eElement.getElementsByTagName("value")
								.item(0).getTextContent();
						accountVec.add(value);
					}
					
					if (key!= null && "address".equalsIgnoreCase(key.trim())) {
						String value = eElement.getElementsByTagName("value")
								.item(0).getTextContent();
						accountVec.add(value);
					}
					
					if (key!= null && "name".equalsIgnoreCase(key.trim())) {
						String value = eElement.getElementsByTagName("value")
								.item(0).getTextContent();
						accountVec.add(value);
					}
					
					if (key!= null && "currency".equalsIgnoreCase(key.trim())) {
						String value = eElement.getElementsByTagName("value")
								.item(0).getTextContent();
						accountVec.add(value);
					}

					
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return accountVec;
	}

}
