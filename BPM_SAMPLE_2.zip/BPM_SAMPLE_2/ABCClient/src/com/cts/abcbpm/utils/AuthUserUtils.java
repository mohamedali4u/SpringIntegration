package com.cts.abcbpm.utils;

import com.cts.abcbpm.bean.UserBean;

public class AuthUserUtils {

	private static UserBean user = new UserBean();
	
	public static void setUser(String userId, String username, String password, boolean isManager){
		user.setUserId(userId);
		user.setUserName(username);
		user.setPassword(password);
		user.setManager(isManager);
	}
	
	public static UserBean getUser(){
		return user;
	}
}
