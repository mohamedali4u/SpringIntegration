package com.cts.abcbpm.utils;

import java.awt.Desktop;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;

//import net.sourceforge.htmlunit.corejs.javascript.ast.NewExpression;
//
//import org.openqa.selenium.By;
//import org.openqa.selenium.Keys;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.ie.InternetExplorerDriver;
//import org.openqa.selenium.remote.CapabilityType;
//import org.openqa.selenium.remote.DesiredCapabilities;

public enum BrowserUtils {
	INSTANCE;
	
	/*public void openTask(String taskId){


	    // Select WebDriver
		//FirefoxBinary binary = new FirefoxBinary(new File("C:\\Mozilla Firefox\\firefox.exe"));
		FirefoxProfile profile = new FirefoxProfile();
		profile.setPreference("dom.allow_scripts_to_close_windows", true);
	     WebDriver driver = new FirefoxDriver(binary, profile);
		System.out.println(System.getProperty("user.home"));
	    String driverPath = System.getProperty("user.home")+"\\WebDriver\\IEDriverServer.exe";
	    System.setProperty("webdriver.ie.driver", driverPath);
	    
	    DesiredCapabilities capabilities =  new DesiredCapabilities();
	    capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
	    capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		WebDriver driver = new InternetExplorerDriver(capabilities);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		driver.findElement(By.tagName("html")).sendKeys(Keys.chord(Keys.CONTROL, "0"));
		
	    // Destination URL
	    driver.get("https://ibmbpm:9443/ProcessPortal/login.jsp");    
	    System.out.println("Testing................");
	    driver.get("javascript:document.getElementById('overridelink').click();");
	    
	    try {
			Thread.sleep(1000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	    
	    
	    WebElement userElement = driver.findElement(By.id("username"));
	    userElement.sendKeys(AuthUserUtils.getUser().getUserName());
	    
	    WebElement passwdElement = driver.findElement(By.id("password"));
	    passwdElement.sendKeys(AuthUserUtils.getUser().getPassword());
	    
	    
	    WebElement login = driver.findElement(By.linkText("Continue"));
	    login.click();

	    try {
			Thread.sleep(1000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	    
	    if (taskId != null) {
	    	driver.get("https://ibmbpm:9443/ProcessPortal/launchTaskCompletion?taskId="+taskId);
		    
		    try {
				Thread.sleep(1000);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	    
	    
	}

	public void openTask(int taskId, String hostname, int port){
		System.setProperty("javax.xml.parsers.DocumentBuilderFactory",
				 "com.sun.org.apache.xerces.internal.jaxp.DocumentBuilderFactoryImpl");
	    // Select WebDriver
		String driverPath = System.getProperty("user.home")+"\\WebDriver\\IEDriverServer.exe";
	    System.setProperty("webdriver.ie.driver", driverPath);
	    
	    DesiredCapabilities capabilities =  new DesiredCapabilities();
	    capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
	    capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		WebDriver driver = new InternetExplorerDriver(capabilities);
		//driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		driver.findElement(By.tagName("html")).sendKeys(Keys.chord(Keys.CONTROL, "0"));
		//WebDriver driver = new InternetExplorerDriver();


	    String baseURL = "https://"+hostname+":"+port;
	    // Destination URL
	    driver.get(baseURL+"/ProcessPortal/login.jsp");    
	    //driver.get("javascript:document.getElementById('overridelink').click();");
	    
	    try {
			Thread.sleep(300);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	    
	    //driver.get("javascript:document.getElementById('overridelink').click();");
	    //WebElement override = driver.findElement(By.id("overridelink"));
	    //override.click();
	    
	    //driver.get(baseURL+"/ProcessPortal/login.jsp");
	    System.out.println("Testing................");
	    //driver.get("javascript:document.getElementById('overridelink').click();");
	    
	    
	    try {
			Thread.sleep(300);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	    
	    
	    WebElement userElement = driver.findElement(By.id("username"));
	    userElement.sendKeys(AuthUserUtils.getUser().getUserName());
	    
	    WebElement passwdElement = driver.findElement(By.id("password"));
	    passwdElement.sendKeys(AuthUserUtils.getUser().getPassword());
	    
	    
	    WebElement login = driver.findElement(By.linkText("Continue"));
	    login.click();

	    try {
			Thread.sleep(1000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	    
	    if (taskId > 0) {
	    	driver.get(baseURL+"/ProcessPortal/launchTaskCompletion?taskId="+taskId);
		    
		    try {
				Thread.sleep(1000);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	    
	    
	}*/
	
	public void openTaskSikuli(int taskId, String hostname, int port){
		
	    String baseURL = "https://"+hostname+":"+port;
	    baseURL = baseURL+"/ProcessPortal/login.jsp";
	    
	    String homePath = System.getProperty("user.home"); //+"\\BrowserUtil\\execute.bat";
	    //ProcessBuilder pBuilder = new ProcessBuilder(batchPath, baseURL, AuthUserUtils.getUser().getUserName(), AuthUserUtils.getUser().getPassword());
	    //ProcessBuilder pBuilder = new ProcessBuilder(batchPath);
	    System.out.println("home path "+homePath);
	    
	    try {
	    	
	    	String batchPath = homePath +"\\BrowserUtil\\lib\\runsikulix.cmd -r "+homePath+"\\BrowserUtil";
	    	if (taskId == 0) {
	    		batchPath = batchPath + "\\Documents.sikuli";
		    	batchPath = batchPath + " --args "+baseURL+" "+AuthUserUtils.getUser().getUserName()+" "+AuthUserUtils.getUser().getPassword();
			}else{
				String taskUrl = "https://"+hostname+":"+port+"/ProcessPortal/launchTaskCompletion?taskId="+taskId;
				batchPath = batchPath + "\\DocumentsTask.sikuli";
		    	batchPath = batchPath + " --args "+baseURL+" "+AuthUserUtils.getUser().getUserName()+" "+AuthUserUtils.getUser().getPassword();
		    	batchPath = batchPath +" "+taskUrl;
			}
	    	
	    	
    	   	new Thread(new ExeSikuli(batchPath)).start();
	    	
    	   	Thread.sleep(5000);
	    	Runtime.getRuntime().exec("C:\\Program Files\\Internet Explorer\\iexplore.exe");
	    	//start iexplore.exe

	    } catch (Exception e) {
			e.printStackTrace();
		}
	    
	}
	
	public void openTaskHttpReq(int taskId, String hostname, int port){
		String baseURL = "https://"+hostname+":"+port;
	    baseURL = baseURL+"/autologin/AutoFilter?username="+AuthUserUtils.getUser().getUserName();
	    baseURL = baseURL+"&password="+AuthUserUtils.getUser().getPassword();
	    baseURL = baseURL+"&taskId="+0;
	    String cmdLine = "rundll32 url.dll,FileProtocolHandler "
				+ baseURL;
		System.out.println("cmdLine "+cmdLine);
		
		Process exec;
		try {
			exec = Runtime.getRuntime().exec(cmdLine);
			exec.waitFor();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if (taskId > 0) {
			String taskUrl = "https://"+hostname+":"+port+"/ProcessPortal/launchTaskCompletion?taskId="+taskId;
			try {
				Thread.sleep(5000);
				Desktop.getDesktop().browse(new URI(taskUrl));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}
	
}

class ExeSikuli implements Runnable{
	String batchPath;
	public ExeSikuli(String batchPath) {
		this.batchPath = batchPath;
	}
	@Override
	public void run() {
		try {
			System.out.println(this.batchPath);
			Process process = Runtime.getRuntime().exec(this.batchPath);
			//Process process = pBuilder.start();
			//System.out.println(process.waitFor());
			System.out.println("testing");
			
			BufferedReader msgStream = new BufferedReader(new InputStreamReader(process.getInputStream()));
			for (String msg = msgStream.readLine(); msg != null; msg = msgStream.readLine()) {
				System.out.println(msg + "\n");
			}

			BufferedReader errStream = new BufferedReader(new InputStreamReader(process.getErrorStream()));
			for (String err = errStream.readLine(); err != null; err = errStream.readLine()) {
				System.out.println(err + "\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}
}
