package com.cts.abcbpm.utils;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Authenticator;
import java.net.PasswordAuthentication;
import java.net.URL;
import java.net.URLConnection;

public enum RestUtils {
	INSTANCE;
	private void doAuthentication(String username, String password){
		String userHome = System.getProperty("user.home");
		String certPath = userHome+"\\ssl_cert\\cacerts";
		System.setProperty("javax.net.ssl.trustStore", certPath);
		System.setProperty("javax.net.ssl.trustStorePassword", "changeit");
		Authenticator.setDefault(new MyAuthenticator(username, password)); 
	}
	
	public StringBuffer userRequest(String urlStr, String username, String password) throws Exception{
		doAuthentication(username, password);
		StringBuffer answer = new StringBuffer();
		
			URL url = new URL(urlStr);
			URLConnection conn = url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestProperty("Content-Type",
					"application/x-www-form-urlencoded");
			conn.setRequestProperty("Accept", "application/xml");

			// Get the response
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					conn.getInputStream()));
			String line;
			while ((line = reader.readLine()) != null) {
				answer.append(line +"\n");
			}
			//writer.close();
			reader.close();

			// Output the response
			//System.out.println(answer.toString());
		return answer;
	}
	
	public StringBuffer getAllTask(String urlStr, String username, String password) throws Exception{
		doAuthentication(username, password);
		StringBuffer answer = new StringBuffer();
		
			URL url = new URL(urlStr);
			URLConnection conn = url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestProperty("Content-Type",
					"application/x-www-form-urlencoded");
			conn.setRequestProperty("Accept", "application/xml");

			// Get the response
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					conn.getInputStream()));
			String line;
			while ((line = reader.readLine()) != null) {
				answer.append(line +"\n");
			}
			//writer.close();
			reader.close();

			// Output the response
			//System.out.println(answer.toString());
		return answer;
	}
	
	public StringBuffer getAccountDataTask(String urlStr, String username, String password) throws Exception{
		doAuthentication(username, password);
		StringBuffer answer = new StringBuffer();
		
			URL url = new URL(urlStr);
			URLConnection conn = url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestProperty("Content-Type",
					"application/x-www-form-urlencoded");
			conn.setRequestProperty("Accept", "application/xml");

			// Get the response
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					conn.getInputStream()));
			String line;
			while ((line = reader.readLine()) != null) {
				answer.append(line +"\n");
			}
			//writer.close();
			reader.close();

			// Output the response
			//System.out.println(answer.toString());
		return answer;
	}
	
	public StringBuffer submitAccountDataTask(String urlStr, String username, String password, String params) throws Exception{
		doAuthentication(username, password);
		StringBuffer answer = new StringBuffer();
		
			URL url = new URL(urlStr);
			URLConnection conn = url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestProperty("Content-Type",
					"application/x-www-form-urlencoded");
			conn.setRequestProperty("Accept", "application/xml");
			
			OutputStreamWriter writer = new OutputStreamWriter(
					conn.getOutputStream());

			// write parameters
			writer.write(params);
			writer.flush();

			// Get the response
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					conn.getInputStream()));
			String line;
			while ((line = reader.readLine()) != null) {
				answer.append(line +"\n");
			}
			writer.close();
			reader.close();

			// Output the response
			//System.out.println(answer.toString());
		return answer;
	}
	
	public StringBuffer finishTask(String urlStr, String username, String password) throws Exception{
		doAuthentication(username, password);
		StringBuffer answer = new StringBuffer();
		
			URL url = new URL(urlStr);
			URLConnection conn = url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestProperty("Content-Type",
					"application/x-www-form-urlencoded");
			conn.setRequestProperty("Accept", "application/xml");
			
//			OutputStreamWriter writer = new OutputStreamWriter(
//					conn.getOutputStream());

			// write parameters
//			writer.write(params);
//			writer.flush();

			// Get the response
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					conn.getInputStream()));
			String line;
			while ((line = reader.readLine()) != null) {
				answer.append(line +"\n");
			}
			//writer.close();
			reader.close();

			// Output the response
			//System.out.println(answer.toString());
		return answer;
	}

	static class MyAuthenticator extends Authenticator {
		String username;
		String password;
		public MyAuthenticator(String username, String password) {
			this.username = username;
			this.password = password;
		}
		public PasswordAuthentication getPasswordAuthentication() {
			System.err.println("Feeding username and password for "
					+ getRequestingScheme() + " authentication");
			return (new PasswordAuthentication(this.username, this.password.toCharArray()));
		}
	}
}
