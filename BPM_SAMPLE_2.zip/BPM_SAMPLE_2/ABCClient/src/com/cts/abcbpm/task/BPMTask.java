package com.cts.abcbpm.task;

import java.awt.Desktop;
import java.net.URI;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Vector;

import com.cts.abcbpm.bean.AccountBean;
import com.cts.abcbpm.bean.TaskBean;
import com.cts.abcbpm.bean.UserBean;
import com.cts.abcbpm.utils.AuthUserUtils;
import com.cts.abcbpm.utils.BrowserUtils;
import com.cts.abcbpm.utils.RestUtils;
import com.cts.abcbpm.utils.XMLtUtils;

public class BPMTask {
	
	private String hostname;
	private int port;
	private String username;
	private String password;
	
	public BPMTask(String hostname, int port, String username, String password) {
		this.hostname = hostname;
		this.port = port;
		this.username = username;
		this.password = password;
	}
	
	private String getURL(){
		return "https://"+this.hostname+":"+this.port+"/rest/bpm/wle/v1";
	}
	
	public List<TaskBean> getTaskList(){

		System.out.println("Search Action");

		List<TaskBean> taskList = new ArrayList<TaskBean>();
		if (this.hostname != null && this.port > 0 && this.username != null && this.password != null) {
			checkUser();
			//String urlTaskList = "https://ibmbpm:9443/rest/bpm/wle/v1/tasks/query/IBM.DEFAULTALLTASKSLIST_75?calcStats=false";
			String urlTaskList = getURL()+"/tasks/query/IBM.DEFAULTALLTASKSLIST_75?parts=all";
			System.out.println(urlTaskList);
			StringBuffer response;
			try {
				response = RestUtils.INSTANCE.getAllTask(urlTaskList, this.username, this.password);
				Vector<String> taskVec = XMLtUtils.INSTANCE.getTaskList(response);
				System.out.println("Task Vector: "+taskVec.size()+" -- "+taskVec);
				if (taskVec != null && taskVec.size() > 0) {
					
					Enumeration<String> enTask = taskVec.elements();
					while (enTask.hasMoreElements()) {
						TaskBean taskBean = new TaskBean();
						UserBean user = AuthUserUtils.getUser();
						
						
						taskBean.setTaskId(Integer.parseInt((String) enTask.nextElement()));
						taskBean.setStatus((String) enTask.nextElement());
						taskBean.setTaskName((String) enTask.nextElement());
						taskBean.setOwner((String) enTask.nextElement());
						taskBean.setDisplayTitle((String) enTask.nextElement());
						
						
						
						//122, Received, ReplenishmentBPD:98, , Task: Review Replenishment Order
						
//						System.out.println(" --> "+user.getUserName());
//						System.out.println(" --> "+user.isManager());
//						System.out.println(" --> "+taskBean.getTaskName());
//						System.out.println(" --> "+taskBean.getDisplayTitle());
//						System.out.println(" --> "+taskBean.getOwner());
//						System.out.println(" --> "+taskBean.getOwner().length());
						
						if ((user.getUserName().equalsIgnoreCase(taskBean.getOwner()) || taskBean.getOwner().length() == 0) && taskBean.getDisplayTitle().contains("Capture")) {
							taskList.add(taskBean);
						}
						
						if (user.isManager() && (user.getUserName().equalsIgnoreCase(taskBean.getOwner())  || taskBean.getOwner().length() == 0) && taskBean.getDisplayTitle().contains("Review")) {
							taskList.add(taskBean);	
						}
											
					}
				}
				System.out.println(taskVec);
			} catch (Exception e) {
				e.printStackTrace();
				
			}

		}
		return taskList;
	}
	
	
	public AccountBean getAccountDetail(int taskId){
		System.out.println("Fetch Demo Action");
		AccountBean accountBean = null;
		if (this.hostname != null && this.port > 0 && this.username != null && this.password != null) {

			String param = "phone,address,name,currency";
			// phone%2Caddress%2Cname%2Ccurrency
			String urlAccountGet = getURL()+"/task/"+taskId+"?action=getData&fields="
					+ param;
			StringBuffer response;
			try {
				response = RestUtils.INSTANCE.getAccountDataTask(urlAccountGet, this.username, this.password);
				Vector<String> taskVec = XMLtUtils.INSTANCE.getAccountDetail(response);
				System.out.println("Task Vector: " + taskVec.size() + " -- "
						+ taskVec);
				if (taskVec != null && taskVec.size() > 0) {
					Enumeration<String> eTask = taskVec.elements();
					
					accountBean = new AccountBean();
					accountBean.setPhone((String) eTask.nextElement());
					accountBean.setAddress((String) eTask.nextElement());
					accountBean.setName((String) eTask.nextElement());
					accountBean.setCcy((String) eTask.nextElement());		
				}
			} catch (Exception e) {
				e.printStackTrace();
				
			}
		}
		
		return accountBean;
	}
	
	public boolean postAccountDetail(AccountBean account, int taskId){
		System.out.println("Post Account");
		boolean successFlag = false;
		if (this.hostname != null && this.port > 0 && this.username != null && this.password != null) {

			String data = "{'phone':'"+account.getPhone()+"','address':'"+account.getAddress()+"','name':'"+account.getName()+"','currency':'"+account.getCcy()+"'}";
			String params = "action=setData&params="+data;
			
			String urlSubmit = getURL()+"/task/"+taskId;
			StringBuffer response;
			try {
				response = RestUtils.INSTANCE.submitAccountDataTask(urlSubmit, this.username, this.password, params);
				Vector<String> taskVec = XMLtUtils.INSTANCE.getAccountDetail(response);
				System.out.println("Task Vector: " + taskVec.size() + " -- "
						+ taskVec);
				if (taskVec != null && taskVec.size() > 0) {
					String urlFinishTask = getURL()+"/task/"+taskId+"?action=finish&parts=all";
					RestUtils.INSTANCE.submitAccountDataTask(urlFinishTask, this.username, this.password, params);
					successFlag = true;
				}
			} catch (Exception e) {
				e.printStackTrace();
				successFlag = false;
			}
		}
		
		return successFlag;
	}
	
	private boolean checkUser(){
		StringBuffer response = null;
		try {
			String urlUser = getURL()+"/user?userName="+username+"&includeInternalMemberships=true&refreshUser=false&parts=all";
			response = RestUtils.INSTANCE.userRequest(urlUser, this.username, this.password);
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		
		if (response != null) {
			boolean flag = XMLtUtils.INSTANCE.userDataCheck(response, this.password);
			return flag;
		}
		return true;
	}
	
	public void openTaskInBPMPortal(int taskId){
		AuthUserUtils.setUser(this.username, this.username, this.password, true);
		//openBPMPortal();
		BrowserUtils.INSTANCE.openTaskHttpReq(taskId, this.hostname, this.port);
	}
	
	public void openBPMPortal(){
		AuthUserUtils.setUser(this.username, this.username, this.password, true);
		BrowserUtils.INSTANCE.openTaskHttpReq(0, this.hostname, this.port);
	}
	
	public static void main(String[] args) {
		
	}

}
