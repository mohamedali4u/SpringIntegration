package com.cts.abcbpm.task;

import java.awt.Desktop;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;

import com.cts.abcbpm.bean.TaskBean;

public class TestURL {
	public static void main(String[] args) {

		BPMTask bpmTask = new BPMTask("ibmbpm", 9443, "bob", "password");
		List<TaskBean> taskList = bpmTask.getTaskList();
		System.out.println(taskList.size());
		for (TaskBean taskBean : taskList) {
			System.out.println(taskBean.getTaskId() + "  " +taskBean.getDisplayTitle());
		}
		//bpmTask.openBPMPortal();
		bpmTask.openTaskInBPMPortal(154);
		
		 
	
	}

}
