package com.test;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet Filter implementation class AutoFilter
 */
@WebFilter("/AutoFilter")
public class AutoFilter implements Filter {

	private final static String TASK_ZERO = "0";
    /**
     * Default constructor. 
     */
    public AutoFilter() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		// place your code here

		// pass the request along the filter chain
		//chain.doFilter(request, response);
		
		HttpServletRequest httpRequest = (HttpServletRequest)request;  
		
		 String username = (String)httpRequest.getParameter("username");
		 String password = (String)httpRequest.getParameter("password");
		 String taskId = (String)httpRequest.getParameter("taskId");
		 System.out.println("======================="+username+" "+password+" "+taskId+"=======================");
		 System.out.println(httpRequest.getRequestURI());
		 System.out.println(httpRequest.getLocalName());
		 System.out.println(httpRequest.getLocalPort());
		 //TestJSSE.getProperty();
		 
		 HttpServletResponse httpResponse = (HttpServletResponse)response;
		 PrintWriter out = httpResponse.getWriter();
		 //out.write(username+" "+password);
		 //out.write(HttpUtil.getResponse());
		
		 if (TASK_ZERO.equalsIgnoreCase(taskId)) {
			 String url = "http://ibmbpm:9443/ProcessPortal/j_security_check?j_username=" + username + "&j_password=" + password;
			 String redirectUrl = httpResponse.encodeRedirectURL(url);
			 httpResponse.sendRedirect(redirectUrl);
		}
		 
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
